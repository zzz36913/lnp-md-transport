#!/bin/bash
# [R4N2v4] run_R4N2v4.sh -- 第 2 晚 rv4 续跑增量包 (rv3 跑完后接手; DEADLINE 11-01 07:30 +0800). 只续跑 (ext), 不新起 build, 不 grompp, 不过闸门.
#   队列 chains_rv4/extq_<机>.txt, 每行 "<build> <目标ns> <prereg|explore> <prior|main>" (文件顺序 = 优先级; 两槽动态领取):
#     prereg = 预注册 1.2 µs 判读段 (规则 2 只在 1.2 µs 判); 须整段放得下 (剩余 >= need + SUPP_MARGIN_H) 才领.
#     explore = 1.2 µs 之后续到 2 µs 的探索段 (只记录 DOPC 何时失去 H_II, 不改任何判据) 与 C3 (320 K h100) 续跑; 剩余 >= EXPLORE_MIN_H 即领, 到点 -maxh 截断 (TRUNC, 能跑多长跑多长).
#     src: prior = 第 1 晚 400 ns 终点 (EXT_SRC_PRIOR 里的 R4N1/R4N1x run 目录, 只读); main = rv3 本晚 400 ns 终点 (WAIT_MAIN 指的 rv3 run 目录, 只读).
#     目标 2000 的条目只从本 OUT 的 ext1200 DONE 续 (低段在跑 -> 等; 低段终态非 DONE -> 记 EXT_LOWER_NOT_DONE 不跑).
#   K_BRANCH=3SYS (必填; 4SYS 于 10-31 15:28 废止, CHECK 判 FAIL): 3SYS = K 批例外, 只续 DOPE/DOPC/MC3H, MC3 记 VOID (SKIP_3SYS_MC3_VOID), 本轮只定尺长.
#   每格 (体系_水合_温度_臂) 最多 EXT_N=3 条 1.2 µs 首段: s4 只在 s1-s3 有缺源时顶上 (rv3 的 MC3 VOID 种子).
#   等 rv3: WAIT_SCOPE=machine (默认) 等 rv3 整机 done + 无 rv3 容器 + rv3 MPS 退净; 见 lib_R4N2v4.sh.
# 用法: K_BRANCH=3SYS WAIT_MAIN=<rv3 run 目录> EXT_SRC_PRIOR="<第 1 晚目录...>" PRIO=raised GATE_PY=... bash run_R4N2v4.sh <k03|k04>  ; CHECK=1 / DRY=1 / APPEND_TO=<R4N2v4_run 目录>
# 不覆写/不 rm 任何既有文件; 只 stop 本脚本 R4N2v4_<机>_<pid>_* 容器; rv3 的进程/容器/MPS/目录一概不碰 (只读).
HERE=$(cd "$(dirname "$0")" && pwd); MACHINE=${1:?usage: bash run_R4N2v4.sh <k03|k04>}; ORCH_PID=$$
case $MACHINE in k03|k04) ;; *) echo "ABORT: 机器名须为 k03 或 k04"; exit 1;; esac
. "$HERE/lib_R4N2v4.sh"
K_BRANCH=${K_BRANCH:-}; K_PR_SALT=${K_PR_SALT:-none}; K_VOID_FIX_N3=${K_VOID_FIX_N3:-off}
EXTQ=$HERE/chains_rv4/extq_${MACHINE}.txt; EXT_QNAME=$(basename $EXTQ)
EXPLORE_MIN_H=${EXPLORE_MIN_H:-1.0}; EXT_N=${EXT_N:-3}; EXTQ_POLL_S=${EXTQ_POLL_S:-60}
EXT_SRC_PRIOR=${EXT_SRC_PRIOR:-"$HOME/R4N1/R4N1_run_${MACHINE}_* $HOME/R4N1x/R4N1x_run_${MACHINE}_*"}
MAINRUN=$(main_run); EXT_SRC_RUNS="$EXT_SRC_PRIOR ${MAINRUN}"
rdq(){ [ -f "$1" ] && grep -vE '^\s*(#|$)' "$1" | awk '{print $1":"$2":"$3":"$4":"$5}'; }   # build:T:class:src:srcdir (srcdir 可空; ~ = $HOME)
q_lower(){ rdq $EXTQ | awk -F: -v b=$1 -v t=$2 '$1==b && $2+0<t+0 && $2+0>m+0{m=$2} END{if(m!="")print m}'; }
branch_skip(){ [ "$K_BRANCH" = 3SYS ] && case $1 in R4N1_MC3_*) return 0;; esac; return 1; }
main_finished(){ [ -n "$MAINRUN" ] || return 0; [ -z "$(main_any_cn)" ] || return 1
  grep -E "^OUT=|== machine $MACHINE done" "$MAINRUN/orchestrator.log" 2>/dev/null | tail -1 | grep -q "== machine $MACHINE done" && return 0; main_lock_free "$MAINRUN"; }
# 每条只在自己的源集合里找 (prior = 第 1 晚目录; main = rv3 目录), 防两处都有同名 build DONE 时 EXT_SRC_AMBIG / 拿错源
use_src(){ if [ "$1" = main ]; then EXT_SRC_RUNS=${MAINRUN:-/nonexistent_rv3_run}; elif [ -n "$2" ] && [ -z "${EXT_SRC_PRIOR_FORCE:-}" ]; then EXT_SRC_RUNS=${2/#\~/$HOME}; else EXT_SRC_RUNS=$EXT_SRC_PRIOR; fi; }   # prior 行带第 5 列目录时只在该目录找 (EXT_SRC_PRIOR_FORCE=1 改用 EXT_SRC_PRIOR)
# 首段 (目标 = 该 build 在队列里的最低目标) 的源是否可用 (只读; 用 ext_src)
first_src_ok(){ use_src $3 $4; ext_src $1 $2 >/dev/null 2>&1 || return 1; return 0; }
# cell_quota_ok <b> <T>: 同格、同目标、队列中排在 b 之前且源可用的首段条目数 < EXT_N
cell_quota_ok(){ local b=$1 T=$2 c x xb xt n=0; c=$(cell_of $b)
  for x in $(rdq $EXTQ); do IFS=: read xb xt _ xs xd <<< "$x"; [ "$xb" = "$b" ] && break; [ "$xt" = "$T" ] && [ "$(cell_of $xb)" = "$c" ] && [ -z "$(q_lower $xb $xt)" ] || continue
    branch_skip $xb && continue; first_src_ok $xb $xt $xs $xd && n=$((n+1)); done; [ $n -lt $EXT_N ]; }
fits_class(){ local cls=$1 n=$2; if [ $cls = prereg ]; then awk -v r=$(rem_h) -v n=$n -v m=$SUPP_MARGIN_H 'BEGIN{exit !(r>=n+m)}'
  else awk -v r=$(rem_h) -v e=$EXPLORE_MIN_H -v t=$TAIL_H 'BEGIN{exit !(r>=e+t)}'; fi; }
# claim_ext: 按队列顺序领一条; 设 CLAIM_B CLAIM_T CLAIM_CLS CLAIM_NEED; 没有可领的返回 1, PENDING=1 表示有条目在等 (低段在跑 / rv3 未完)
claim_ext(){ local x b T cls src lo sl; CLAIM_B=; CLAIM_T=; PENDING=0; halted && return 1
  for x in $(rdq $EXTQ); do IFS=: read b T cls src sd <<< "$x"; local key=ext$T.$b
    ledger_has claim $key && continue; ledger_has dead $key && continue
    if branch_skip $b; then ledger_claim dead $key && rec skip $b $cls ext$T - SKIP_3SYS_MC3_VOID - - - - - - - "K_BRANCH=3SYS: MC3 记 VOID, 本轮不续"; continue; fi
    lo=$(q_lower $b $T)
    if [ -n "$lo" ]; then sl=$(last_state $OUT/builds/$b/ext$lo)
      if [ "$sl" != DONE ]; then
        if ledger_has dead ext$lo.$b || ledger_has fin ext$lo.$b; then ledger_claim dead $key && rec skip $b $cls ext$T - EXT_LOWER_NOT_DONE - - - - - - - "低段 ext$lo 终态=$sl (不跳段)"; continue; fi
        PENDING=1; continue; fi
    else
      if [ $src = main ] && ! main_finished; then PENDING=1; continue; fi
      use_src $src $sd; if ! ext_src $b $T >/dev/null 2>&1; then ledger_claim dead $key && rec skip $b $cls ext$T - EXT_NO_SRC - - - - - - - "src=$src: $ES_MSG (不从头跑)"; continue; fi
      cell_quota_ok $b $T || { ledger_claim dead $key && rec skip $b $cls ext$T - CELL_FULL - - - - - - - "格 $(cell_of $b) 已有 $EXT_N 条可续 (s4 只顶缺源)"; continue; }
    fi
    use_src $src $sd; CLAIM_NEED=$(need_h_ext $b $T)
    # 时间: 剩余只会变少 (实测速率只会把 need 调大) -> 放不下是永久的. prereg 放不下整段 -> 降为 prereg_trunc (照跑到 DL-TAIL, 记为未达 1.2 µs, 不进判读); 连探索最短都不够 -> dead
    if fits_class $cls $CLAIM_NEED; then :
    elif [ $cls = prereg ] && fits_class explore $CLAIM_NEED; then cls=prereg_trunc; rec skip $b $cls ext$T - PREREG_NO_FULL_FIT - - - - - - $CLAIM_NEED "剩余 $(rem_h)h < need+${SUPP_MARGIN_H}h: 照跑到 DL-TAIL (预计截断, 不进 1.2 µs 判读)"
    else ledger_claim dead $key && rec skip $b $cls ext$T - SUPP_SKIP_NO_TIME - - - - - - $CLAIM_NEED "剩余 $(rem_h)h 不够 (EXPLORE_MIN_H=${EXPLORE_MIN_H}h+TAIL)"; continue; fi
    ledger_claim claim $key || continue; CLAIM_B=$b; CLAIM_T=$T; CLAIM_CLS=$cls; CLAIM_SRC=$src; CLAIM_SD=$sd; return 0; done
  return 1; }
# ------------------------------------------------------------------ 发车判据
f(){ echo "  [FAIL] $*"; bad=1; }; p(){ echo "  [ok]   $*"; }
launch_guard(){ local b T cls src x lo dup n=0 g; bad=0
  echo "== launch_guard [rv4] machine=$MACHINE MODE=$MODE variant=$(cat $HERE/VARIANT_rv4 2>/dev/null) K_BRANCH=$K_BRANCH $(date '+%F %T %z')"
  [ "$(cat $HERE/VARIANT_rv4 2>/dev/null)" = night2_rv4_ext ] && p "VARIANT_rv4=night2_rv4_ext" || f "缺 VARIANT_rv4 或内容不对"
  # 1 包完整: rv4 增量 + rv3 底包 + 冻结
  ( cd $HERE && sha256sum -c MANIFEST_rv4_sha256.txt --quiet ) >/dev/null 2>&1 && p "MANIFEST_rv4_sha256.txt 全 OK" || f "rv4 文件与 MANIFEST_rv4_sha256.txt 不符"
  ( cd $HERE && sha256sum -c MANIFEST_sha256.txt --quiet ) >/dev/null 2>&1 && p "rv3 底包 MANIFEST_sha256.txt 全 OK (未被改)" || f "rv3 底包与 MANIFEST_sha256.txt 不符"
  ( cd $HERE && sha256sum -c FROZEN_sha256.txt --quiet ) >/dev/null 2>&1 && p "冻结文件 (verdict/PREREG/amendment) 逐字节不变" || f "冻结文件 sha 不符 (FROZEN_sha256.txt)"
  # 2 参数/开关
  [ "$MAXWARN_PROD" = 0 ] && p "MAXWARN_PROD=0" || f "MAXWARN_PROD=$MAXWARN_PROD (须 0)"
  [ -z "${NSTEPS_OVERRIDE_RELAX}${NSTEPS_OVERRIDE_PROD}" ] && p "无 nsteps 覆盖" || f "NSTEPS_OVERRIDE_* 本包不用"
  [ -z "${ALLOW_BUSY:-}" ] && p "未设 ALLOW_BUSY" || f "ALLOW_BUSY 已设 (本包不接受)"
  [ -z "${ONLY:-}${ONLY_FILE:-}" ] && p "未设 ONLY (rv4 不支持 ONLY; 用 K_BRANCH)" || f "ONLY/ONLY_FILE 已设: rv4 不支持"
  case "$K_BRANCH" in 4SYS) f "K_BRANCH=4SYS 已废止 (2026-10-31 15:28 调度回报 k03 rv3 C4 MC3H/MC3 hii 全 VOID_L2, 中性 MC3 过闸不可能 >=3); 只用 3SYS";; 3SYS) p "K_BRANCH=3SYS (K 批例外): 只续 DOPE/DOPC/MC3H; MC3 记 VOID (SKIP_3SYS_MC3_VOID); 本轮只定尺长";; *) f "K_BRANCH='$K_BRANCH' 须显式 4SYS|3SYS (只接受 3SYS; 4SYS 已废止)";; esac
  [ "$K_PR_SALT" = none ] && p "K_PR_SALT=none" || f "K_PR_SALT=$K_PR_SALT: 本包无 PR/盐 内容"
  [ "$K_VOID_FIX_N3" = off ] && p "K_VOID_FIX_N3=off" || f "K_VOID_FIX_N3=$K_VOID_FIX_N3: 第 3 晚另包"
  case "$WAIT_SCOPE" in machine|slot) p "WAIT_SCOPE=$WAIT_SCOPE";; *) f "WAIT_SCOPE=$WAIT_SCOPE 须 machine|slot";; esac
  [ "$PRIO" = raised ] && p "PRIO=raised (nice 0, cpu-shares 2048)" || echo "  [warn] PRIO=$PRIO (发车令要求 raised)"
  case "$GATE_PY" in /*) [ -x "$GATE_PY" ] && p "GATE_PY 绝对路径可执行: $GATE_PY (rv4 续跑不过闸门; 只核路径)" || { [ "$MODE" = local ] && echo "  [info] MODE=local: GATE_PY=$GATE_PY 不可执行" || f "GATE_PY=$GATE_PY 不可执行"; };; *) [ "$MODE" = local ] && echo "  [info] MODE=local: GATE_PY=$GATE_PY 非绝对路径" || f "GATE_PY 须绝对路径 (发车令: \$HOME/R4N2_pkg/R4N2/gatewrap/gate_py_container.sh)";; esac
  # 3 时间窗
  [ "$(rem_s)" -gt 0 ] && p "距 DEADLINE($DEADLINE) 剩 $(rem_h) h" || f "已过 DEADLINE"
  DL_CAP="2026-11-01 07:30 +0800"; [ "$(date -d "$DEADLINE" +%s 2>/dev/null || echo 9999999999)" -le "$(date -d "$DL_CAP" +%s)" ] && p "DEADLINE <= 硬上限 $DL_CAP (docker 外层超时 = 剩余+600 s, 最坏约 07:42 收完, 07:45 前交还)" || f "DEADLINE=$DEADLINE 晚于硬上限 $DL_CAP"
  for x in "$HERE" "$J"; do case "$(readlink -m "$x")/" in "$(readlink -m "$HOME")"/*) p "在 \$HOME 下: $x";; *) [ "$MODE" = local ] && echo "  [info] MODE=local: $x 不在 \$HOME 下" || f "$x 不在 \$HOME 下";; esac; done
  # 4 队列
  need_cmd || bad=1
  [ -s "$EXTQ" ] && p "队列 $EXT_QNAME: $(rdq $EXTQ | wc -l) 条" || f "缺队列 $EXTQ"
  for x in $(rdq $EXTQ); do IFS=: read b T cls src sd <<< "$x"
    valid_name $b || { f "非法 build 或缺 inputs_rv4/$b/expect.env: $b"; continue; }; [ "$(arm_of $b)" = hii ] || f "$b 非 hii"
    [ -s $INP/$b/prod_hii.mdp ] || f "缺 $INP/$b/prod_hii.mdp"
    case "$T" in 1200|2000|3000) ;; *) f "$b 目标 $T ns 非 1200|2000|3000";; esac
    case "$cls" in prereg) [ "$T" = 1200 ] && case $b in *_h100_T350_hii_*) true;; *) false;; esac || f "$b ext$T 标 prereg 但不是 C4 1.2 µs";; explore) ;; *) f "$b class=$cls 须 prereg|explore";; esac
    case "$src" in prior|main) ;; *) f "$b src=$src 须 prior|main";; esac
    lo=$(q_lower $b $T); if [ -n "$lo" ]; then n=$(rdq $EXTQ | grep -n "^$b:$lo:" | cut -d: -f1); [ "$n" -lt "$(rdq $EXTQ | grep -n "^$b:$T:" | cut -d: -f1)" ] || f "$b ext$T 排在其低段 ext$lo 之前"; fi; done
  dup=$(rdq $EXTQ | cut -d: -f1,2 | sort | uniq -d | tr '\n' ' '); [ -z "$dup" ] && p "队列内无重复 (build,目标)" || f "队列重复: $dup"
  dup=$(for m in k03 k04; do rdq $HERE/chains_rv4/extq_$m.txt | cut -d: -f1 | sort -u; done | sort | uniq -d | tr '\n' ' '); [ -z "$dup" ] && p "两机队列之间无同一 build" || f "跨机重复 build: $dup"
  # 5 源 (只读): prior 首段必须合格; main 首段 rv3 未完时只报 info
  for g in $(rdq $EXTQ | awk -F: '$4=="prior" && $5!=""{print $5}' | sort -u); do g=${g/#\~/$HOME}; [ -d "$g" ] && p "prior 源目录在: $g" || f "队列第 5 列 prior 源目录不存在: $g"; done
  if rdq $EXTQ | awk -F: '$4=="prior" && $5==""' | grep -q . || [ -n "${EXT_SRC_PRIOR_FORCE:-}" ]; then for g in $EXT_SRC_PRIOR; do [ -d "$g" ] || f "EXT_SRC_PRIOR 项 $g 未命中目录"; done; fi
  if [ "$WAIT_MAIN" = none ]; then echo "  [info] WAIT_MAIN=none: 不等 rv3 (src=main 条目无源 -> EXT_NO_SRC)"; elif [ -n "$MAINRUN" ] && [ -d "$MAINRUN" ]; then p "rv3 run 目录: $MAINRUN ($(main_finished && echo '已完' || echo '仍在跑, 本包会等'))"; else f "WAIT_MAIN=$WAIT_MAIN 未解析到唯一 rv3 run 目录 (显式给 WAIT_MAIN=\$HOME/R4N2/R4N2_run_${MACHINE}_<TS>)"; fi
  for x in $(rdq $EXTQ); do IFS=: read b T cls src sd <<< "$x"; [ -z "$(q_lower $b $T)" ] || continue; branch_skip $b && { echo "  [info] $b: 3SYS 跳过"; continue; }
    use_src $src $sd; if ext_src $b $T; then p "源 $b ($src): $EXT_SRC_DIR [$ES_MSG]"
    elif [ $src = main ]; then echo "  [info] 源 $b (main=rv3): 现在不可用 ($ES_MSG) -> 运行时 rv3 完后再判, 无则 EXT_NO_SRC (s4 顶)"
    else f "源 $b (prior): $ES_MSG"; fi; done
  # 6 进程/容器/MPS 冲突 (rv3 认出排除; 其余 FAIL)
  if [ "$MODE" = docker ]; then
    x=$(gmx_unattributed); [ -z "$x" ] && p "gmx 进程全部在 rv3 ^R4N2_${MACHINE}_ 容器内 (或无)" || f "有不属于 rv3 容器的 gmx 进程: $x"
    x=$(procs_other $$ 'R2a_machine|R2a_slot|R2b_machine|R2b_slot|run_R2|run_prerun|preflight_R3|run_R3\.sh|run_R4\.sh|run_R4N1\.sh|run_R4N1x\.sh|run_R4N2v4\.sh'"$( [ "$WAIT_MAIN" = none ] && echo '|run_R4N2\.sh')"); [ -z "$x" ] && p "无其它相关脚本进程 (另一个 run_R4N2v4 / R4N1 / R4N1x ...)" || f "有相关脚本进程: $(echo "$x" | head -3 | tr '\n' ';')"
    x=$(procs_other $$ 'run_R4N2\.sh'); [ -z "$x" ] && echo "  [info] rv3 run_R4N2.sh 编排进程: 无" || echo "  [info] rv3 run_R4N2.sh 在跑 (允许; 本包等它): $(echo "$x" | head -2 | cut -c1-120 | tr '\n' ';')"
    if [ -n "${HAVE_LOCK:-}" ]; then p "已持有 flock $J/.R4N2v4_${MACHINE}.flock"; elif test_lock; then p "flock 可得 (无同机 rv4)"; else f "flock 被占用: 同机已有 rv4 在跑"; fi
    x=$(docker ps --format '{{.Names}}' 2>/dev/null | grep -E '^(R2a_|R2b_|R3|R4_|R4N1_|R4N1x_|R4N2v4_|R4N2_|j009_)' | { [ "$WAIT_MAIN" = none ] && cat || grep -vE "^R4N2_${MACHINE}_[0-9]+_"; }); [ -z "$x" ] && p "docker ps 无 rv3 以外的占卡容器" || f "有占卡容器: $(echo "$x" | tr '\n' ' ')"
    echo "  [info] rv3 容器 (允许): $(main_any_cn | tr '\n' ' ')"
    x=$(mps_unattributed); [ -z "$x" ] && p "MPS 进程: $(ps -eo args= | grep -c '[n]vidia-cuda-mps') 个, 全部是 rv3 的 (pipe 在 \$HOME/mps_R4N2/)" || f "认不出归属的 MPS 进程 (先认人再 quit; 不 kill): $(echo "$x" | tr '\n' ';')"
    [ "$X_MPS" = off ] && echo "  [warn] X_MPS=off: 全程不用 MPS (约 1/3 速)" || p "X_MPS=auto: rv3 收完后起自己的 \$HOME/mps_R4N2v4/${MACHINE}_<TS>_<n>; 每条前验活 (rv3 同款)"
    if [ $bad = 0 ]; then echo "  ... ${GUARD_RECHECK_S:-60}s 后复查"; sleep ${GUARD_RECHECK_S:-60}; x=$(gmx_unattributed); [ -z "$x" ] && p "复查: 仍无 rv3 容器外的 gmx" || f "复查: 出现 rv3 容器外的 gmx: $x"; fi
    x=$(df -Pk "$(dirname $J)" 2>/dev/null | awk 'NR==2{printf "%d",$4/1048576}'); [ "${x:-0}" -ge 10 ] && p "磁盘可用 ${x} GiB" || f "磁盘可用 ${x:-?} GiB < 10"
  else echo "  [info] MODE=local: 跳过 gmx/容器/MPS/磁盘冲突检查 (box 冒烟)"; fi
  # 7 gmx 版本 + convert-tpr/dump 自检 (用第一条 prior 首段源的 tpr 复制件; 只写 $OUT/cvtchk, 不 mdrun)
  GMXV=$(gmx_version); [ -n "$GMXV" ] && check_gmxv && p "gmx 版本 $GMXV" || f "gmx 版本检查失败 ('$GMXV')"
  for x in $(rdq $EXTQ); do IFS=: read b T cls src sd <<< "$x"; use_src $src $sd; [ $src = prior ] && [ -z "$(q_lower $b $T)" ] && ext_src $b $T && break; b=; done
  if [ -n "$b" ]; then g=$OUT/cvtchk; mkdir -p $g; cp $ES_TPR $g/src.tpr; ( cd $g && CN=$(cn_name cvtchk_$BASHPID) gx convert-tpr -s src.tpr -nsteps $(ext_steps $b $T) -o ext.tpr ) > $g/convert.log 2>&1
    x=$( cd $g && CN=$(cn_name dmpchk_$BASHPID) gx dump -s ext.tpr 2>/dev/null | awk '$1=="nsteps"{print $3; exit}' )
    [ -s $g/ext.tpr ] && [ "$x" = "$(ext_steps $b $T)" ] && p "convert-tpr 自检: $b -> nsteps=$x (= ${T} ns)" || f "convert-tpr/dump 自检失败 (nsteps='$x' 期望 $(ext_steps $b $T)): $g/convert.log"
  else echo "  [info] 无 prior 源可做 convert-tpr 自检"; fi
  [ $bad = 0 ] && { echo "== launch_guard: ALL OK"; return 0; } || { echo "== launch_guard: FAIL (见 [FAIL])"; return 1; }; }
# ------------------------------------------------------------------ 槽
slot(){ local tag=$1 po=$2 rc
  SLOT_TAG=$tag; say "== slot start [rv4] queue=$EXT_QNAME K_BRANCH=$K_BRANCH pinoffset=$po NT=$NT deadline=$DEADLINE scope=$WAIT_SCOPE"
  wait_slot ${tag#${MACHINE}_} || { say "== slot end (未起: 等待放弃)"; return 0; }
  while :; do halted && break
    if claim_ext; then XB=$CLAIM_B; x_mps_pick; EXT_CLASS=$CLAIM_CLS
      say "领取 $CLAIM_B ext$CLAIM_T ($CLAIM_CLS) need≈${CLAIM_NEED}h remaining=$(rem_h)h mps=$X_MPS_NOTE"
      use_src $CLAIM_SRC $CLAIM_SD; run_ext $CLAIM_B $CLAIM_T $CLAIM_CLS $po supp; rc=$?; ledger_add fin ext$CLAIM_T.$CLAIM_B
      say "END $CLAIM_B ext$CLAIM_T rc=$rc state=$(last_state $OUT/builds/$CLAIM_B/ext$CLAIM_T) mps=$X_MPS_NOTE"; continue; fi
    if [ "$PENDING" = 1 ] && awk -v r=$(rem_h) -v e=$EXPLORE_MIN_H -v t=$TAIL_H 'BEGIN{exit !(r>=e+t)}'; then sleep $EXTQ_POLL_S; continue; fi
    break; done
  say "== slot end"; }
summary(){ echo "== summary [rv4] $MACHINE K_BRANCH=$K_BRANCH $(date '+%F %T %z')"; printf 'build\tclass\text_segments\n'
  for x in $(rdq $EXTQ | cut -d: -f1 | awk '!s[$0]++'); do printf '%s\t%s\t%s\n' $x "$(rdq $EXTQ | awk -F: -v b=$x '$1==b{printf "%s@%s ", $3, $2}')" "$(for e in $(ls -1d $OUT/builds/$x/ext[0-9]* 2>/dev/null); do printf '%s=%s(%s) ' $(basename $e) $(last_state $e) "$(sed -n 's/.*laststep=\([0-9]*\)\/.*/\1/p' $(last_attempt $e)/STATUS 2>/dev/null)"; done)"; done | tee $OUT/SUMMARY.tsv
  for x in $(ledger_list dead); do echo "DEAD $x"; done | tee -a $OUT/SUMMARY.tsv; }
# ------------------------------------------------------------------ DRY: 两槽事件模拟 (估算)
# 每条 need = (目标-起点) ns / (PERF*参考珠/本体系珠) * 24 + OVH_H; prereg 须 start+need+margin <= DL; explore 须 start+EXPLORE_MIN+TAIL <= DL, 截到 DL-TAIL.
dry_sim(){ local t0=$1 perf=$2 label=$3 x b T cls src P need ok
  for x in $(rdq $EXTQ); do IFS=: read b T cls src sd <<< "$x"; branch_skip $b && continue
    lo=$(q_lower $b $T); if [ -z "$lo" ]; then if [ $src = main ] && [ -n "${SIM_MAIN_MISSING:-}" ] && echo " $SIM_MAIN_MISSING " | grep -q " $b "; then continue; fi; cell_quota_sim=1; fi
    P=$(awk -v p=$perf -v r=$PERF_REF_BEADS -v n=$(exp_of $b EXP_ATOMS) 'BEGIN{printf "%.1f", p*r/n}')
    f0=$( [ -n "$lo" ] && echo $lo || echo 400 ); need=$(awk -v P=$P -v T=$T -v f=$f0 -v o=$OVH_H 'BEGIN{printf "%.3f", (T-f)/P*24 + o}')
    echo "$b $T $cls ${lo:-0} $need $(cell_of $b)"; done | awk -v t0=$t0 -v dl=$DL -v m=$SUPP_MARGIN_H -v e=$EXPLORE_MIN_H -v tail=$TAIL_H -v N=$EXT_N -v lab="$label" '
  { n++; B[n]=$1; T[n]=$2; C[n]=$3; L[n]=$4; D[n]=$5*3600; CE[n]=$6 }
  END{ s[1]=t0; s[2]=t0; left=n
    while(1){ k = (s[1]<=s[2]) ? 1 : 2; now=s[k]; pick=0; nextev=0
      for(i=1;i<=n;i++){ if(st[i]!="") continue
        if(L[i]>0){ key=B[i]" "L[i]; if(!(key in fin)){ if(key in dead){st[i]="dead_lower"; continue}; continue }; if(fin[key]>now){ if(nextev==0||fin[key]<nextev) nextev=fin[key]; continue } }
        else { if(quota[CE[i]" "T[i]]>=N){ st[i]="CELL_FULL"; dead[B[i]" "T[i]]=1; continue } }
        if(now+(e+tail)*3600>dl){ st[i]="SKIP_NO_TIME"; dead[B[i]" "T[i]]=1; continue }
        if(C[i]=="prereg" && now+D[i]+m*3600>dl) C[i]="prereg_trunc"
        pick=i; break }
      if(pick==0){ if(nextev>0){ s[k]=nextev; continue } ; s[k]=dl+1; if(s[1]>dl && s[2]>dl) break; continue }
      i=pick; if(L[i]==0) quota[CE[i]" "T[i]]++
      en=now+D[i]; lim=dl-tail*3600; if(en>lim){ en=lim; st[i]="TRUNC"; dead[B[i]" "T[i]]=1; frac=(en-now)/D[i] } else { st[i]="DONE"; fin[B[i]" "T[i]]=en; frac=1 }
      S[i]=now; E[i]=en; F[i]=frac; SL[i]=k; s[k]=en }
    printf "   %-34s %5s %-7s %-4s %-11s %-11s %s\n", "build", "目标", "类", "槽", "开始", "结束", "状态 (估算)"
    for(i=1;i<=n;i++){ if(S[i]=="") { printf "   %-34s %5s %-7s %-4s %-11s %-11s %s\n", B[i], T[i], C[i], "-", "-", "-", (st[i]==""?"不起(时间到)":st[i]); continue }
      lo=(L[i]>0?L[i]:400); reach=lo+(T[i]-lo)*F[i]
      printf "   %-34s %5s %-7s %-4s %-11s %-11s %s%s\n", B[i], T[i], C[i], (SL[i]==1?"A":"B"), strftime("%m-%d %H:%M",S[i]), strftime("%m-%d %H:%M",E[i]), st[i], (st[i]=="TRUNC"?sprintf(" -> 约 %d ns", reach):"") } }'; }
# ------------------------------------------------------------------ main
if [ -n "${CHECK:-}" ]; then OUT=/tmp/R4N2v4_check_$$; mkdir -p $OUT/slots; OUT_PARENT=$OUT; launch_guard; exit $?; fi
if [ -n "${DRY:-}" ]; then
  OUT=$(mktemp -d /tmp/R4N2v4_dry_XXXXXX); OUT_PARENT=$OUT; mkdir -p $OUT/slots $OUT/ledger; SLOT_TAG=dry; GMXV=dry
  echo "== DRY [rv4] machine=$MACHINE K_BRANCH='$K_BRANCH' MODE=$MODE deadline=$DEADLINE remaining=$(rem_h)h P=$(perf_eff) ns/day@${PERF_REF_BEADS}珠 (PERF_NOM=$PERF_NOM F_THR=$F_THR) WAIT_SCOPE=$WAIT_SCOPE WAIT_MAIN=$WAIT_MAIN main_run=${MAINRUN:-无} | 不建输出/不起 MPS/容器"
  case "$K_BRANCH" in 3SYS) ;; *) echo "   [warn] K_BRANCH 非 3SYS: 下面按不跳 MC3 列出, 正式跑会被 launch_guard FAIL";; esac
  echo "-- 队列 $EXT_QNAME (优先级 = 文件顺序; 两槽动态领取):"
  for x in $(rdq $EXTQ); do IFS=: read b T cls src sd <<< "$x"; lo=$(q_lower $b $T)
    if branch_skip $b; then echo "   $b ext$T [$cls] -> SKIP_3SYS_MC3_VOID"; continue; fi
    if [ -n "$lo" ]; then sr="源 = 本 OUT ext$lo DONE (运行时)"; else use_src $src $sd; if ext_src $b $T; then sr="源 $EXT_SRC_KIND $EXT_SRC_DIR"; else sr="源: $ES_MSG$( [ $src = main ] && echo ' (rv3 完后再判)')"; fi; fi
    echo "   $b ${lo:-400}->${T}ns [$cls/$src] need=$(need_h_ext $b $T ${lo:-})h | convert-tpr -nsteps $(ext_steps $b $T); mdrun -deffnm ext -s ext.tpr -cpi src.cpt -noappend | $sr"; done
  t0=$(date -d "${SIM_START:-now}" +%s); echo "-- 两槽事件模拟 (估算; 起点 SIM_START=${SIM_START:-现在} = rv3 本机预计完; prereg 须放得下 need+${SUPP_MARGIN_H}h; explore 剩余>=${EXPLORE_MIN_H}h+TAIL 即起, 到 DL-TAIL 截断):"
  for sc in ${SIM_PERFS:-"$(perf_eff):模型(PERF_NOM*F_THR)"}; do echo "  * 情景 ${sc#*:} P=${sc%%:*} ns/day@${PERF_REF_BEADS}珠"; dry_sim $t0 ${sc%%:*} "${sc#*:}"; done
  echo "-- K: K_BRANCH='$K_BRANCH' K_PR_SALT=$K_PR_SALT K_VOID_FIX_N3=$K_VOID_FIX_N3 | MPS X_MPS=$X_MPS 上限 $X_MPS_MAX_START | EXT_N=$EXT_N EXPLORE_MIN_H=$EXPLORE_MIN_H"
  exit 0; fi
need_cmd || exit 1
take_lock || { echo "ABORT: 同机 rv4 已在运行 (flock $J/.R4N2v4_${MACHINE}.flock)"; exit 1; }; HAVE_LOCK=1
init_out $MACHINE || exit 1; exec > >(tee -a $OUT/orchestrator.log) 2>&1
echo "OUT=$OUT"; launch_guard || { echo "ABORT: 发车判据不过, 未起 MPS/容器"; exit 1; }
GMXV=${GMXV:-unknown}
# APPEND_TO 续跑: 上一进程领了但没 fin 的条目 (被打断) 释放回队列 (改名到 ledger/released, 不删), 由 run_ext 从 ext.cpt 续
if [ -n "${APPEND:-}" ]; then for x in $(ledger_list claim); do ledger_has fin $x && continue; mkdir -p $OUT/ledger/released; mv $OUT/ledger/claim/$x $OUT/ledger/released/${x}_$(date +%m%d_%H%M%S) && echo "APPEND_TO: 释放未完成领取 $x"; done; fi
{ echo "machine=$MACHINE host=$(hostname) start=$(date '+%F %T %z') deadline=$DEADLINE gmx=$GMXV mode=$MODE variant=rv4 K_BRANCH=$K_BRANCH"; env | grep -E '^(K_|EXT_|DEADLINE|WAIT_|START_AT|GO_QUIET|JMAIN|X_MPS|MPS_DRAIN|MAXWARN_|F_THR|PERF_NOM|GATE_|SUPP|EXPLORE|NT=|PINA|PINB|TAIL_H|MINRUN_H|IMG=|J=|EXPECT_GMX|PRIO|PERF_)' | sort; echo "PRIO=$PRIO NICE=$NICE CPUSH=$CPUSH WAIT_SCOPE=$WAIT_SCOPE main_run=$MAINRUN"; echo "EXT_SRC_PRIOR=$EXT_SRC_PRIOR"; echo "EXT_SRC_MAIN=$MAINRUN"; (cd $HERE && sha256sum run_R4N2v4.sh lib_R4N2v4.sh chains_rv4/*.txt MANIFEST_rv4_sha256.txt MANIFEST_sha256.txt FROZEN_sha256.txt VARIANT_rv4); } > $OUT/RUN_META.txt
cleanup(){ echo "[$(date '+%F %T')] INTERRUPT/EXIT: 只停本脚本容器 ${CN_PREFIX}${MACHINE}_${ORCH_PID}_*"; [ "$MODE" = local ] || { for c in $(docker ps --format '{{.Names}}' | grep "^${CN_PREFIX}${MACHINE}_${ORCH_PID}_"); do docker stop -t 120 $c >/dev/null 2>&1; done; }; }
trap 'cleanup; kill $PA $PB 2>/dev/null; wait $PA $PB 2>/dev/null; x_mps_stop; exit 143' INT TERM
( slot ${MACHINE}_A $PINA ) & PA=$!
( slot ${MACHINE}_B $PINB ) & PB=$!
wait $PA $PB; x_mps_stop; summary; echo "== machine $MACHINE done $(date '+%F %T %z') OUT=$OUT"
