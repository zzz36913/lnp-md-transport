#!/bin/bash
# test_orch_rv4.sh [包目录] -- box 上整机编排冒烟 (MODE=local, mock gmx, 假 $HOME 树); 只写 /tmp. 包目录须已解开 rv3 底包 + rv4 增量 (= 机上 ~/R4N2_pkg/R4N2).
#  O1 k03 3SYS 分包实况: rv3 已完 (MC3H/MC3 C4 全 VOID); C4 DOPE 1200->2000->3000 + C3 DOPE 1200->2000->3000; 源树/rv3 树逐字节不变, EXT_CLASS 写对
#  O2 K_BRANCH=4SYS 正式跑 -> launch_guard FAIL
#  O3 k04 低段失败: DOPC s1 ext1200 FAIL -> ext2000 EXT_LOWER_NOT_DONE, 不跳段
#  O4 时间不够: 剩 2.2h -> prereg 降 prereg_trunc 照跑; 剩 1.0h -> 起槽但条目全 SUPP_SKIP_NO_TIME
#  O5 整机等待: rv3 容器在 + flock 被持有 -> 不起; 容器消失 + "== machine done" 后才起 (reason=MAIN_DONE), 起跑时间晚于放行时刻
#  O6 APPEND_TO: 上次领了没 fin 的条目释放 (改名, 不删) 并从 ext.cpt 续到 DONE
#  (O1 内含) prior 源目录里同名 build 在别的 run 也有 DONE: 第 5 列限定目录 -> 不 AMBIG
H=${1:-$(cd "$(dirname "$0")/.." && pwd)}; H=$(cd $H && pwd); T=$(mktemp -d /tmp/R4N2v4_orch_XXXXXX); fails=0
ok(){ echo "PASS $*"; }; bad(){ echo "FAIL $*"; fails=$((fails+1)); }
mkdone(){ local d=$1/builds/$2/prod/attempt_${3:-001} ls=${4:-20000000}; mkdir -p $d; printf 'nsteps = 20000000\nbuild %s\n' $2 > $d/prod.tpr; printf 'step %s\npart 1\n' $ls > $d/prod.cpt
  printf '           Step           Time\n       %s    0\nFinished mdrun\n' $ls > $d/prod.log; echo "DONE rc=0 laststep=$ls/20000000 nan=0" > $d/STATUS; ( cd $d && sha256sum prod.tpr prod.log prod.cpt > SHA256_out.txt ); }
mkhome(){ local m=$1; local FH=$T/$2/home/$m; mkdir -p $FH/R4N2_pkg; cp -a $H $FH/R4N2_pkg/R4N2; mkdir -p $FH/R4N1x $FH/R4N1 $FH/R4N2
  if [ $m = k03 ]; then for s in 1 2 3; do mkdone $FH/R4N1x/R4N1x_run_k03_1030_145609 R4N1_DOPE_h100_T350_hii_s$s; mkdone $FH/R4N1/R4N1_run_k03_1030_141205 R4N1_DOPE_h100_T320_hii_s$s; done
    mkdone $FH/R4N1x/R4N1x_run_k03_1030_145609 R4N1_MC3H_h100_T350_hii_s1   # 第 1 晚也有 MC3H s1 DONE: main 行只在 rv3 找 -> 不 AMBIG
    mkdone $FH/R4N1/R4N1_run_k03_1030_141205 R4N1_DOPE_h100_T350_hii_s1    # 另一 prior run 也有 DOPE C4 s1 DONE: 第 5 列限定 -> 不 AMBIG
    R=$FH/R4N2/R4N2_run_k03_1031_150232; for s in 1 2 3 4; do mkdone $R R4N1_MC3H_h100_T350_hii_s$s; done; for s in 1 2 4; do mkdone $R R4N1_MC3_h100_T350_hii_s$s; done
    mkdir -p $R/builds/R4N1_MC3_h100_T350_hii_s3/prod/attempt_001; echo "VOID gate" > $R/builds/R4N1_MC3_h100_T350_hii_s3/prod/attempt_001/STATUS
  else for s in 1 2 3; do mkdone $FH/R4N1x/R4N1x_run_k04_1030_145916 R4N1_DOPC_h100_T350_hii_s$s; mkdone $FH/R4N1/R4N1_run_k04_1030_141353 R4N1_DOPC_h100_T320_hii_s$s; done; R=$FH/R4N2/R4N2_run_k04_1031_150301; mkdir -p $R/builds; fi
  mkdir -p $R/slots; printf 'OUT=%s\n== machine %s done 2026-10-31 18:30:00 +0800\n' $R $m > $R/orchestrator.log; touch $FH/R4N2/.R4N2_$m.flock; echo $FH; }
treesha(){ ( cd $1 && find R4N1 R4N1x R4N2 -path '*/R4N2v4_run_*' -prune -o -type f -print | grep -v '\.R4N2v4_' | sort | xargs sha256sum | sha256sum ); }
run(){ local FH=$1 m=$2; shift 2; ( cd $FH && env -i PATH=$PATH HOME=$FH MODE=local GMX_LOCAL=$FH/R4N2_pkg/R4N2/tests_rv4/mock/gmx EXPECT_GMX=2026.3 PRIO=raised GATE_PY=/bin/true \
  WAIT_POLL_S=1 WAIT_CONFIRM_S=0 MPS_DRAIN_POLL_S=1 EXTQ_POLL_S=1 GO_QUIET_S=0 "$@" bash $FH/R4N2_pkg/R4N2/run_R4N2v4.sh $m ); }
stt(){ local d; d=$(ls -1d $1/builds/$2/ext$3/attempt_* 2>/dev/null | tail -1); [ -n "$d" ] && cut -d' ' -f1 $d/STATUS || echo NONE; }
DL10="$(date -d '+10 hour' '+%F %T %z')"
# ---------- O1  (k03 分包实况: rv3 已完, rv3 树里 MC3H/MC3 C4 全 VOID 无 prod; 队列只有 DOPE)
FH=$(mkhome k03 o1); R=$FH/R4N2/R4N2_run_k03_1031_150232; for x in MC3H_h100_T350_hii_s1 MC3H_h100_T350_hii_s4 MC3_h100_T350_hii_s2 MC3_h100_T350_hii_s3; do rm -rf $R/builds/R4N1_$x; mkdir -p $R/builds/R4N1_$x/gate; echo "VOID_L2 sel 0/67" > $R/builds/R4N1_$x/gate/STATUS; done
S0=$(treesha $FH); run $FH k03 K_BRANCH=3SYS DEADLINE="$DL10" > $T/o1.log 2>&1; rc=$?; O=$(ls -1d $FH/R4N2/R4N2v4_run_k03_*)
e=""; for s in 1 2 3; do for t in 1200 2000 3000; do [ "$(stt $O R4N1_DOPE_h100_T350_hii_s$s $t)" = DONE ] || e="$e DOPE_s$s@$t"; done; for t in 1200 2000 3000; do [ "$(stt $O R4N1_DOPE_h100_T320_hii_s$s $t)" = DONE ] || e="$e C3_s$s@$t"; done; done
[ -z "$(ls -d $O/builds/R4N1_MC3* 2>/dev/null)" ] || e="$e MC3x_ran"
grep -q "src_dir=$FH/R4N1x/R4N1x_run_k03_1030_145609/" $O/builds/R4N1_DOPE_h100_T350_hii_s1/ext1200/attempt_001/EXT_SRC.txt || e="$e DOPE_s1_src"
grep -q "src_dir=$FH/R4N1/R4N1_run_k03_1030_141205/" $O/builds/R4N1_DOPE_h100_T320_hii_s2/ext1200/attempt_001/EXT_SRC.txt || e="$e C3_s2_src"
grep -q "src_kind=ext1200" $O/builds/R4N1_DOPE_h100_T350_hii_s2/ext2000/attempt_001/EXT_SRC.txt || e="$e 2000_src"
grep -q "src_kind=ext2000" $O/builds/R4N1_DOPE_h100_T350_hii_s3/ext3000/attempt_001/EXT_SRC.txt || e="$e 3000_src"
grep -q "class=prereg target_ns=1200 queue=extq_k03.txt branch=3SYS" $O/builds/R4N1_DOPE_h100_T350_hii_s2/ext1200/attempt_001/EXT_CLASS.txt && grep -q "class=explore target_ns=3000" $O/builds/R4N1_DOPE_h100_T350_hii_s2/ext3000/attempt_001/EXT_CLASS.txt || e="$e EXT_CLASS"
grep -q "== launch_guard: ALL OK" $T/o1.log && grep -q "== machine k03 done" $T/o1.log || e="$e guard/done(rc=$rc)"
[ "$S0" = "$(treesha $FH)" ] || e="$e 源树或rv3树被改"; grep -q "reason=MAIN_DONE" $O/slots/k03_A_wait.txt || e="$e reason"
[ -z "$e" ] && ok "O1 k03 3SYS 分包: 18 段 DONE (C4+C3 DOPE 1200/2000/3000), 无 MC3H/MC3, 源按行限定, 2000<-1200, 3000<-2000, EXT_CLASS, 源/rv3 树不变" || bad "O1:$e (log $T/o1.log)"
# ---------- O2  (4SYS 已废: 正式跑也被 launch_guard 拦, 不建任何 build)
FH=$(mkhome k03 o2); run $FH k03 K_BRANCH=4SYS DEADLINE="$DL10" > $T/o2.log 2>&1; rc=$?; O=$(ls -1d $FH/R4N2/R4N2v4_run_k03_* 2>/dev/null); e=""
[ $rc != 0 ] || e="$e rc=0"; grep -q "4SYS 已废止" $T/o2.log || e="$e no_msg"; [ -z "$O" ] || [ -z "$(ls $O/builds 2>/dev/null)" ] || e="$e built"
[ -z "$e" ] && ok "O2 K_BRANCH=4SYS 正式跑 -> launch_guard FAIL, 不起任何条目" || bad "O2:$e (log $T/o2.log)"
# ---------- O3
FH=$(mkhome k04 o3); run $FH k04 K_BRANCH=3SYS DEADLINE="$DL10" MOCK_FAIL_RE='DOPC_h100_T350_hii_s1/ext1200' > $T/o3.log 2>&1; O=$(ls -1d $FH/R4N2/R4N2v4_run_k04_*); e=""
[ "$(stt $O R4N1_DOPC_h100_T350_hii_s1 1200)" = FAIL ] || e="$e s1@1200=$(stt $O R4N1_DOPC_h100_T350_hii_s1 1200)"; [ -d $O/builds/R4N1_DOPC_h100_T350_hii_s1/ext2000 ] && e="$e s1@2000_dir"
grep EXT_LOWER_NOT_DONE $O/ALL_RECORDS.tsv | grep -q DOPC_h100_T350_hii_s1 || e="$e no_LOWER_NOT_DONE"; [ "$(stt $O R4N1_DOPC_h100_T350_hii_s2 2000)" = DONE ] && [ "$(stt $O R4N1_DOPC_h100_T320_hii_s3 2000)" = DONE ] || e="$e others"
[ -z "$e" ] && ok "O3 k04: DOPC s1 ext1200 FAIL -> ext2000 EXT_LOWER_NOT_DONE (不跳段); 其余 DONE" || bad "O3:$e"
# ---------- O4
FH=$(mkhome k04 o4a); run $FH k04 K_BRANCH=3SYS DEADLINE="$(date -d '+2 hour 12 min' '+%F %T %z')" > $T/o4a.log 2>&1; O=$(ls -1d $FH/R4N2/R4N2v4_run_k04_*); e=""
grep -q "class=prereg_trunc" $O/builds/R4N1_DOPC_h100_T350_hii_s1/ext1200/attempt_001/EXT_CLASS.txt 2>/dev/null || e="$e no_demote"; grep -q PREREG_NO_FULL_FIT $O/ALL_RECORDS.tsv || e="$e no_rec"
FH=$(mkhome k04 o4b); run $FH k04 K_BRANCH=3SYS DEADLINE="$(date -d '+60 min' '+%F %T %z')" > $T/o4b.log 2>&1; O=$(ls -1d $FH/R4N2/R4N2v4_run_k04_*)
[ -z "$(ls -d $O/builds/*/ext*/attempt_* 2>/dev/null)" ] || e="$e ran_short"; [ "$(grep -c SUPP_SKIP_NO_TIME $O/ALL_RECORDS.tsv)" -ge 6 ] || e="$e skips=$(grep -c SUPP_SKIP_NO_TIME $O/ALL_RECORDS.tsv)"
[ -z "$e" ] && ok "O4 剩 2.2h: prereg 放不下整段 -> prereg_trunc 照跑 (记 PREREG_NO_FULL_FIT); 剩 1.0h: 全部 SUPP_SKIP_NO_TIME 不建 attempt" || bad "O4:$e"
# ---------- O5
FH=$(mkhome k04 o5); R=$FH/R4N2/R4N2_run_k04_1031_150301; echo "OUT=$R" > $R/orchestrator.log; CNF=$T/o5_cn.txt; echo "R4N2_k04_4242_k04_A_md_x" > $CNF
( exec 9>$FH/R4N2/.R4N2_k04.flock; flock 9; sleep 12 ) & LP=$!
( sleep 8; : > $CNF; R5=$(date +%s); echo $R5 > $T/o5_release; echo "== machine k04 done" >> $R/orchestrator.log ) &
sleep 0.5; run $FH k04 K_BRANCH=3SYS DEADLINE="$DL10" FAKE_MAIN_CN_FILE=$CNF > $T/o5.log 2>&1; wait; O=$(ls -1d $FH/R4N2/R4N2v4_run_k04_*); e=""
st=$(stat -c %Y $(ls -1d $O/builds/*/ext1200/attempt_001 | head -1)); [ $st -ge $(cat $T/o5_release) ] || e="$e started_early"; grep -q "reason=MAIN_DONE" $O/slots/k04_A_wait.txt || e="$e reason=$(cat $O/slots/k04_A_wait.txt)"
grep -q "scope=machine" $O/ALL_RECORDS.tsv || e="$e scope"
[ -z "$e" ] && ok "O5 整机等待: rv3 容器在/锁被持有时不起; 容器消失 + machine done 后才起 (MAIN_DONE, scope=machine)" || bad "O5:$e"
# ---------- O6
FH=$(mkhome k04 o6); run $FH k04 K_BRANCH=3SYS DEADLINE="$DL10" > $T/o6a.log 2>&1; O=$(ls -1d $FH/R4N2/R4N2v4_run_k04_*); b=R4N1_DOPC_h100_T320_hii_s3; e=""
# 伪造中断: s3 ext2000 改成 TRUNC 且 ledger fin 删 (只在测试树); APPEND_TO 应释放并续
d=$O/builds/$b/ext2000/attempt_001; sed -i 's/^DONE/TRUNC_TIMEOUT/' $d/STATUS; printf 'step 80000000\npart 3\n' > $d/ext.cpt; rmdir $O/ledger/fin/ext2000.$b
run $FH k04 K_BRANCH=3SYS DEADLINE="$DL10" APPEND_TO=$O > $T/o6b.log 2>&1
[ -n "$(ls -d $O/ledger/released/ext2000.${b}_* 2>/dev/null)" ] || e="$e not_released"; [ "$(stt $O $b 2000)" = DONE ] || e="$e st=$(stt $O $b 2000)"
grep -q -- "-cpi $d/ext.cpt -noappend" $O/builds/$b/ext2000/attempt_002/mdrun_cmd.txt 2>/dev/null || e="$e no_resume"; [ -d $O/builds/R4N1_DOPC_h100_T350_hii_s1/ext1200/attempt_002 ] && e="$e redo_done"
[ -z "$e" ] && ok "O6 APPEND_TO: 未 fin 的领取释放到 ledger/released (不删), 从上次 ext.cpt 续到 DONE; 已 DONE 的不重跑" || bad "O6:$e"
echo "== test_orch_rv4: $([ $fails = 0 ] && echo ALL PASS || echo "$fails FAIL") (tmp=$T)"; exit $fails
