#!/bin/bash
# [rv4] 由 tests/test_ext_n2.sh 机械改写: lib_R4N2v4.sh + inputs_rv4 的 h100 build (B2=DOPC s2, B6=MC3H s3); E10 lam 臂不在 inputs_rv4 -> REFUSE_NAME 或 REFUSE_EXT_ARM 均算拒绝.
# test_ext_rv4.sh [包目录] -- box 上用 mock gmx 测 [R4N2] 续跑 (ext_src_check / ext_src / run_ext / ext_lower_busy / need_h_ext). 只写 /tmp, 不碰源树.
# 假第 1 晚树: $T/prior/R4N1_run_k03_X/builds/<b>/prod/attempt_001 {prod.tpr prod.cpt prod.log STATUS SHA256_out.txt}
# E1 正常: 源 sha 对 -> convert (dump 复核 nsteps=60000000) -> mdrun -s ext.tpr -cpi src.cpt -noappend -> DONE, ext.part0002.log, 源目录未被改
# E2 源 cpt 被改 (sha 不符) -> EXT_NO_SRC (不从头跑)   E3 无源 -> EXT_NO_SRC   E4 两个先前 run 都有 DONE -> EXT_SRC_AMBIG
# E5 源 laststep < 20M -> EXT_NO_SRC   E6 截断 -> TRUNC; 再调 -> 新 attempt 用首个 ext.tpr + 最新 ext.cpt 续 -> DONE
# E7 低一段未 DONE -> EXT_WAIT_LOWER   E8 1200 DONE 后 2000 段以本 OUT ext1200 为源 (nsteps=100000000)
# E9 convert 写错 nsteps -> EXT_TPR_BAD + HALT   E10 非 hii 臂 -> REFUSE_EXT_ARM   E11 need_h_ext 数值 (800 ns @ 珠数缩放)
# (不 set -u: run_R4N2.sh 本身不用 set -u, lib 依赖未设变量为空)
H=${1:-$(cd "$(dirname "$0")/.." && pwd)}; H=$(cd $H && pwd); T=$(mktemp -d /tmp/R4N2v4_ext_test_XXXXXX)
fails=0; ok(){ echo "PASS $*"; }; bad(){ echo "FAIL $*"; fails=$((fails+1)); }
mkprior(){ local run=$1 b=$2 ls=${3:-20000000} d; d=$T/prior/$run/builds/$b/prod/attempt_001; mkdir -p $d
  printf 'nsteps = 20000000\nbuild %s\n' $b > $d/prod.tpr; printf 'step %s\npart 1\n' $ls > $d/prod.cpt
  printf '           Step           Time\n       %s    0\nFinished mdrun\n' $ls > $d/prod.log; echo "DONE rc=0 laststep=$ls/20000000 nan=0" > $d/STATUS
  ( cd $d && sha256sum prod.tpr prod.log prod.cpt > SHA256_out.txt ); }
B1=R4N1_DOPC_h100_T350_hii_s1 B2=R4N1_DOPC_h100_T350_hii_s2 B3=R4N1_DOPC_h100_T350_hii_s3 B4=R4N1_MC3H_h100_T350_hii_s1 B5=R4N1_DOPE_h100_T350_hii_s1 B6=R4N1_MC3H_h100_T350_hii_s3
mkprior R4N1_run_k03_X $B1; mkprior R4N1_run_k03_X $B2; echo tampered >> $T/prior/R4N1_run_k03_X/builds/$B2/prod/attempt_001/prod.cpt
mkprior R4N1_run_k03_X $B4; mkprior R4N1_run_k03_Y $B4; mkprior R4N1_run_k03_X $B5 19000000; mkprior R4N1_run_k03_X $B6
SRCSHA0=$(cd $T/prior && find . -type f | sort | xargs sha256sum | sha256sum)
(
  HERE=$H MACHINE=k03 MODE=local GMX_LOCAL=$H/tests_rv4/mock/gmx X_MPS=off WAIT_MAIN=none DEADLINE="$(date -d '+10 hour' '+%F %T %z')" EXT_SRC_RUNS="$T/prior/R4N1_run_k03_*" J=$T/J PERF_OVERRIDE_FILE=$T/none
  . $H/lib_R4N2v4.sh >/dev/null 2>&1 || true
  OUT=$T/out; mkdir -p $OUT/slots $OUT/ledger; SLOT_TAG=k03_A ORCH_PID=$$ MD_RC=0
  st(){ last_state $OUT/builds/$1/ext$2; }
  run_ext $B1 1200 main 0 main >/dev/null 2>&1; d=$OUT/builds/$B1/ext1200/attempt_001
  [ "$(st $B1 1200)" = DONE ] && [ -s $d/ext.part0002.log ] && grep -q 'nsteps(dump)=60000000 期望 60000000' $d/EXT_SRC.txt && grep -q -- '-s ext.tpr -cpi src.cpt -noappend' $d/mdrun_cmd.txt && grep -q 'src_kind=prior_prod' $d/EXT_SRC.txt && grep -q ext.cpt $d/SHA256_out.txt \
    && ok "E1 400->1200: 源 sha 对, convert nsteps=60M (dump 复核), -s ext.tpr -cpi src.cpt -noappend, DONE" || bad "E1 st=$(st $B1 1200) $(cat $d/STATUS 2>/dev/null)"
  run_ext $B2 1200 main 0 main >/dev/null 2>&1; [ "$(st $B2 1200)" = EXT_NO_SRC ] && grep -q 'sha' $OUT/builds/$B2/ext1200/attempt_001/STATUS && [ ! -e $OUT/builds/$B2/ext1200/attempt_001/mdrun_cmd.txt ] && ok "E2 源 cpt 被改 -> EXT_NO_SRC (不跑)" || bad "E2 $(cat $OUT/builds/$B2/ext1200/attempt_001/STATUS)"
  run_ext $B3 1200 main 0 main >/dev/null 2>&1; [ "$(st $B3 1200)" = EXT_NO_SRC ] && ok "E3 无源 -> EXT_NO_SRC" || bad "E3 $(st $B3 1200)"
  run_ext $B4 1200 main 0 main >/dev/null 2>&1; [ "$(st $B4 1200)" = EXT_SRC_AMBIG ] && ok "E4 两个先前 run 都 DONE -> EXT_SRC_AMBIG" || bad "E4 $(st $B4 1200)"
  run_ext $B5 1200 main 0 main >/dev/null 2>&1; [ "$(st $B5 1200)" = EXT_NO_SRC ] && grep -q laststep $OUT/builds/$B5/ext1200/attempt_001/STATUS && ok "E5 源 laststep 19M<20M -> EXT_NO_SRC" || bad "E5 $(cat $OUT/builds/$B5/ext1200/attempt_001/STATUS)"
  MOCK_STOP_AT=40000000 run_ext $B6 1200 main 0 main >/dev/null 2>&1; s1=$(st $B6 1200)
  export -n MOCK_STOP_AT; run_ext $B6 1200 main 0 main >/dev/null 2>&1; d=$OUT/builds/$B6/ext1200/attempt_002
  [ "$s1" = TRUNC ] && [ "$(st $B6 1200)" = DONE ] && grep -q "attempt_001/ext.tpr -cpi .*attempt_001/ext.cpt -noappend" $d/mdrun_cmd.txt && [ -s $d/ext.part0003.log ] && ok "E6 截断 TRUNC -> 新 attempt 续 (首个 ext.tpr + 最新 ext.cpt) -> DONE (part0003)" || bad "E6 s1=$s1 s2=$(st $B6 1200)"
  mkdir -p $OUT/builds/$B5/ext2000; run_ext $B5 2000 fill 0 supp >/dev/null 2>&1; [ ! -d $OUT/builds/$B5/ext2000/attempt_001 ] && grep -q "EXT_WAIT_LOWER" $OUT/ALL_RECORDS.tsv && ok "E7 低一段 (ext1200) 未 DONE -> EXT_WAIT_LOWER, 不建 attempt" || bad "E7"
  run_ext $B1 2000 fill 0 supp >/dev/null 2>&1; d=$OUT/builds/$B1/ext2000/attempt_001
  [ "$(st $B1 2000)" = DONE ] && grep -q 'src_kind=ext1200' $d/EXT_SRC.txt && grep -q 'nsteps(dump)=100000000' $d/EXT_SRC.txt && ok "E8 1200 DONE -> 2000 以本 OUT ext1200 为源, nsteps=100M" || bad "E8 $(st $B1 2000) $(cat $d/STATUS 2>/dev/null)"
  echo "nsteps(ext_from_ns $B1 2000)=$(ext_from_ns $B1 2000) need_h_ext($B4 1200)=$(need_h_ext $B4 1200) perf_eff=$(perf_eff) atoms=$(exp_of $B4 EXP_ATOMS)"
  awk -v n=$(need_h_ext $B4 1200) -v p=$(perf_eff) -v a=$(exp_of $B4 EXP_ATOMS) -v r=$PERF_REF_BEADS -v o=$OVH_H 'BEGIN{e=800/(p*r/a)*24+o; exit !( (n-e)^2<0.01 )}' && ok "E11 need_h_ext = 800 ns/(perf*珠数缩放)*24+OVH" || bad "E11"
  exit $fails ) ; rc=$?
# E9/E10 单独 OUT
(
  HERE=$H MACHINE=k03 MODE=local GMX_LOCAL=$H/tests_rv4/mock/gmx X_MPS=off WAIT_MAIN=none DEADLINE="$(date -d '+10 hour' '+%F %T %z')" EXT_SRC_RUNS="$T/prior/R4N1_run_k03_X" J=$T/J PERF_OVERRIDE_FILE=$T/none
  . $H/lib_R4N2v4.sh >/dev/null 2>&1 || true
  OUT=$T/out2; mkdir -p $OUT/slots $OUT/ledger; SLOT_TAG=k03_B ORCH_PID=$$; f=0
  MOCK_CONVERT_BAD=1 run_ext R4N1_DOPC_h100_T350_hii_s1 1200 main 0 main >/dev/null 2>&1
  [ "$(last_state $OUT/builds/R4N1_DOPC_h100_T350_hii_s1/ext1200)" = EXT_TPR_BAD ] && [ -f $OUT/HALT ] && echo "PASS E9 convert nsteps 不符 -> EXT_TPR_BAD + HALT" || { echo "FAIL E9"; f=1; }
  run_ext R4N1_DOPE_h100_T350_lam_s2 1200 main 0 main >/dev/null 2>&1; [ $? = 9 ] && grep -qE "REFUSE_EXT_ARM|REFUSE_NAME" $OUT/ALL_RECORDS.tsv && echo "PASS E10 lam 臂 ext -> REFUSE_EXT_ARM" || { echo "FAIL E10"; f=1; }
  exit $f ); rc=$((rc+$?))
SRCSHA1=$(cd $T/prior && find . -type f | sort | xargs sha256sum | sha256sum); [ "$SRCSHA0" = "$SRCSHA1" ] && echo "PASS E0 先前 run 树逐字节未变 (只读)" || { echo "FAIL E0 源树被改"; rc=$((rc+1)); }
echo "== test_ext_rv4: $([ $rc = 0 ] && echo ALL PASS || echo "$rc FAIL") (tmp=$T)"; exit $rc
