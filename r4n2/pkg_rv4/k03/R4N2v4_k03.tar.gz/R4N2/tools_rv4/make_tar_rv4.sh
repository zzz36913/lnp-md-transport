#!/bin/bash
# [R4N2v4] 生成增量 tar (gzip): 内容 = FILES_rv4.txt 所列 + FILES_rv4.txt + MANIFEST_rv4_sha256.txt, 路径前缀 R4N2/ (解到 ~/R4N2_pkg 上, 用 tar -k).
# 用法: bash tools_rv4/make_tar_rv4.sh <输出 .tar.gz>   (先跑 make_manifest_rv4.sh)
set -e; cd "$(dirname "$0")/.."; O=${1:?out}; R=$(pwd)
sha256sum -c --quiet MANIFEST_rv4_sha256.txt
( echo FILES_rv4.txt; echo MANIFEST_rv4_sha256.txt; cat FILES_rv4.txt ) | sed 's#^#R4N2/#' > /tmp/rv4_tarlist_$$
tar -C "$(dirname $R)" --sort=name --mtime='2026-10-31 16:00:00 +0800' --owner=0 --group=0 --numeric-owner --mode='u+rwX,go+rX,go-w' -cf - -T /tmp/rv4_tarlist_$$ | gzip -9n > "$O"
rm -f /tmp/rv4_tarlist_$$; ls -l "$O"; sha256sum "$O"
