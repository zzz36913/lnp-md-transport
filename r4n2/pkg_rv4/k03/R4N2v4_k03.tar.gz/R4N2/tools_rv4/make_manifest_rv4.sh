#!/bin/bash
# [R4N2v4] 用法: bash tools_rv4/make_manifest_rv4.sh <k03|k04>  (分机分包: 只收本机的 chains_rv4/extq_<机>.txt).
# [R4N2v4] 生成 MANIFEST_rv4_sha256.txt (rv4 增量包全部文件, 不含自身) 与增量 tar 的文件清单 FILES_rv4.txt. 在包根目录 (R4N2/) 运行.
set -e; M=${1:?k03|k04}; case $M in k03) X=k04;; k04) X=k03;; *) echo bad machine; exit 1;; esac; cd "$(dirname "$0")/.."
{ ls -1 run_R4N2v4.sh lib_R4N2v4.sh VARIANT_rv4 README_rv4.md 2>/dev/null; find chains_rv4 inputs_rv4 tests_rv4 tools_rv4 -type f ! -name '*.pyc' ! -path chains_rv4/extq_$X.txt | sort; } > FILES_rv4.txt
xargs sha256sum < FILES_rv4.txt > MANIFEST_rv4_sha256.txt
echo "FILES_rv4.txt ($M): $(wc -l < FILES_rv4.txt) 个; MANIFEST_rv4_sha256.txt 写好"
