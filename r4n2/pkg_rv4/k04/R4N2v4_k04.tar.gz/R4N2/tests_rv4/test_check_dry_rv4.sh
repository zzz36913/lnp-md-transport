#!/bin/bash
# test_check_dry_rv4.sh [包目录] -- box 上 CHECK / DRY / 装包 自检 (MODE=local, mock gmx, 假 $HOME 树); 只写 /tmp.
#  C1 k03/k04 3SYS: CHECK 全 OK (rc=0); k03 另测 rv3 已完 (done 行在, 即 15:20 后实况)
#  C2 负自检 (每条须 FAIL, rc!=0): K_BRANCH 未设 / K_BRANCH=5SYS / K_BRANCH=4SYS (15:28 废止) / 冻结文件被改 / rv4 文件被改 / ONLY 设了 / DEADLINE 晚于 07:30 上限 /
#     NSTEPS_OVERRIDE_PROD 覆盖 / 第 5 列源目录不存在 / 队列跨机重复
#  D1 DRY k03 3SYS (起点 16:45) / k04 3SYS (起点估 19:30): rc=0, 打印队列表 + 3 情景 (模型 / 实测 MPS / 无 MPS) 两槽模拟, 起点 = rv3 本机预计完
#  I2 k03 分包装好后在解出的真包树里跑 CHECK k03 -> ALL OK; CHECK k04 -> FAIL (分包不含 extq_k04)
#  I1 增量 tar 按 tar -k 解到 rv3 底包上: 无路径冲突 (rv3 文件一个不覆盖), 解后 rv3 MANIFEST / FROZEN / rv4 MANIFEST 全过
H=${1:-$(cd "$(dirname "$0")/.." && pwd)}; H=$(cd $H && pwd); T=$(mktemp -d /tmp/R4N2v4_chk_XXXXXX); fails=0
ok(){ echo "PASS $*"; }; bad(){ echo "FAIL $*"; fails=$((fails+1)); }
mkdone(){ local d=$1/builds/$2/prod/attempt_001; mkdir -p $d; printf 'nsteps = 20000000\nbuild %s\n' $2 > $d/prod.tpr; printf 'step 20000000\n' > $d/prod.cpt
  printf '           Step           Time\n       20000000    0\nFinished mdrun\n' > $d/prod.log; echo "DONE rc=0 laststep=20000000/20000000 nan=0" > $d/STATUS; ( cd $d && sha256sum prod.tpr prod.log prod.cpt > SHA256_out.txt ); }
mkhome(){ local m=$1; local FH=$T/$2/home/$m; mkdir -p $FH/R4N2_pkg $FH/R4N1x $FH/R4N1 $FH/R4N2; cp -a $H $FH/R4N2_pkg/R4N2
  if [ $m = k03 ]; then for s in 1 2 3; do mkdone $FH/R4N1x/R4N1x_run_k03_1030_145609 R4N1_DOPE_h100_T350_hii_s$s; mkdone $FH/R4N1/R4N1_run_k03_1030_141205 R4N1_DOPE_h100_T320_hii_s$s; done
    R=$FH/R4N2/R4N2_run_k03_1031_150232; mkdir -p $R/builds
  else for s in 1 2 3; do mkdone $FH/R4N1x/R4N1x_run_k04_1030_145916 R4N1_DOPC_h100_T350_hii_s$s; mkdone $FH/R4N1/R4N1_run_k04_1030_141353 R4N1_DOPC_h100_T320_hii_s$s; done
    R=$FH/R4N2/R4N2_run_k04_1031_150301; mkdir -p $R/builds; fi
  mkdir -p $R/slots; echo "OUT=$R" > $R/orchestrator.log; echo $FH; }   # rv3 仍在跑 (无 done 行): CHECK/DRY 必须照样能过
run(){ local FH=$1 m=$2; shift 2; ( cd $FH/R4N2_pkg/R4N2 && env -i PATH=$PATH HOME=$FH MODE=local GMX_LOCAL=$FH/R4N2_pkg/R4N2/tests_rv4/mock/gmx EXPECT_GMX=2026.3 PRIO=raised \
  GATE_PY=$FH/R4N2_pkg/R4N2/gatewrap/gate_py_container.sh DEADLINE="2026-11-01 07:30 +0800" "$@" bash run_R4N2v4.sh $m ); }
NOWDL=$( [ $(date +%s) -lt $(date -d '2026-11-01 07:30 +0800' +%s) ] && echo real || echo past )
DLX=(); [ $NOWDL = past ] && DLX=(DEADLINE_CAP="$(date -d '+20 hour' '+%F %T %z')" DEADLINE="$(date -d '+14 hour' '+%F %T %z')")   # box 时钟过了 07:30 时 (事后复跑) 平移
# ---------- C1
for m in k03 k03done k04; do for br in 3SYS; do FH=$(mkhome ${m%done} c1_${m}_$br); L=c1_${m}_$br; [ $m = k03done ] && { m=k03; echo '== machine k03 done 2026-10-31 15:20:00 +0800' >> $FH/R4N2/R4N2_run_k03_1031_150232/orchestrator.log; }; run $FH $m K_BRANCH=$br "${DLX[@]}" CHECK=1 > $T/$L.log 2>&1; rc=$?
  [ $rc = 0 ] && grep -q "== launch_guard: ALL OK" $T/$L.log && ok "C1 CHECK $L ALL OK" || bad "C1 CHECK $L rc=$rc (log $T/$L.log)"; done; done
# ---------- C2
neg(){ local name=$1 m=$2 prep=$3; shift 3; local FH; FH=$(mkhome $m c2_$name); ( cd $FH/R4N2_pkg/R4N2 && HOME=$FH && eval "$prep" ); run $FH $m "${DLX[@]}" CHECK=1 "$@" > $T/c2_$name.log 2>&1; local rc=$?
  [ $rc != 0 ] && grep -q "FAIL" $T/c2_$name.log && ok "C2 $name -> FAIL (rc=$rc): $(grep FAIL $T/c2_$name.log | grep -v 'launch_guard: FAIL' | cut -c1-90 | tr '\n' '|')" || bad "C2 $name 未 FAIL (rc=$rc, log $T/c2_$name.log)"; }
neg nobranch k03 ":"
neg badbranch k04 ":" K_BRANCH=5SYS
neg branch4sys k03 ":" K_BRANCH=4SYS
neg frozen k04 "chmod u+w PREREG_R4_3day.md; echo x >> PREREG_R4_3day.md" K_BRANCH=3SYS
neg rv4file k03 "echo '# x' >> lib_R4N2v4.sh" K_BRANCH=3SYS
neg only k03 ":" K_BRANCH=3SYS ONLY=C4
neg latedl k04 ":" K_BRANCH=3SYS DEADLINE="2026-11-01 08:30 +0800"
neg nsteps k04 ":" K_BRANCH=3SYS NSTEPS_OVERRIDE_PROD=1000
neg nosrcdir k04 "mv \$HOME/R4N1x/R4N1x_run_k04_1030_145916 \$HOME/R4N1x/moved" K_BRANCH=3SYS
neg xdup k04 "chmod u+w chains_rv4/extq_k04.txt; echo 'R4N1_DOPE_h100_T350_hii_s1:1200:prereg:prior' >> chains_rv4/extq_k04.txt; (cd \$HOME/R4N2_pkg/R4N2 && bash tools_rv4/make_manifest_rv4.sh k04 >/dev/null)" K_BRANCH=3SYS
# ---------- D1  (起点估算: k03 16:45 (rv3 15:20 已完), k04 19:30 (rv3 lam 预计完))
for x in "k03 3SYS 2026-10-31_16:45" "k04 3SYS 2026-10-31_19:30"; do set -- $x; FH=$(mkhome $1 d1_$1_$2)
  run $FH $1 K_BRANCH=$2 "${DLX[@]}" DRY=1 SIM_START="${3/_/ } +0800" SIM_PERFS="14258:模型 16900:实测MPS 4600:无MPS" > $T/d1_$1_$2.log 2>&1; rc=$?
  n=$(grep -c "情景" $T/d1_$1_$2.log); [ $rc = 0 ] && [ "$n" = 3 ] && ok "D1 DRY $1 $2 rc=0, 3 情景 (log $T/d1_$1_$2.log)" || bad "D1 DRY $1 $2 rc=$rc 情景=$n (log $T/d1_$1_$2.log)"; done
# ---------- I1
TAR=${RV4_TAR:-}; if [ -z "$TAR" ] && [ -f $H/../R4N2v4_incr.tar.gz ]; then TAR=$H/../R4N2v4_incr.tar.gz; fi
RV3=${RV3_TAR:-$H/../../../pkg/R4N2_rv3.tar}
if [ -n "$TAR" ] && [ -f "$TAR" ] && [ -f "$RV3" ]; then I=$T/i1; mkdir -p $I; tar -C $I -xf $RV3; S0=$(cd $I/R4N2 && find . -type f | sort | xargs sha256sum | sha256sum)
  col=$(tar tzf $TAR | grep -v '/$' | while read f; do [ -e $I/$f ] && echo $f; done); tar -C $I -k -xzf $TAR 2>$T/i1.err; trc=$?
  e=""; [ -z "$col" ] || e="$e 冲突:$col"; [ $trc = 0 ] || e="$e tar_rc=$trc"
  ( cd $I/R4N2 && sha256sum -c --quiet MANIFEST_sha256.txt && sha256sum -c --quiet FROZEN_sha256.txt && sha256sum -c --quiet MANIFEST_rv4_sha256.txt ) >/dev/null 2>&1 || e="$e manifest"
  S1=$(cd $I/R4N2 && tar tzf $TAR | sed -n 's#^R4N2/#./#p' | grep -v '/$' > $T/new.txt; find . -type f | grep -vxF -f $T/new.txt | sort | xargs sha256sum | sha256sum)
  [ "$S0" = "$S1" ] || e="$e rv3文件变了"
  [ -z "$e" ] && ok "I1 tar -k 装到 rv3 底包: 0 冲突, rv3 文件逐字节不变, 3 份 MANIFEST/FROZEN 全过 ($(tar tzf $TAR | grep -vc '/$') 个新文件)" || bad "I1:$e"
  # I2: 真包树 (rv3 底包 + 本分包) 上跑 CHECK
  PM=$(tar xzOf $TAR R4N2/FILES_rv4.txt | sed -n 's#^chains_rv4/extq_\(k0[34]\)\.txt$#\1#p'); OM=$([ "$PM" = k03 ] && echo k04 || echo k03)
  FH=$(mkhome $PM i2_$PM); rm -rf $FH/R4N2_pkg/R4N2; cp -a $I/R4N2 $FH/R4N2_pkg/R4N2; run $FH $PM K_BRANCH=3SYS "${DLX[@]}" CHECK=1 > $T/i2_ok.log 2>&1; r1=$?
  FH=$(mkhome $OM i2_$OM); rm -rf $FH/R4N2_pkg/R4N2; cp -a $I/R4N2 $FH/R4N2_pkg/R4N2; run $FH $OM K_BRANCH=3SYS "${DLX[@]}" CHECK=1 > $T/i2_other.log 2>&1; r2=$?
  [ $r1 = 0 ] && grep -q 'launch_guard: ALL OK' $T/i2_ok.log && [ $r2 != 0 ] && grep -q '缺队列' $T/i2_other.log && ok "I2 分包=$PM: 真包树 CHECK $PM ALL OK; CHECK $OM FAIL (缺队列)" || bad "I2 分包=$PM r1=$r1 r2=$r2 (logs $T/i2_*.log)"
else echo "SKIP I1 (无 tar: RV4_TAR=$TAR RV3_TAR=$RV3)"; fi
[ $fails = 0 ] && echo "== test_check_dry_rv4: ALL PASS (tmp=$T)" || echo "== test_check_dry_rv4: $fails FAIL (tmp=$T)"; exit $fails
