#!/bin/bash
# test_mps_n2.sh -- box 上用 mock nvidia-cuda-mps-control 测 [R4N2] MPS 修复 (x_mps_pick / x_mps_alive / x_mps_stop). 只写 /tmp; 只杀 mock 自己起的 sleep.
# 场景 (X_MPS_MAX_START=2): T1 首次起 own_started; T2 env 在且活 -> own (不重起); T3 守护被杀 (=10-30 事故) -> env 改名 dead_ + own_restarted;
#       T4 守护在但 get_server_list 不通 (挂死) -> 对自己 pipe 发 quit, 超预算 none_dead_budget; T5 stop -> env 改名 stopped_, quit 已发, 再 pick 不会 own (APPEND_TO 不复用)
#       T6 -d 失败 -> none_start_fail; T7 起后验活不过 (进程没起) -> none_start_fail + 对该 pipe 发 quit; T8 机上有别的 MPS 进程 -> none_mps_present
set -u
H=$(cd "$(dirname "$0")/.." && pwd); T=$(mktemp -d /tmp/R4N2_mps_test_XXXXXX); export MOCK_DIR=$T/mock; mkdir -p $MOCK_DIR
export PATH=$H/tests/mock:$PATH HOME_SAVE=$HOME
fails=0; ok(){ echo "PASS $*"; }; bad(){ echo "FAIL $*"; fails=$((fails+1)); }
killmock(){ for p in $(pgrep -f '^nvidia-cuda-mps-control 3600'); do e=$(tr '\0' '\n' < /proc/$p/environ 2>/dev/null | sed -n 's/^CUDA_MPS_PIPE_DIRECTORY=//p'); case "$e" in $T/*) kill $p;; esac; done; }
trap killmock EXIT
newout(){ OUT=$T/out_$1; mkdir -p $OUT/slots $OUT/ledger; }
(  # 子 shell 里 source lib (MODE=local + X_MPS_TEST=1 才走 MPS 逻辑)
  MACHINE=k03 MODE=local X_MPS_TEST=1 X_MPS=auto X_MPS_MAX_START=2 WAIT_MAIN=none X_MPS_ROOT_BASE=$T/roots X_MPS_START_WAIT_S=1 X_MPS_STOP_WAIT_S=1 HERE=$H
  . $H/lib_R4N2.sh >/dev/null 2>&1 || true
  SLOT_TAG=k03_A
  newout 1
  XB=b1; x_mps_pick; [ "$X_MPS_NOTE" = own_started ] && [ -f $OUT/slots/x_mps.env ] && [ -n "$MPSARGS" ] && ok "T1 own_started ($X_MPS_WHY)" || bad "T1 got $X_MPS_NOTE $X_MPS_WHY"
  P1=$(sed -n 's/^MPSPIPE=//p' $OUT/slots/x_mps.env)
  XB=b2; x_mps_pick; [ "$X_MPS_NOTE" = own ] && [ "$(wc -l < $MOCK_DIR/start.log)" = 1 ] && ok "T2 env+活 -> own, 不重起" || bad "T2 got $X_MPS_NOTE"
  for p in $(pgrep -f '^nvidia-cuda-mps-control 3600'); do kill $p; done; sleep 0.3   # 模拟守护被前一段收尾 quit 掉
  XB=b3; x_mps_pick; P2=$(sed -n 's/^MPSPIPE=//p' $OUT/slots/x_mps.env 2>/dev/null)
  [ "$X_MPS_NOTE" = own_restarted ] && ls $OUT/slots/x_mps.env.dead_* >/dev/null 2>&1 && [ "$P2" != "$P1" ] && grep -q 'own_restarted' $OUT/slots/x_mps_events.log && ok "T3 守护死 -> 旧 env 改名 dead_, 新 pipe own_restarted ($P2)" || bad "T3 got $X_MPS_NOTE P1=$P1 P2=$P2"
  touch $MOCK_DIR/gsl_fail; XB=b4; x_mps_pick; [ "$X_MPS_NOTE" = none_dead_budget ] && [ -z "$MPSARGS" ] && [ ! -f $OUT/slots/x_mps.env ] && grep -q "quit $P2" $MOCK_DIR/quit.log && grep -q dead_own_quit $OUT/slots/x_mps_events.log && ok "T4 守护在但 pipe 不通 (挂死) -> 对自己 pipe 发 quit, 已起 2 次 (=上限) -> none_dead_budget, MPSARGS 空" || bad "T4 got $X_MPS_NOTE args=$MPSARGS"
  rm -f $MOCK_DIR/gsl_fail; killmock; sleep 0.3
  newout 5; XB=b5; x_mps_pick; [ "$X_MPS_NOTE" = own_started ] || bad "T5 pre got $X_MPS_NOTE"; P5=$(sed -n 's/^MPSPIPE=//p' $OUT/slots/x_mps.env)
  x_mps_stop >/dev/null; [ ! -f $OUT/slots/x_mps.env ] && ls $OUT/slots/x_mps.env.stopped_* >/dev/null 2>&1 && grep -q "quit $P5" $MOCK_DIR/quit.log && ok "T5 stop -> quit 已发, env 改名 stopped_" || bad "T5 stop"
  XB=b5b; x_mps_pick; [ "$X_MPS_NOTE" = own_restarted ] && [ "$(sed -n 's/^MPSPIPE=//p' $OUT/slots/x_mps.env)" != "$P5" ] && ok "T5b stop 后再 pick (APPEND_TO 情形) 不复用旧 pipe, 起新的" || bad "T5b got $X_MPS_NOTE"
  x_mps_stop >/dev/null; killmock; sleep 0.3
  newout 6; touch $MOCK_DIR/start_fail; XB=b6; x_mps_pick; rm -f $MOCK_DIR/start_fail; [ "$X_MPS_NOTE" = none_start_fail ] && [ -z "$MPSARGS" ] && ok "T6 -d 失败 -> none_start_fail" || bad "T6 got $X_MPS_NOTE"
  sleep 1.1; newout 7; touch $MOCK_DIR/start_dead; XB=b7; : > $MOCK_DIR/quit.log; x_mps_pick; rm -f $MOCK_DIR/start_dead
  [ "$X_MPS_NOTE" = none_start_fail ] && [ -s $MOCK_DIR/quit.log ] && [ ! -f $OUT/slots/x_mps.env ] && ok "T7 起后验活不过 -> none_start_fail, 已对该 pipe 发 quit, 不写 env" || bad "T7 got $X_MPS_NOTE"
  newout 8; ( exec -a nvidia-cuda-mps-server sleep 30 ) & SP=$!; sleep 0.3; XB=b8; x_mps_pick; kill $SP 2>/dev/null
  [ "$X_MPS_NOTE" = none_mps_present ] && ls $OUT/slots/x_mps_residue_* >/dev/null 2>&1 && ok "T8 机上有别的 MPS 进程 -> none_mps_present + 认人文件 (不 quit/不 kill)" || bad "T8 got $X_MPS_NOTE"
  newout 9; X_MPS=off; XB=b9; x_mps_pick; [ "$X_MPS_NOTE" = off ] && ok "T9 X_MPS=off" || bad "T9"
  echo "events log 示例:"; cat $T/out_1/slots/x_mps_events.log
  exit $fails ); rc=$?
killmock; echo "== test_mps_n2: $([ $rc = 0 ] && echo ALL PASS || echo "$rc FAIL") (tmp=$T)"; exit $rc
