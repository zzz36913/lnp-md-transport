#!/usr/bin/env python3
"""tests/test_verdict_Larm.py -- verdict_Larm.py 合成数据单元测试 (零算力). 运行: python3 tests/test_verdict_Larm.py"""
import csv, json, os, subprocess, sys, tempfile, unittest
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE); sys.path.insert(0, ROOT); sys.path.insert(0, HERE)
import verdict_R4_3day as V, verdict_Larm as VL
from test_verdict import frames, write
COLS = V.STATUS_COLS
KIND = {'RET': lambda t: 'HII', 'LOST': lambda t: 'HII' if t < 100 else 'LAM', 'LATE': lambda t: 'HII' if t <= 450 else 'LAM'}
def mk(d, tag, spec, T=400.0):
    """spec: {(prim, arm): [kind per seed s1..]} ; kind TRUNC = 300 ns RET; VOID = VOID_L2"""
    rows = []
    for key, ks in spec.items():
        p, arm, w = (key + ('h050',))[:3]
        for i, k in enumerate(ks, 1):
            b = 'R4N1_%s_%s_T320_%s_s%d' % (p, w, arm, i); r = dict(build=b, prim=p, w=w, T='T320', arm=arm, seed=i, start='PASS', prod='DONE', prod_attempts='DONE', sha_check='OK', xtc='x', roots='r', note='-')
            if k == 'VOID': r.update(start='VOID_L2', series='-')
            else:
                cs = os.path.join(d, b + '.csv'); write(cs, frames(T=300 if k == 'TRUNC' else T, f=KIND['RET' if k == 'TRUNC' else k])); r['series'] = cs
            rows.append(r)
    p = os.path.join(d, tag + '.tsv')
    with open(p, 'w') as f:
        f.write('\t'.join(COLS) + '\n'); [f.write('\t'.join(str(r.get(c, '-')) for c in COLS) + '\n') for r in rows]
    return p
def run(long_spec, short_spec, TL=400.0, TS=400.0, short_inputs=None):
    d = tempfile.mkdtemp(); o = os.path.join(d, 'outL'); os.makedirs(o)
    os.replace(mk(d, 'L', long_spec, TL), os.path.join(o, 'runs_status_Larm.tsv')); s = mk(d, 'S', short_spec, TS)
    cmd = [sys.executable, os.path.join(ROOT, 'verdict_Larm.py'), 'judge', o, '--short-status', s] + (['--short-inputs', short_inputs] if short_inputs else [])
    p = subprocess.run(cmd, capture_output=True, text=True); assert p.returncode == 0, p.stderr
    return json.load(open(os.path.join(o, 'VERDICT_Larm.json')))
R3 = ['RET'] * 3; L3 = ['LOST'] * 3
class T(unittest.TestCase):
    def test_artifact(self):
        v = run({('DOPE', 'hiiL'): R3, ('DOPC', 'hiiL'): L3}, {('DOPE', 'hii'): R3, ('DOPC', 'hii'): R3})
        self.assertEqual(v['decisive']['DOPC_reading'], 'SHORT_BOX_ARTIFACT'); self.assertEqual(v['by_horizon']['max']['DOPE_long_positive'], 'POS_OK')
        self.assertEqual(v['by_horizon']['max']['long_ruler_rule12'], 'PASS')
    def test_artifact_boundary_2of3(self):
        v = run({('DOPE', 'hiiL'): R3, ('DOPC', 'hiiL'): ['LOST', 'LOST', 'RET']}, {('DOPE', 'hii'): R3, ('DOPC', 'hii'): ['LOST', 'RET', 'RET']})
        self.assertEqual(v['decisive']['DOPC_reading'], 'SHORT_BOX_ARTIFACT')
        self.assertEqual(v['by_horizon']['max']['long_ruler_rule12'], 'FAIL')   # 长盒 DOPC 有 1 RETAIN -> 规则 2 (RETAIN 0/3) 不过; 不放宽
    def test_consistent_lost(self):
        self.assertEqual(run({('DOPE', 'hiiL'): R3, ('DOPC', 'hiiL'): L3}, {('DOPE', 'hii'): R3, ('DOPC', 'hii'): L3})['decisive']['DOPC_reading'], 'CONSISTENT_LOST')
    def test_consistent_retain(self):
        self.assertEqual(run({('DOPE', 'hiiL'): R3, ('DOPC', 'hiiL'): R3}, {('DOPE', 'hii'): R3, ('DOPC', 'hii'): R3})['decisive']['DOPC_reading'], 'CONSISTENT_RETAIN')
    def test_reverse(self):
        self.assertEqual(run({('DOPE', 'hiiL'): R3, ('DOPC', 'hiiL'): R3}, {('DOPE', 'hii'): R3, ('DOPC', 'hii'): L3})['decisive']['DOPC_reading'], 'LONG_BOX_RETAINS_MORE')
    def test_not_evaluable_trunc(self):
        v = run({('DOPE', 'hiiL'): R3, ('DOPC', 'hiiL'): ['LOST', 'LOST', 'TRUNC']}, {('DOPE', 'hii'): R3, ('DOPC', 'hii'): R3})
        self.assertEqual(v['decisive']['DOPC_reading'], 'NOT_EVALUABLE'); self.assertIsNone(v['H_cmp_ns'])
    def test_spare_replaces_void(self):
        v = run({('DOPE', 'hiiL'): R3, ('DOPC', 'hiiL'): ['LOST', 'VOID', 'LOST', 'LOST']}, {('DOPE', 'hii'): R3, ('DOPC', 'hii'): R3})
        self.assertEqual(v['decisive']['DOPC_reading'], 'SHORT_BOX_ARTIFACT')
    def test_common_horizon(self):   # 长盒跑到 600 ns, 450 ns 后才丢管; 短盒 400 ns RETAIN -> 比较截到 H_cmp=400 -> CONSISTENT_RETAIN (max 窗是 ARTIFACT 但只描述)
        v = run({('DOPE', 'hiiL'): R3, ('DOPC', 'hiiL'): ['LATE'] * 3}, {('DOPE', 'hii'): R3, ('DOPC', 'hii'): R3}, TL=600.0)
        self.assertEqual(v['H_cmp_ns'], 400); self.assertEqual(v['decisive']['DOPC_reading'], 'CONSISTENT_RETAIN'); self.assertEqual(v['by_horizon']['max']['DOPC_reading'], 'SHORT_BOX_ARTIFACT')
    def test_scope(self):
        d = tempfile.mkdtemp()
        for b, g in (('R4N1_DOPC_h050_T320_hii_s1', '{"Lz":10.97,"r_water":1.8396}'), ('R4N1_DOPE_h050_T320_hii_s1', '{"Lz":19.09,"r_water":0.9505}')):
            os.makedirs(os.path.join(d, b)); open(os.path.join(d, b, 'SYSTEM.txt'), 'w').write('%s geom=%s start_box=1x1x1\n' % (b, g))
        v = run({('DOPE', 'hiiL'): R3, ('DOPC', 'hiiL'): L3}, {('DOPE', 'hii'): R3[:1], ('DOPC', 'hii'): R3[:1]}, short_inputs=d)
        self.assertEqual(v['downgraded_if_artifact'], ['DOPC_h050_T320'])
    def test_scope_h100_not_covered(self):   # [REVIEW v3] h100 短盒 (比值 0.28) 不被 h050 的 L 臂 "放行"
        d = tempfile.mkdtemp()
        for b, g in (('R4N1_DOPC_h050_T320_hii_s1', '{"Lz":10.97,"r_water":1.8396}'), ('R4N1_DOPC_h100_T320_hii_s1', '{"Lz":6.16,"r_water":3.4718}'), ('R4N1_DOPE_h100_T320_hii_s1', '{"Lz":11.61,"r_water":1.7237}')):
            os.makedirs(os.path.join(d, b)); open(os.path.join(d, b, 'SYSTEM.txt'), 'w').write('%s geom=%s start_box=1x1x1\n' % (b, g))
        v = run({('DOPE', 'hiiL'): R3, ('DOPC', 'hiiL'): R3}, {('DOPE', 'hii'): R3, ('DOPC', 'hii'): R3, ('DOPC', 'hii', 'h100'): R3[:1], ('DOPE', 'hii', 'h100'): R3[:1]}, short_inputs=d)
        self.assertEqual(v['decisive']['DOPC_reading'], 'CONSISTENT_RETAIN')
        self.assertEqual(v['downgraded_if_artifact'], ['DOPC_h050_T320', 'DOPC_h100_T320']); self.assertEqual(v['not_covered_by_Larm'], ['DOPC_h100_T320'])
    def test_frozen_untouched_and_name(self):
        self.assertIsNotNone(VL.NAME_L.match('R4N1_DOPC_h050_T320_hiiL_s4')); self.assertIsNone(V.NAME.match('R4N1_DOPC_h050_T320_hiiL_s4'))
        fz = {l.split()[1].lstrip('*'): l.split()[0] for l in open(os.path.join(ROOT, 'FROZEN_sha256.txt'))} if os.path.exists(os.path.join(ROOT, 'FROZEN_sha256.txt')) else {}
        if 'verdict_R4_3day.py' in fz: self.assertEqual(V.sha256(os.path.join(ROOT, 'verdict_R4_3day.py')), fz['verdict_R4_3day.py'])
if __name__ == '__main__': unittest.main(verbosity=1)
