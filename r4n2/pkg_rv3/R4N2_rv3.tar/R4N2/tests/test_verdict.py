#!/usr/bin/env python3
"""tests/test_verdict.py -- verdict_R4_3day.py 的合成数据单元测试 (零算力). 运行: python3 tests/test_verdict.py"""
import csv, json, os, subprocess, sys, tempfile, unittest
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE); sys.path.insert(0, ROOT)
import verdict_R4_3day as V
D1V2 = os.environ.get('D1V2_LAM', '/workspace/lnp-md/scan/R4_recipe/D1v2_results_pull/results_xtc_prereg/runs.tsv')
COLS = ['t_ns', 'Lx', 'Ly', 'Lz', 'ncl', 'wind', 'npol', 'wpol', 'n_tube', 'Cx', 'Cy', 'Cz', 'C_max', 'cls', 'tube_sizes', 'v1_agree']

def frames(T=400, step=1.0, f=lambda t: 'HII', cmax=0.8, t0=0.0):
    out = []; n = int(round(T / step))
    for i in range(n + 1):
        t = t0 + i * step; k = f(t - t0)
        if k == 'HII': d = dict(ncl=1, wind=3, wpol=1, n_tube=4, Cz=0.2, C_max=0.79)
        elif k == 'LAM': d = dict(ncl=2, wind=2, wpol=2, n_tube=0, Cz=0.9, C_max=cmax)
        elif k == 'NET': d = dict(ncl=1, wind=3, wpol=3, n_tube=0, Cz=0.1, C_max=0.2)
        elif k == 'DISC': d = dict(ncl=1, wind=3, wpol=0, n_tube=0, Cz=0.1, C_max=0.2)
        elif k == 'LAMSTACK': d = dict(ncl=2, wind=2, wpol=2, n_tube=0, Cz=0.95, C_max=0.95)
        elif k == 'LAMEV': d = dict(ncl=1, wind=3, wpol=1, n_tube=0, Cz=0.3, C_max=0.4)
        elif k == 'LAMMERGE': d = dict(ncl=1, wind=2, wpol=2, n_tube=0, Cz=0.9, C_max=0.9)
        d.update(t_ns=t, Lx=9, Ly=8, Lz=7, npol=3, Cx=0, Cy=0, cls=k, tube_sizes='', v1_agree=''); out.append(d)
    return out

def write(path, fr):
    with open(path, 'w') as fh:
        w = csv.DictWriter(fh, COLS); w.writeheader(); [w.writerow(x) for x in fr]

def rows(fr): return [dict(t=x['t_ns'], ncl=x['ncl'], wind=x['wind'], wpol=x['wpol'], n_tube=x['n_tube'], Cz=x['Cz'], C_max=x['C_max']) for x in fr]

class RunLevel(unittest.TestCase):
    def test_retain(self): self.assertEqual(V.judge_hii_run(rows(frames()))['status'], 'RETAIN')
    def test_lost_lamreturn_tloss(self):
        r = V.judge_hii_run(rows(frames(f=lambda t: 'HII' if t < 100 else 'LAM', cmax=0.8)))
        self.assertEqual((r['status'], r['sub'], r['t_loss_ns']), ('LOST', 'LAM_RETURN', 100.0))
    def test_lost_lamlowc(self):
        r = V.judge_hii_run(rows(frames(f=lambda t: 'HII' if t < 100 else 'LAM', cmax=0.3))); self.assertEqual((r['status'], r['sub']), ('LOST', 'LAM_LOWC'))
    def test_lost_net(self):
        r = V.judge_hii_run(rows(frames(f=lambda t: 'HII' if t < 50 else ('NET' if int(t) % 3 else 'DISC')))); self.assertEqual((r['status'], r['sub']), ('LOST', 'NET'))
    def test_partial(self): self.assertEqual(V.judge_hii_run(rows(frames(f=lambda t: 'HII' if int(t) % 2 else 'LAM')))['status'], 'PARTIAL')
    def test_boundary(self):   # 窗 = t>=300 共 101 帧; 81 帧 HII -> 0.802 RETAIN; 80 帧 -> 0.792 PARTIAL; 20 帧 -> 0.198 LOST; 21 -> PARTIAL
        for nh, exp in ((81, 'RETAIN'), (80, 'PARTIAL'), (20, 'LOST'), (21, 'PARTIAL')):
            self.assertEqual(V.judge_hii_run(rows(frames(f=lambda t, nh=nh: 'HII' if (t < 300 or t >= 400 - nh + 1) else 'LAM')))['status'], exp, nh)
    def test_trunc(self): self.assertEqual(V.judge_hii_run(rows(frames(T=300)))['status'], 'TRUNC')
    def test_window_incomplete(self): self.assertEqual(V.judge_hii_run(rows(frames(step=2.0)))['status'], 'WINDOW_INCOMPLETE')
    def test_horizon_and_t0shift(self):
        fr = frames(T=600, t0=1000.0, f=lambda t: 'HII' if t <= 400 else 'LAM')
        p = tempfile.mktemp(suffix='.csv'); write(p, fr)
        self.assertEqual(V.judge_hii_run(V.read_series(p, 400.0))['status'], 'RETAIN')
        self.assertEqual(V.judge_hii_run(V.read_series(p, None))['status'], 'LOST')
    def test_lam(self):
        self.assertEqual(V.judge_lam_run(rows(frames(f=lambda t: 'LAMSTACK')))['status'], 'NO_EVENT')
        r = V.judge_lam_run(rows(frames(f=lambda t: 'LAMEV' if 50 <= t <= 75 else 'LAMSTACK'))); self.assertEqual((r['status'], r['t_event_ns']), ('EVENT', 50.0))
        self.assertEqual(V.judge_lam_run(rows(frames(f=lambda t: 'LAMEV' if 50 <= t <= 65 else 'LAMSTACK')))['status'], 'NO_EVENT')   # 15 ns < 20
        self.assertEqual(V.judge_lam_run(rows(frames(T=200, f=lambda t: 'LAMSTACK')))['status'], 'TRUNC')
        self.assertEqual(V.judge_lam_run(rows(frames(T=200, f=lambda t: 'LAMEV' if t >= 100 else 'LAMSTACK')))['status'], 'EVENT')
        r = V.judge_lam_run(rows(frames(f=lambda t: 'LAMMERGE' if t >= 300 else 'LAMSTACK'))); self.assertEqual((r['status'], r['t_merge_ns']), ('NO_EVENT', 300.0))

SPEC_PASS = {  # (prim, T, arm) -> per seed kind ; 'VOID' = start VOID_BUILD
    ('DOPE', 'T320', 'hii'): ['RET', 'RET', 'LOSTL', 'RET'], ('DOPC', 'T320', 'hii'): ['LOSTL', 'VOID', 'LOSTL', 'LOSTL'],
    ('MC3H', 'T320', 'hii'): ['RET', 'RET', 'LOSTL', 'RET'], ('MC3', 'T320', 'hii'): ['VOID', 'VOID', 'VOID', 'VOID']}
KIND = {'RET': lambda t: 'HII', 'LOSTL': lambda t: 'HII' if t < 100 else 'LAM', 'LAMNO': lambda t: 'LAMSTACK', 'LAMEV': lambda t: 'LAMEV' if t > 100 else 'LAMSTACK',
        'LATELOSS': lambda t: 'HII' if t <= 400 else 'LAM'}

def build_status(tmp, spec, w='h050', T_ns=400):
    sd = os.path.join(tmp, 'series'); os.makedirs(sd, exist_ok=True); out = []
    for (p, T, arm), kinds in spec.items():
        for i, k in enumerate(kinds, 1):
            b = 'R4N1_%s_%s_%s_%s_s%d' % (p, w, T, arm, i); st = dict(build=b, prim=p, w=w, T=T, arm=arm, seed=str(i), start='PASS', prod='DONE', sha_check='OK', series='-')
            if k == 'VOID': st['start'] = 'VOID_BUILD'; st['prod'] = 'NONE'
            elif k == 'NOTRUN': st['start'] = 'NOT_RUN'; st['prod'] = 'NONE'
            elif k == 'TRUNC': st['prod'] = 'TRUNC'; c = os.path.join(sd, b + '.csv'); write(c, frames(T=250)); st['series'] = c
            else: c = os.path.join(sd, b + '.csv'); write(c, frames(T=(600 if k == 'LATELOSS' else T_ns), f=KIND[k])); st['series'] = c
            out.append(st)
    with open(os.path.join(tmp, 'runs_status.tsv'), 'w') as f:
        f.write('\t'.join(V.STATUS_COLS) + '\n')
        for st in out: f.write('\t'.join(st.get(c, '-') for c in V.STATUS_COLS) + '\n')
    return out

def judge(tmp, *extra):
    p = subprocess.run([sys.executable, os.path.join(ROOT, 'verdict_R4_3day.py'), 'judge', tmp, '--d1v2-lam', D1V2] + list(extra), capture_output=True, text=True)
    assert p.returncode == 0, p.stderr; return json.load(open(os.path.join(tmp, 'VERDICT.json')))

class CellLevel(unittest.TestCase):
    def test_c1_pass_with_void_substitution(self):
        tmp = tempfile.mkdtemp(); build_status(tmp, SPEC_PASS); v = judge(tmp); c = v['final']['conditions']['C1']
        self.assertEqual(c['ruler'], 'PASS'); self.assertEqual(v['final']['main_condition'], 'C1')
        d = c['systems']['DOPC']['hii']; self.assertEqual((d['n_eval'], d['n_LOST']), (3, 3)); self.assertTrue(any('替补 s4' in n for n in d['notes']))
        self.assertEqual(c['systems']['DOPE']['hii']['n_RETAIN'], 2)   # s4 未被需要, 不计入
        self.assertEqual(c['systems']['MC3']['hii']['state'], 'VOID'); self.assertEqual(c['systems']['MC3']['lam']['state'], 'VOID')
        self.assertEqual(c['systems']['MC3']['phase_class'], 'NOT_EVALUABLE'); self.assertIn('MC3_note', c)   # AMENDMENT_01 M1: 两臂 VOID -> NOT_EVALUABLE
        self.assertEqual(c['systems']['DOPE']['phase_class'], 'HYST'); self.assertEqual(c['systems']['DOPC']['phase_class'], 'LAM_PREF')
        self.assertEqual(c['delta']['verdict'], 'NOT_EVALUABLE')
        for k in ('C2', 'C3', 'C4'): self.assertEqual(v['final']['conditions'][k]['ruler'], 'NOT_RUN')
        self.assertFalse(v['final']['F1_crux_fail']); self.assertEqual(v['retractions'], [])
    def test_ruler_not_evaluable_trunc_not_substituted(self):
        s = dict(SPEC_PASS); s[('DOPC', 'T320', 'hii')] = ['LOSTL', 'TRUNC', 'LOSTL', 'LOSTL']
        tmp = tempfile.mkdtemp(); build_status(tmp, s); v = judge(tmp); c = v['final']['conditions']['C1']
        self.assertEqual(c['ruler'], 'RULER_NOT_EVALUABLE'); self.assertEqual(c['systems']['DOPC']['hii']['n_eval'], 2)
        self.assertEqual(c['systems']['DOPC']['phase_class'], 'NOT_EVALUABLE')
    def test_crux_fail_F1(self):
        s = dict(SPEC_PASS); s[('DOPC', 'T320', 'hii')] = ['RET', 'LOSTL', 'LOSTL']
        tmp = tempfile.mkdtemp(); build_status(tmp, s); v = judge(tmp)
        self.assertEqual(v['final']['conditions']['C1']['ruler'], 'FAIL'); self.assertTrue(v['final']['F1_crux_fail']); self.assertIn('B1', v['final']['branch'])
    def test_retraction_horizon_and_compare(self):
        s = dict(SPEC_PASS); s[('DOPE', 'T320', 'hii')] = ['LATELOSS', 'LATELOSS', 'RET']
        tmp = tempfile.mkdtemp(); build_status(tmp, s); v = judge(tmp)
        self.assertEqual(v['by_horizon']['400']['conditions']['C1']['ruler'], 'PASS'); self.assertEqual(v['final']['conditions']['C1']['ruler'], 'FAIL')
        self.assertTrue(any(r.startswith('撤回') and 'C1' in r for r in v['retractions']))
        old = tempfile.mkdtemp(); build_status(old, SPEC_PASS); judge(old)
        v2 = judge(tmp, '--compare', os.path.join(old, 'VERDICT.json'), '--horizons', 'max')
        self.assertTrue(any('旧 VERDICT' in r for r in v2['retractions']))
    def test_350_lam_arm_and_delta(self):
        s = {('DOPE', 'T350', 'hii'): ['RET'] * 3, ('DOPC', 'T350', 'hii'): ['LOSTL'] * 3, ('MC3H', 'T350', 'hii'): ['LOSTL'] * 3, ('MC3', 'T350', 'hii'): ['RET'] * 3,
             ('DOPE', 'T350', 'lam'): ['LAMEV'] * 3, ('DOPC', 'T350', 'lam'): ['LAMNO'] * 3, ('MC3H', 'T350', 'lam'): ['LAMNO'] * 3, ('MC3', 'T350', 'lam'): ['VOID'] * 4}
        tmp = tempfile.mkdtemp(); build_status(tmp, s); v = judge(tmp); c = v['final']['conditions']['C2']
        self.assertEqual(c['ruler'], 'PASS'); self.assertEqual(c['delta'], dict(value=3, verdict='SEP_EXPECTED'))
        self.assertEqual(c['systems']['DOPE']['phase_class'], 'HII_PREF'); self.assertEqual(c['systems']['MC3H']['like'], ['DOPC'])
        self.assertEqual(c['systems']['MC3']['lam']['state'], 'VOID'); self.assertEqual(v['final']['main_condition'], 'C2')
    def test_F3_overdriven(self):
        s = {('DOPE', 'T350', 'hii'): ['RET'] * 3, ('DOPC', 'T350', 'hii'): ['LOSTL'] * 3, ('DOPE', 'T350', 'lam'): ['LAMEV'] * 3, ('DOPC', 'T350', 'lam'): ['LAMEV', 'LAMNO', 'LAMNO']}
        tmp = tempfile.mkdtemp(); build_status(tmp, s); v = judge(tmp); c = v['final']['conditions']['C2']
        self.assertEqual(c['ruler'], 'FAIL'); self.assertTrue(c['F3_overdriven']); self.assertEqual(v['final']['F3_overdriven'], ['C2'])

class Collect(unittest.TestCase):
    def test_collect_states(self):
        tmp = tempfile.mkdtemp(); inp = os.path.join(tmp, 'inputs'); run = os.path.join(tmp, 'R4N1_run_k03_x'); os.makedirs(inp)
        bs = ['R4N1_DOPC_h050_T320_hii_s%d' % i for i in (1, 2, 3, 4)]
        with open(os.path.join(inp, 'L1_summary.tsv'), 'w') as f:
            f.write('build\tarm\tverdict\n'); [f.write('%s\thii\t%s\n' % (b, 'VOID_BUILD' if b.endswith('s2') else 'PASS')) for b in bs]
        def st(b, stage, n, s):
            d = os.path.join(run, 'builds', b, stage, 'attempt_%03d' % n); os.makedirs(d); open(os.path.join(d, 'STATUS'), 'w').write(s + ' x\n'); return d
        st(bs[0], 'relax', 1, 'DONE'); st(bs[0], 'gate', 1, 'VOID_L2')
        st(bs[2], 'relax', 1, 'RELAX_FAIL')
        st(bs[3], 'relax', 1, 'DONE'); st(bs[3], 'gate', 1, 'PASS'); d = st(bs[3], 'prod', 1, 'TRUNC_TIMEOUT'); open(os.path.join(d, 'prod.xtc'), 'wb').write(b'xx')
        open(os.path.join(d, 'SHA256_out.txt'), 'w').write('0' * 64 + '  prod.xtc\n')
        o = os.path.join(tmp, 'res'); p = subprocess.run([sys.executable, os.path.join(ROOT, 'verdict_R4_3day.py'), 'collect', run, '--inputs', inp, '--out', o], capture_output=True, text=True)
        self.assertEqual(p.returncode, 0, p.stderr)
        R = {r['build']: r for r in csv.DictReader(open(os.path.join(o, 'runs_status.tsv')), delimiter='\t')}
        self.assertEqual([R[b]['start'] for b in bs], ['VOID_L2', 'VOID_BUILD', 'RELAX_FAIL', 'PASS'])
        self.assertEqual((R[bs[3]]['prod'], R[bs[3]]['sha_check']), ('TRUNC_TIMEOUT', 'prod.xtc:MISMATCH'))

class PhaseClassAmend01(unittest.TestCase):   # PRE_REG_AMENDMENT_R4N1_01 (M1)
    V_ = dict(state='VOID'); HL = dict(state='EVALUABLE', n_RETAIN=0, n_LOST=3, n_eval=3); LE = dict(state='EVALUABLE', n_eval=3, n_event=3)
    def test_both_void_not_evaluable(self): self.assertEqual(V.phase_class(self.V_, self.V_), 'NOT_EVALUABLE')
    def test_one_void_other_lost_neither(self):
        self.assertEqual(V.phase_class(self.V_, self.LE), 'NEITHER'); self.assertEqual(V.phase_class(self.HL, self.V_), 'NEITHER')

if __name__ == '__main__': unittest.main(verbosity=1)
