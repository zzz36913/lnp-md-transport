#!/usr/bin/env python3
"""预检 3: 温度相关 mdp 参数自洽. 对每个 build: (a) relax/prod 两份 mdp 的 ref_t 每组 == 名字里的 T, relax gen_temp == T, gen_vel yes / prod gen_vel no + continuation yes;
(b) tc-grps 组数 == tau_t 组数 == ref_t 组数; (c) 与 D1v2 同名模板逐键比对, 只允许 ref_t / gen_temp / gen_seed 不同 (其它键一字相同);
(d) 同一体系 T320 与 T350 的 mdp 只差 ref_t/gen_temp/gen_seed. 输出 TSV + 末行 ALL_OK/FAIL. 退出码 0=全过."""
import glob, os, re, sys
D = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); D1 = '/workspace/lnp-md/scan/R4_recipe/D1v2/mdp'
def P(f):
    o = {}
    for l in open(f):
        l = l.split(';')[0].strip()
        if '=' in l: k, v = l.split('=', 1); o[k.strip().replace('_', '-').lower()] = ' '.join(v.split())
    return o
ALLOW = {'ref-t', 'gen-temp', 'gen-seed'}; bad = 0; rows = []
for b in sorted(glob.glob(D + '/inputs/R4N1_*')):
    if not os.path.isfile(b + '/start.gro'): continue
    n = os.path.basename(b); T = int(re.search(r'_T(\d+)_', n).group(1)); arm = re.search(r'_(hii|lam)_', n).group(1)
    for m, tmpl in (('relax_crescale_dev', 'relax_crescale_dev'), ('prod_' + arm, 'prod_lam')):
        x = P('%s/%s.mdp' % (b, m)); t = P('%s/%s.mdp' % (D1, tmpl)); err = []
        ng = len(x['tc-grps'].split())
        if x['tc-grps'].split() != ['Solvent', 'Rest']: err.append('tc-grps=' + x['tc-grps'])
        if len(x['tau-t'].split()) != ng or len(x['ref-t'].split()) != ng: err.append('组数不一致')
        if any(float(v) != T for v in x['ref-t'].split()): err.append('ref_t=' + x['ref-t'])
        if m.startswith('relax'):
            if x.get('gen-vel') != 'yes' or float(x.get('gen-temp', -1)) != T: err.append('gen_vel/gen_temp=%s/%s' % (x.get('gen-vel'), x.get('gen-temp')))
        else:
            if x.get('gen-vel', 'no') != 'no' or x.get('continuation') != 'yes': err.append('prod gen_vel/continuation=%s/%s' % (x.get('gen-vel'), x.get('continuation')))
        diff = sorted(k for k in set(x) | set(t) if x.get(k) != t.get(k) and k not in ALLOW)
        if diff: err.append('与D1v2差异键=' + ','.join(diff))
        if T == 350:
            twin = b.replace('_T350_', '_T320_')
            if os.path.isdir(twin):
                y = P('%s/%s.mdp' % (twin, m)); d2 = sorted(k for k in set(x) | set(y) if x.get(k) != y.get(k) and k not in ALLOW)
                if d2: err.append('与T320同体系差异键=' + ','.join(d2))
        rows.append('%s\t%s\tT=%d\tref_t=%s\tgen_temp=%s\tgen_seed=%s\ttau_t=%s\t%s' % (n, m, T, x['ref-t'], x.get('gen-temp', ''), x.get('gen-seed', ''), x['tau-t'], 'OK' if not err else 'FAIL ' + '; '.join(err)))
        bad += bool(err)
print('\n'.join(rows)); print('ALL_OK n=%d' % len(rows) if not bad else 'FAIL n_bad=%d' % bad); sys.exit(1 if bad else 0)
