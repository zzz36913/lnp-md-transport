#!/bin/bash
# N1 L1 (builder 级) 闸门扫描: start.gro; lam -> gate/t0_gate_launch.py --arm lam (D1v2 原件); hii -> gate/t0_gate_hii.py --level builder. 期望组成读 expect.env.
# 未建成的 build (无 start.gro) 记 VOID_BUILD(builder). 用法: PY=<python+MDAnalysis> bash tools/l1_scan.sh <inputs 目录> > L1_summary.tsv
D=$(cd "$(dirname "$0")/.." && pwd); PY=${PY:-python3}
echo -e "build\tarm\tverdict\trc\tn_lipid\tn_W\treading\tbuilder_seed\tmin_intermol\tforced\tgeom"
for b in "$1"/R4N1_*; do [ -d $b ] || continue; n=$(basename $b)
  if [ ! -s $b/start.gro ]; then echo -e "$n\t$(echo $n | grep -o '_\(hii\|lam\)_' | tr -d _)\tVOID_BUILD\tbuilder_fail\t\t\t$(grep -o '"min_intermol_nm": [0-9.]*, "n_beads_below_dmin": [0-9]*' $b/preasm.json 2>/dev/null)"; continue; fi
  . $b/expect.env; j=$(mktemp)
  if [ "$EXP_ARM" = lam ]; then $PY $D/gate/t0_gate_launch.py $b/start.gro --level builder --arm lam --expect-lipids $EXP_LIP --expect-w $EXP_W --json $j >/dev/null 2>&1; rc=$?
  else $PY $D/gate/t0_gate_hii.py $b/start.gro --level builder --expect-lipids $EXP_LIP --expect-w $EXP_W --json $j >/dev/null 2>&1; rc=$?; fi
  $PY - $j $n $rc $b/SYSTEM.txt $EXP_ARM <<'P'
import json,sys
d=json.load(open(sys.argv[1])); s=dict(x.split('=',1) for x in open(sys.argv[4]).read().split() if '=' in x); r=d['readings']
if sys.argv[5]=='lam': rd=' '.join('%s:%s'%(k,'/'.join(map(str,r[k]['v1']))) for k in ('0.65','0.75','0.95'))
else: rd='ncl/wind/npol/wpol=%d/%d/%d/%d n_tube=%d v1=%s C_max=%.2f'%(r['ncl'],r['wind'],r['npol'],r['wpol'],r['n_tube'],'/'.join(map(str,r['v1'])),r['C_max'])
c=d['composition']; print('\t'.join(map(str,[sys.argv[2],sys.argv[5],d['verdict'],sys.argv[3],c['n_lipid_res'],c['n_W'],rd,s.get('builder_seed'),s.get('builder_min_intermol'),s.get('forced'),s.get('geom','')])))
P
  rm -f $j
done
