#!/bin/bash
# R4N1x 起点构建 (幂等: 已有 start.gro + SYSTEM.txt 跳过). C4 = h100 T350 hii+lam, 4 体系 x s1-s4; L 臂 = DOPE/DOPC h050 T320 hiiL x s1-s4. 用法: bash tools/build_all_x.sh [并行数]
D=$(cd "$(dirname "$0")/.." && pwd); P=${1:-4}
{ for s in DOPE DOPC; do for k in 1 2 3 4; do echo "$s 50 320 hiiL $k"; done; done
  for s in DOPE DOPC MC3H MC3; do for k in 1 2 3 4; do echo "$s 100 350 hii $k"; echo "$s 100 350 lam $k"; done; done; } |
xargs -P $P -L 1 bash -c 'n=$(printf "R4N1_%s_h%03d_T%d_%s_s%d" $0 $1 $2 $3 $4); o='"$D"'/inputs/$n; [ -s $o/start.gro ] && [ -s $o/SYSTEM.txt ] && { echo "SKIP $n"; exit 0; };
  python3 '"$D"'/tools/build_R4N1x.py --prim $0 --tier $1 --temp $2 --arm $3 --seed-id $4 -o $o --ntomp 2 > /dev/null 2>$o.err; rc=$?; echo "rc=$rc $n $(date +%T)"; [ $rc = 0 ] && mv $o.err $o/build_stderr.txt'
