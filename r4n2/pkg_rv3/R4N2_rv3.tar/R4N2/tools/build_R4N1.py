#!/usr/bin/env python3
"""R4 3 天扫参 第 1 晚 (N1) 起点构建器 (box 上只做 EM; 不发车). 由 D1v2/tools/build_R4.py 改写 (见 PREREG_R4_3day.md §2).
  --arm lam : 与 D1v2 逐字同流程 (单层 builder 2 bilayer?=1 -> EM1 -> genconf z x2 -> EM2), APL 0.55, 240/叶; 只多 --temp (ref_t/gen_temp).
  --arm hii : R2a 的 H_II 几何 (build_lam_rect.py --geom hii, nx=2 ny=1 => 4 根水管, 管轴 z, Ly/Lx=0.866), 960 脂单盒 (不 genconf);
              Lz 规则 (PREREG §2, 冻结): a_w = 4*2*pi*r_head*Lz/960 (= builder 的 apl_head_nm2, r_head=r_water+0.25) 取最接近 0.60 nm^2 的 Lz
              (步长 0.01 nm, 搜 4-40 nm), 要求 0.50<=a_w<=0.70, 否则 VOID_BUILD (exit 4). A = sqrt(V/Lz/(2 sqrt3)), V = 质量/700 (同 D1v2/R2a).
              EM1 -> EM2 (同一 em1/em2 mdp; 无复制).
  水合 (同 D1v2): W = NW_FULL[prim]*tier/100 * 960/4; MC3H 每脂 1 CL.
  名字 R4N1_<prim>_h<tier>_T<temp>_<arm>_s<k>; builder seed = 20301030 + cksum(name)%100000; gen_seed 同.
用法: build_R4N1.py --prim DOPE|DOPC|MC3H|MC3 --tier 50|100 --temp 320|350 --arm lam|hii --seed-id N -o DIR"""
import argparse, json, math, os, re, shutil, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__)); PKG = os.path.dirname(HERE)
R2A = '/workspace/lnp-md/scan/R2a'; BUILDER = R2A + '/gen/build_lam_rect.py'; TMPL = R2A + '/tmpl'
BOX_GMX = '/workspace/ha_src/gmxenv/bin/gmx'
ap = argparse.ArgumentParser(); ap.add_argument('--prim', required=True, choices=['DOPE', 'DOPC', 'MC3H', 'MC3'])
ap.add_argument('--tier', type=int, required=True, choices=[50, 100]); ap.add_argument('--temp', type=int, required=True, choices=[320, 350])
ap.add_argument('--arm', required=True, choices=['lam', 'hii'])
ap.add_argument('--seed-id', type=int, required=True); ap.add_argument('-o', required=True); ap.add_argument('--gmx', default=BOX_GMX); ap.add_argument('--ntomp', type=int, default=4)
ap.add_argument('--apl', type=float, default=0.55); ap.add_argument('--dens', type=float, default=700.0)
a = ap.parse_args(); d = os.path.abspath(a.o); os.makedirs(d, exist_ok=True)
NW_FULL = {'DOPC': 32.5, 'DOPE': 15.1, 'MC3': 32.5, 'MC3H': 32.5}
AW_TARGET, AW_LO, AW_HI, RHO_W = 0.60, 0.50, 0.70, 8.36      # RHO_W 与 build_lam_rect.py 同值 (该文件第 14 行)
NTOT = 960; NL = 480 if a.arm == 'lam' else 960                # lam: 单层 builder 480 脂 x genconf 2; hii: 960 脂单盒
wl = NW_FULL[a.prim] * a.tier / 100.0; nwf = wl * NL / 4.0; NW = int(round(nwf)); assert abs(nwf - NW) < 1e-6, nwf
NCL = NL if a.prim == 'MC3H' else 0
name = 'R4N1_%s_h%03d_T%d_%s_s%d' % (a.prim, a.tier, a.temp, a.arm, a.seed_id)
def cksum(s): return int(subprocess.run('printf %%s %s | cksum' % repr(s), shell=True, capture_output=True, text=True).stdout.split()[0])
seed = 20301030 + cksum(name) % 100000
FF = ['martini_v3.0.0.itp', 'martini_v3.0.0_ffbonded_v2.itp', 'martini_v3.0.0_phospholipids_PC_v2.itp', 'martini_v3.0.0_phospholipids_PE_v2.itp',
      'lk_v1_macros.itp', 'MC3_MC3H.itp', 'martini_v3.0.0_solvents_v1.itp', 'martini_v3.0.0_ions_v1.itp']
def masses(files):
    M, cur, sec = {}, None, None
    for fn in files:
        for raw in open(fn):
            l = raw.split(';')[0].strip()
            if not l or l.startswith('#'): continue
            m = re.match(r'\[\s*(\w+)\s*\]', l)
            if m: sec = m.group(1); continue
            if sec == 'moleculetype': cur = l.split()[0]; M[cur] = 0.0; sec = 'mt_done'
            elif sec == 'atoms' and cur:
                f = l.split(); M[cur] += float(f[7]) if len(f) >= 8 else (36.0 if f[1].startswith('T') else 54.0 if f[1].startswith('S') else 72.0)
    return M
M = masses([PKG + '/inputs/ff/' + f for f in FF])
def run(cmd, log, cwd=d, ok=(0,)):
    r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True); open(log, 'w').write(r.stdout + r.stderr)
    if r.returncode not in ok: sys.exit('FAIL %s (见 %s)' % (cmd[:80], log))
    return r.returncode
def ndx(gro, out):
    L = open(gro).read().splitlines(); n = int(L[1]); sol = []; rest = []
    for i, l in enumerate(L[2:2 + n], 1): (sol if l[5:10].strip() in ('W', 'CL', 'NA') else rest).append(i)
    def blk(nm, ids):
        s = '[ %s ]\n' % nm
        for k in range(0, len(ids), 15): s += ' '.join(map(str, ids[k:k + 15])) + '\n'
        return s
    open(out, 'w').write(blk('System', list(range(1, n + 1))) + blk('Solvent', sol) + blk('Rest', rest))
def top(path, mols, title):
    with open(path, 'w') as o:
        for f in FF: o.write('#include "%s"\n' % f)
        o.write('\n[ system ]\n%s\n\n[ molecules ]\n' % title)
        for m, n in mols: o.write('%s %d\n' % (m, n))
cnt = [(a.prim, NL), ('W', NW)] + ([('CL', NCL)] if NCL else [])
open(d + '/counts.txt', 'w').write(''.join('%s %d\n' % kv for kv in cnt))
V = sum(M[m] * n for m, n in cnt) / a.dens
os.environ['GMXLIB'] = PKG + '/inputs/ff'
geo = {}
if a.arm == 'lam':
    Lxy = math.sqrt(a.apl * NL / 2.0); Lz = V / Lxy ** 2; geo = dict(Lxy=round(Lxy, 4), Lz_single=round(Lz, 4))
    bcmd = '--geom lam --box %.4f --lz %.4f --nbil 1' % (Lxy, Lz)
else:
    def aw(Lz):
        rw = math.sqrt(NW / RHO_W / (4 * math.pi * Lz)); return 4 * 2 * math.pi * (rw + 0.25) * Lz / NL, rw
    best = min((abs(aw(i / 100.0)[0] - AW_TARGET), i / 100.0) for i in range(400, 4001)); Lz = best[1]; aw_, rw = aw(Lz)
    A = math.sqrt(V / Lz / (2 * math.sqrt(3)))
    geo = dict(Lz=Lz, a_w=round(aw_, 4), r_water=round(rw, 4), r_head=round(rw + 0.25, 4), lattice_a=round(A, 4), Lx=round(2 * A, 4), Ly=round(A * math.sqrt(3), 4),
               a_w_at_rwater=round(4 * 2 * math.pi * rw * Lz / NL, 4), rule='a_w(r_head) closest to %.2f, step 0.01 nm' % AW_TARGET)
    if not (AW_LO <= aw_ <= AW_HI):
        open(d + '/VOID_BUILD.txt', 'w').write('a_w=%.4f 不在 [%.2f,%.2f]\n' % (aw_, AW_LO, AW_HI)); sys.exit(4)
    bcmd = '--geom hii --hii-a %.4f --nx 2 --ny 1 --lz %.4f' % (A, Lz)
rc = run('python3 %s --counts counts.txt --tmpl %s --seed %d --dmin 0.30 --info preasm.json -o built.gro %s' % (BUILDER, TMPL, seed, bcmd), d + '/build.log')
for f in FF: shutil.copy(PKG + '/inputs/ff/' + f, d + '/' + f)
top(d + '/built.top', cnt, name); ndx(d + '/built.gro', d + '/built.ndx')
G = a.gmx; mdp = PKG + '/mdp'
def grompp_em(mdpn, gro, tp, ndxf, tag):
    run('%s grompp -f %s/%s.mdp -c %s -p %s -n %s -o %s.tpr -po %s_out.mdp -maxwarn 0' % (G, mdp, mdpn, gro, tp, ndxf, tag, tag), d + '/%s_grompp.log' % tag)
    run('%s mdrun -deffnm %s -ntmpi 1 -ntomp %d -nb cpu -pin off' % (G, tag, a.ntomp), d + '/%s_mdrun.log' % tag)
title = name + ' prim=%s arm=%s tier=%d wl=%.4f T=%d' % (a.prim, a.arm, a.tier, wl, a.temp)
grompp_em('em1', 'built.gro', 'built.top', 'built.ndx', 'em1')
if a.arm == 'lam':
    run('%s genconf -f em1.gro -nbox 1 1 2 -o rep.gro' % G, d + '/genconf.log'); mols = cnt + cnt; g2 = 'rep.gro'
else:
    mols = cnt; g2 = 'em1.gro'
top(d + '/sys.top', mols, title); ndx(d + '/' + g2, d + '/index.ndx'); grompp_em('em2', g2, 'sys.top', 'index.ndx', 'em2')
shutil.copy(d + '/em2.gro', d + '/start.gro')
for k in ('relax_crescale_dev', 'prod_' + a.arm):
    t = open('%s/%s.mdp' % (mdp, k)).read().replace('@SEED@', str(seed)).replace('@TEMP@', str(a.temp)); assert '@' not in t; open('%s/%s.mdp' % (d, k), 'w').write(t)
info = json.load(open(d + '/preasm.json')); L = open(d + '/start.gro').read().splitlines(); nat = int(L[1]); box = [float(x) for x in L[-1].split()[:3]]
f = 2 if a.arm == 'lam' else 1
open(d + '/expect.env', 'w').write('EXP_LIP=%d\nEXP_W=%d\nEXP_CL=%d\nEXP_ATOMS=%d\nEXP_ARM=%s\nEXP_TEMP=%d\nBOX0=%.4f,%.4f,%.4f\n' % (f * NL, f * NW, f * NCL, nat, a.arm, a.temp, *box))
json.dump(dict(name=name, prim=a.prim, arm=a.arm, tier=a.tier, temp=a.temp, seed=seed, geometry=geo, builder_info=info, start_box=box), open(d + '/t0_builder.json', 'w'), indent=1)
open(d + '/SYSTEM.txt', 'w').write('%s prim=%s arm=%s tier=%d seed_id=%d T=%d nlip=%d W=%d CL=%d wl_real=%.3f beads=%d builder_seed=%d builder_min_intermol=%s forced=%s builder_ok=%s geom=%s start_box=%s gmx_used=%s\n'
    % (name, a.prim, a.arm, a.tier, a.seed_id, a.temp, f * NL, f * NW, f * NCL, 4.0 * NW / NL, nat, seed, info.get('min_intermol_nm'), info.get('place_forced'), info.get('ok'),
       json.dumps(geo, separators=(',', ':')), 'x'.join('%.3f' % x for x in box), G))
print(open(d + '/SYSTEM.txt').read().strip())
