#!/bin/bash
# mps_residue.sh -- 规则「MPS 残留先认人再 quit」的执行工具 (R4N1). 不 kill 任何进程, 不删任何目录.
# 默认 (只认人): 列出所有 nvidia-cuda-mps-* 进程的 owner / pid / ppid / etime / args, 以及每个 control 守护的 CUDA_MPS_PIPE_DIRECTORY (读 /proc/<pid>/environ, 只能读自己的进程)
#                和 $HOME/mps_R4*/ 下的候选 pipe 目录; 同时列 gmx 进程. 什么都不改.
# QUIT=1 (认完人后 quit): 只对同时满足以下条件的守护发 'quit' (echo quit | CUDA_MPS_PIPE_DIRECTORY=<pipe> nvidia-cuda-mps-control):
#        (a) 进程 owner == 当前用户; (b) pipe 目录在 $HOME/mps_R4* 之下 (即 R4 系列自己起的); (c) 本机无 gmx 进程 (防止打断正在跑的 mdrun).
#        别人的 / 不在 $HOME/mps_R4* 下的 / 有 gmx 在跑的: 一律只报告, 交 K/调度决定. quit 后再列一次进程.
# 用法: bash tools/mps_residue.sh          (只认人)
#       QUIT=1 bash tools/mps_residue.sh   (认人 + 只 quit 自己的 R4 残留)
set -u
me=$(id -un)
echo "== MPS 残留认人 $(hostname) $(date '+%F %T %z') user=$me"
echo "-- nvidia-cuda-mps 进程 (user pid ppid etime args):"
ps -eo user=,pid=,ppid=,etime=,args= | grep '[n]vidia-cuda-mps' || echo "   (无)"
echo "-- gmx 进程:"; pgrep -a gmx || echo "   (无)"
echo "-- 候选 pipe 目录 ($HOME/mps_R4*/**/pipe):"; ls -1d $HOME/mps_R4*/pipe $HOME/mps_R4*/*/pipe 2>/dev/null || echo "   (无)"
declare -a QP=()
for pid in $(pgrep -f 'nvidia-cuda-mps-control' 2>/dev/null); do
  u=$(ps -o user= -p $pid 2>/dev/null | tr -d ' '); pipe=$(tr '\0' '\n' < /proc/$pid/environ 2>/dev/null | sed -n 's/^CUDA_MPS_PIPE_DIRECTORY=//p')
  echo "   control pid=$pid owner=$u pipe=${pipe:-<读不到: 非本用户进程或默认 /tmp/nvidia-mps>}"
  if [ "$u" = "$me" ] && [ -n "$pipe" ]; then case "$pipe" in "$HOME"/mps_R4*) QP+=("$pipe");; *) echo "     -> pipe 不在 \$HOME/mps_R4* 下: 不是本包系列起的, 只报告";; esac
  else echo "     -> 非本用户/读不到 pipe: 只报告, 交 K/调度"; fi
done
[ "${QUIT:-0}" = 1 ] || { echo "== 只认人模式结束 (未改任何东西). 需 quit 自己的残留: QUIT=1 bash $0"; exit 0; }
if [ -n "$(pgrep gmx)" ]; then echo "== 有 gmx 在跑: 不 quit (避免打断 mdrun). 先确认这些 gmx 是谁的"; exit 2; fi
[ ${#QP[@]} = 0 ] && { echo "== 没有可由本用户 quit 的 R4 系列残留"; exit 0; }
for pipe in "${QP[@]}"; do echo "-- quit -> $pipe"; echo quit | CUDA_MPS_PIPE_DIRECTORY=$pipe timeout 20 nvidia-cuda-mps-control; echo "   rc=$?"; done
sleep 5; echo "-- quit 后 nvidia-cuda-mps 进程:"; ps -eo user=,pid=,ppid=,etime=,args= | grep '[n]vidia-cuda-mps' || echo "   (无)"
echo "== 结束 (未 kill, 未删目录; 仍在的进程交 K/调度)"
