#!/bin/bash
# make_package_n2.sh <out_pkg_dir>  -- 组装 R4N2 第 2 晚包 (只读 N2/src, N1/inputs, D2/*.md; 只写 <out_pkg_dir>; 目标已存在则拒绝, 不覆盖). 仿 N1x/tools/make_package_x.sh.
set -eu
P=${1:?out_pkg_dir}
X=$(cd "$(dirname "$0")/.." && pwd); D2=$(cd $X/../.. && pwd); N1=$D2/N1; D1V2_RUNS=/workspace/lnp-md/scan/R4_recipe/D1v2_results_pull/results_xtc_prereg/runs.tsv
[ -e "$P" ] && { echo "REFUSE: $P 已存在 (不覆盖)"; exit 1; }
v=$(sha256sum $X/verdict_R4_3day.py | cut -c1-8); [ "$v" = 4fd49504 ] || { echo "ERR: verdict_R4_3day.py sha=$v != 冻结 4fd49504"; exit 1; }
mkdir -p "$P"; cd "$P"
cp $X/run_R4N2.sh $X/lib_R4N2.sh $X/verdict_R4_3day.py $X/verdict_Larm.py $X/merge_status_x.py .
cp $D2/PREREG_R4_3day.md $D2/PRE_REG_AMENDMENT_R4N1_01.md $D2/PRE_REG_AMENDMENT_R4N1_02.md .
echo night2 > VARIANT
mkdir gate gatewrap mdp tools tools/ref_n1x tools/ref_main tests proof chains inputs inputs/ff
cp $X/gate/*.py gate/; cp $X/gatewrap/*.sh gatewrap/; cp $X/mdp/*.mdp mdp/; cp $X/tests/*.py $X/tests/*.sh tests/; cp -r $X/tests/mock tests/
for t in $X/tools/*; do [ -f $t ] && cp $t tools/; done
cp $D2/N1x/run_R4N1x.sh $D2/N1x/lib_R4N1x.sh tools/ref_n1x/; cp $N1/run_R4N1.sh $N1/lib_R4N1.sh tools/ref_main/   # 第 1 晚两包 (只供 diff 对照, 不被调用)
cp -r $X/proof/grompp_box proof/; cp $X/proof/*.tsv proof/
cp -r $N1/proof/readout_validation $N1/proof/verdict_realdata proof/; cp $N1/proof/neg_selftest_bridged.gro proof/; cp -r $X/proof/n1x_chains $X/proof/n1x_tools proof/   # 第 1 晚链/工具 (只作记录)
cp $X/chains/*.txt chains/
cp $X/inputs/L1_summary.tsv inputs/; cp $D1V2_RUNS inputs/D1v2_lam_runs.tsv; cp $X/inputs/ff/*.itp inputs/ff/
for b in $(cat chains/*.txt | grep -vE '^\s*(#|$)' | awk '{print $1}' | sort -u); do
  s=$X/inputs/$b; [ -s $s/start.gro ] || s=$N1/inputs/$b; [ -s $s/start.gro ] || { echo "ERR: 缺 $b/start.gro"; exit 1; }; mkdir inputs/$b
  for x in start.gro sys.top index.ndx expect.env counts.txt SYSTEM.txt t0_builder.json preasm.json build.log relax_crescale_dev.mdp prod_hii.mdp prod_lam.mdp genconf.log; do [ -e $s/$x ] && cp $s/$x inputs/$b/; done
  echo "$s" > inputs/$b/SOURCE_DIR.txt
  for x in $s/*.itp; do n=$(basename $x); cmp -s $x inputs/ff/$n || { echo "ERR: $b/$n 与 ff 不同"; exit 1; }; ln inputs/ff/$n inputs/$b/$n; done
done
sha256sum verdict_R4_3day.py PREREG_R4_3day.md PRE_REG_AMENDMENT_R4N1_01.md PRE_REG_AMENDMENT_R4N1_02.md inputs/D1v2_lam_runs.tsv > FROZEN_sha256.txt
find . -type f ! -name MANIFEST_sha256.txt | sed 's#^\./##' | LC_ALL=C sort | xargs sha256sum > MANIFEST_sha256.txt
echo "OK $P files=$(wc -l < MANIFEST_sha256.txt) builds=$(ls -d inputs/R4N1_* | wc -l)"
