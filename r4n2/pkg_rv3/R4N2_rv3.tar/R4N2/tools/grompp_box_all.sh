#!/bin/bash
# box 预检: 每个 build 的 relax_crescale_dev.mdp 与 prod_<arm>.mdp 都用 box gmx (2025.4) grompp -maxwarn 0 (prod 用 start.gro 作 -c, 只验参数/拓扑). 输出 TSV.
D=$(cd "$(dirname "$0")/.." && pwd); G=${GMX:-/workspace/ha_src/gmxenv/bin/gmx}; O=${O:-$D/proof/grompp_box}; mkdir -p $O; T=$(mktemp -d)
echo -e "build\tmdp\trc\tnotes\twarnings"
for b in $D/inputs/R4N1_*; do [ -s $b/start.gro ] || continue; n=$(basename $b); . $b/expect.env
  for m in relax_crescale_dev prod_$EXP_ARM; do
    ( cd $b && GMXLIB=$D/inputs/ff $G grompp -f $m.mdp -c start.gro -p sys.top -n index.ndx -o $T/$n.$m.tpr -po $T/$n.$m.mdp -maxwarn 0 > $O/$n.$m.log 2>&1 ); rc=$?
    echo -e "$n\t$m\t$rc\t$(grep -c '^NOTE' $O/$n.$m.log)\t$(grep -c '^WARNING' $O/$n.$m.log)"
  done; done
rm -rf $T
