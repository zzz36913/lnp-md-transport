#!/bin/bash
# run_R4N1x.sh -- R4N1x 追加包 (PRE_REG_AMENDMENT_R4N1_02): 主包 R4N1 (已发, 不改) 某槽主链跑完后接着跑:
#   L 臂 (优先): 长盒 H_II, K1 检验; h050 T320, DOPE/DOPC, Lz 约 22 nm (DOPC 21.93 / DOPE 38.18), n=3 (+ s4 替补), 名字 R4N1_<体系>_h050_T320_hiiL_s<k>
#   C4: 350 K h100, 4 体系 × (hii, lam), n=3, 400 ns, 原 PREREG 判据; 放不下的按 K 12:42 裁剪序 (先内标 MC3H/MC3, 再 lam 臂) 进 supp 队列 (有时间才跑, 否则第 2 晚)
# 由 run_R4N1.sh 复制, 只改 [R4N1x] 处: 等待启动器 (wait_slot, 每槽), ONLY 过滤, 追加包 MPS (x_mps_pick), launch_guard 第 5 节 (主包在跑时的冲突检查改为 "认出主包的、排除它、其余照旧 FAIL").
# 用法:  WAIT_MAIN=auto bash run_R4N1x.sh <k03|k04>    正式: 过 launch_guard 后两槽各自等主包同槽 done 再起 (见 lib_R4N1x.sh "等主槽")
#        START_AT="2026-10-30 21:00 +0800" ...           调度手动接入时间点 (此前不起; 到点后仍要求槽空)
#        touch $OUT/slots/<机>_<A|B>.GO                    调度手动接入 (确认主槽不会再起新条; 再等 GO_QUIET_S 无主包容器即起)
#        ONLY="Larm" / ONLY="DOPC_h050_T320_hiiL,C4hii" / ONLY_FILE=<文件> ...   只跑挑出来的条目 (分段闭环)
#        CHECK=1 / DRY=1 / APPEND_TO=<R4N1x_run_目录> / NEW_RUN=1 同主包
# 判读: C4 用冻结的 verdict_R4_3day.py (与主包合并 inputs, 见 README_R4N1x.md §6); L 臂用 verdict_Larm.py (只 import 冻结函数).
# 不覆写/不 rm; MPS 先认人再 quit, 只 quit 自己的 pipe, 不 kill, 不删目录; 主包的 MPS/容器/目录一概不碰 (只读其日志与 docker ps).
HERE=$(cd "$(dirname "$0")" && pwd); MACHINE=${1:?usage: bash run_R4N1x.sh <k03|k04>}; ORCH_PID=$$
case $MACHINE in k03|k04) ;; *) echo "ABORT: 机器名须为 k03 或 k04"; exit 1;; esac
. "$HERE/lib_R4N1x.sh"
rdlines0(){ grep -vE '^\s*(#|$)' "$1" | awk '{print $1}'; }
REFB=$(rdlines0 $HERE/chains/${MACHINE}_A.txt | head -1)   # 估时参考 build = A 链第一条
REFH=$(cat $HERE/chains/${MACHINE}_[AB].txt | rdlines0 /dev/stdin | grep -E '_hiiL?_' | head -1); REFL=$(cat $HERE/chains/*.txt | rdlines0 /dev/stdin | grep '_lam_' | head -1)   # 闸门自检用 (各臂一条) [R4N1x] 本包主链无 lam (全在 supp), REFL 从全部链/supp/替补文件取
CA=$HERE/chains/${MACHINE}_A.txt; CB=$HERE/chains/${MACHINE}_B.txt; SPARES=$HERE/chains/spares_${MACHINE}.txt; SUPPQ=$HERE/chains/supp_${MACHINE}.txt
rdlines(){ [ -f "$1" ] && grep -vE '^\s*(#|$)' "$1" | awk '{print $1}'; }
# ------------------------------------------------------------------ 发车判据 (R2b REVIEW §4 同款多条件 + R3 专项)
f(){ echo "  [FAIL] $*"; bad=1; }; p(){ echo "  [ok]   $*"; }
launch_guard(){ local b x dup P n2; bad=0
  echo "== launch_guard machine=$MACHINE MODE=$MODE variant=$(cat $HERE/VARIANT 2>/dev/null) $(date '+%F %T %z')"
  [ -n "$(cat $HERE/VARIANT 2>/dev/null)" ] && p "VARIANT=$(cat $HERE/VARIANT)" || f "缺 VARIANT 文件"
  # 1 包完整
  ( cd $HERE && sha256sum -c MANIFEST_sha256.txt --quiet ) >/dev/null 2>&1 && p "MANIFEST sha256 全 OK" || f "包与 MANIFEST_sha256.txt 不符 (cd $HERE && sha256sum -c MANIFEST_sha256.txt)"
  # 2 参数/开关
  [ "$MAXWARN_PROD" = 0 ] && p "MAXWARN_PROD=0" || f "MAXWARN_PROD=$MAXWARN_PROD (须 0; prod 警告须看见, 非 0 需改包)"
  case $RELAX_ARM in
    crescale_dev) [ "$MAXWARN_RELAX" = 0 ] && p "RELAX_ARM=crescale_dev (偏离 SI 协议的开发臂), MAXWARN_RELAX=0" || f "crescale_dev 不需要 maxwarn, MAXWARN_RELAX=$MAXWARN_RELAX 须 0";;
    literal) if [ "$K_APPROVED_LITERAL" = yes ] && [ "$MAXWARN_RELAX" = 2 ]; then p "RELAX_ARM=literal, K_APPROVED_LITERAL=yes, MAXWARN_RELAX=2 (逐字核对 2 条警告; 不符则 HALT)"; else f "literal 须同时 K_APPROVED_LITERAL=yes 且 MAXWARN_RELAX=2 (现 '$K_APPROVED_LITERAL'/$MAXWARN_RELAX)"; fi;;
    *) f "RELAX_ARM=$RELAX_ARM 非法";; esac
  if [ -n "${NSTEPS_OVERRIDE_RELAX}${NSTEPS_OVERRIDE_PROD}" ]; then [ "$MODE" = local ] && p "NSTEPS_OVERRIDE_* 已设 (MODE=local 冒烟)" || f "NSTEPS_OVERRIDE_* 只允许 MODE=local"; else p "无 nsteps 覆盖"; fi
  [ -z "${ALLOW_BUSY:-}" ] && p "未设 ALLOW_BUSY" || f "ALLOW_BUSY 已设 (本包不接受)"
  # 3 时间窗
  if [ "$(rem_s)" -gt 0 ]; then p "距 DEADLINE($DEADLINE) 剩 $(rem_h) h"; else f "已过 DEADLINE"; fi
  # AMENDMENT_01 (REVIEW S2, K 12:14): 完整版硬门槛 = 只允许在 FULL_CUTOFF 前新启动; 之后拒跑, 改用缩减版 (APPEND_TO 续跑同一套 run 不算新启动)
  if [ "$(cat $HERE/VARIANT 2>/dev/null)" = full ] && [ -z "${APPEND_TO:-}" ]; then
    if [ $(date +%s) -lt $(date -d "$FULL_CUTOFF" +%s) ]; then p "完整版: 现在早于 FULL_CUTOFF ($FULL_CUTOFF), 允许新启动"; else f "完整版只允许在 $FULL_CUTOFF 之前新启动; 现在 $(date '+%F %T %z') -> 拒跑, 请改用 R4N1_reduced 包"; fi; fi
  P=$(perf_eff); n2=$(need_h $REFB)
  echo "  [info] 有效速率 ${P} ns/day/槽 (PERF_NOM=$PERF_NOM F_THR=$F_THR; 估计非实测), 一条 $REFB (relax+闸+prod, 珠数缩放, 估算) 约需 ${n2} h; 剩余 $(rem_h) h ->" \
        "$(awk -v r=$(rem_h) -v n=$n2 -v t=$TAIL_H 'BEGIN{ if(r-t>=n) print "主批第 1 波可完整跑满"; else print "第 1 波 prod 会被 -maxh 截断; 用 NSTEPS 更短的包或向 K 报告"}')"
  # AMENDMENT_01 (REVIEW S3): 包与输出都须在 $HOME 下 (gatewrap 容器只挂 $HOME 和 /tmp); MODE=local 冒烟只提示
  for x in "$HERE" "$J"; do case "$(readlink -m "$x")/" in "$(readlink -m "$HOME")"/*) p "在 \$HOME 下: $x";; *) [ "$MODE" = local ] && echo "  [info] MODE=local: $x 不在 \$HOME 下 (仅 box 冒烟允许)" || f "$x 不在 \$HOME ($HOME) 下 (gate 容器只挂 \$HOME 和 /tmp)";; esac; done
  # 4 输入/链
  need_cmd || bad=1
  for b in $(rdlines $CA; rdlines $CB; rdlines $SPARES; rdlines $SUPPQ); do valid_name $b || { f "链/替补/补跑里有非法 build 或缺 expect.env: $b"; continue; }
    for x in start.gro sys.top index.ndx relax_$RELAX_ARM.mdp prod_$(arm_of $b).mdp $(grep -E '^#include' $INP/$b/sys.top 2>/dev/null | sed 's/.*"\(.*\)".*/\1/' | sort -u); do [ -s $INP/$b/$x ] || f "缺 $INP/$b/$x"; done
    [ "$(exp_of $b EXP_ARM)" = "$(arm_of $b)" ] || f "$b expect.env EXP_ARM=$(exp_of $b EXP_ARM) 与名字不符"; [ "T$(exp_of $b EXP_TEMP)" = "$(echo $b | sed -E 's/.*_(T[0-9]+)_.*/\1/')" ] || f "$b expect.env EXP_TEMP 与名字不符"
    [ "$(arm_of $b)" = hii ] && [ -z "$(exp_of $b BOX0)" ] && f "$b 缺 BOX0 (hii L2 闸门要用)"; done
  for b in $HIST_BAN; do (rdlines $CA; rdlines $CB; rdlines $SPARES; rdlines $SUPPQ) | grep -qx "$b" && f "禁用 build 入链: $b"; done
  [ -n "$(rdlines $CA)" ] && [ -n "$(rdlines $CB)" ] && p "chains: A=$(rdlines $CA | wc -l) 条 B=$(rdlines $CB | wc -l) 条 spares=$(rdlines $SPARES | wc -l) 补跑队列=$(rdlines $SUPPQ | wc -l)" || f "缺链文件"
  dup=$( (rdlines $CA; rdlines $CB; rdlines $SPARES; rdlines $SUPPQ) | sort | uniq -d | tr '\n' ' '); [ -z "$dup" ] && p "链/替补/补跑无重复 build" || f "重复 build: $dup"
  dup=$(for x in $HERE/chains/*.txt; do rdlines $x; done | sort | uniq -d | tr '\n' ' '); [ -z "$dup" ] && p "两机全部 chains/spares/supp 文件之间无同一 build 重复 (账本只按机, 跨机重复会被当成 2 个独立重复实验)" || f "跨机重复 build: $dup"
  # [R4N1x] ONLY: 每个 tok 须至少命中本机一条 build (防拼错后静默什么都不跑)
  if [ -n "$ONLY_TOKS" ]; then for x in $ONLY_TOKS; do n2=0; for b in $(rdlines $CA; rdlines $CB; rdlines $SPARES; rdlines $SUPPQ); do for g in $(groups_of $b); do [ "$g" = "$x" ] && n2=$((n2+1)); done; done
      [ $n2 -gt 0 ] && p "ONLY tok '$x' 命中本机 $n2 条" || f "ONLY tok '$x' 不命中本机任何 build (拼错? 本机格: $( (rdlines $CA; rdlines $CB; rdlines $SPARES; rdlines $SUPPQ) | while read b; do cell_of $b; done | sort -u | tr '\n' ' '))"; done
    echo "  [info] ONLY 生效: 本机将跑 $( (rdlines $CA; rdlines $CB; rdlines $SUPPQ) | while read b; do only_ok $b && echo $b; done | wc -l) 条主链/补跑 (+替补按 VOID)"; else p "ONLY 未设: 全跑"; fi
  # [R4N1x] 等主槽参数
  [ -z "$START_AT" ] || { date -d "$START_AT" +%s >/dev/null 2>&1 && p "START_AT=$START_AT 可解析 ($(date -d "$START_AT" '+%F %T %z'))" || f "START_AT='$START_AT' 无法解析"; }
  x=$(main_run); case "$WAIT_MAIN" in none) p "WAIT_MAIN=none: 不依赖主包, 只要求起跑时本槽无 ^R4N1_${MACHINE}_ 主包容器";; auto) [ -n "$x" ] && p "WAIT_MAIN=auto -> 主 run 目录 $x" || f "WAIT_MAIN=auto 但 $JMAIN/R4N1_run_${MACHINE}_* 不是恰好 1 个 (有 $(ls -1d $JMAIN/R4N1_run_${MACHINE}_* 2>/dev/null | wc -l) 个) -> 请显式 WAIT_MAIN=<目录>";;
    *) [ -d "$x/slots" ] && p "WAIT_MAIN=$x (有 slots/)" || f "WAIT_MAIN=$x 不是主 run 目录 (无 slots/)";; esac
  [ -n "$x" ] && for t in A B; do [ -f $x/slots/${MACHINE}_$t.log ] && echo "  [info] 主槽 ${MACHINE}_$t 日志末行: $(tail -1 $x/slots/${MACHINE}_$t.log | cut -c1-160)"; done
  # 5 进程/容器/MPS 冲突 (R2b M1: 60 s 复查; 不抢占)
  # [R4N1x] 主包 R4N1 允许在跑: 它的编排进程 (run_R4N1.sh)、容器 (^R4N1_<机>_)、容器内 gmx、它的 MPS 守护 (pipe 在 $HOME/mps_R4N1/ 下) 被认出并排除;
  #         其余一切照主包规则 FAIL (含: 认不出归属的 gmx、其它 R2a/R2b/R3/R4/j009 容器或脚本、另一个 run_R4N1x、认不出的 MPS 进程). 改动写在 README_R4N1x.md §4, 不是放宽.
  if [ "$MODE" = docker ]; then
    x=$(gmx_unattributed); [ -z "$x" ] && p "gmx 进程: $(pgrep -c gmx) 个, 全部在主包 ^R4N1_${MACHINE}_ 容器内 (认出并排除)" || f "有不属于主包容器的 gmx 进程: $x"
    x=$(procs_other $$ 'R2a_machine|R2a_slot|R2b_machine|R2b_slot|run_R2|run_prerun|preflight_R3|run_R3\.sh|run_R4\.sh|run_R4N1x\.sh'); [ -z "$x" ] && p "无 R2a/R2b/prerun/run_R3/run_R4/其它 run_R4N1x 脚本进程 (已排除本进程及其祖先/后代)" || f "有相关脚本进程: $(echo "$x" | head -3 | tr '\n' ';')"
    x=$(procs_other $$ 'run_R4N1\.sh'); [ -z "$x" ] && echo "  [info] 主包 run_R4N1.sh 编排进程: 无" || echo "  [info] 主包 run_R4N1.sh 编排进程在跑 (允许; 本包等它的槽): $(echo "$x" | head -2 | cut -c1-120 | tr '\n' ';')"
    if [ -n "${HAVE_LOCK:-}" ]; then p "已持有 flock $J/.R4N1x_${MACHINE}.flock"; elif test_lock; then p "flock 可得 (无同机 run_R4N1x 在跑)"; else f "flock 被占用: 同机已有 run_R4N1x 在跑"; fi
    x=$(docker ps --format '{{.Names}}' 2>/dev/null | grep -E '^(R2a_|R2b_|R3|R4_|R4N1x_|j009_)|^R4N1_' | grep -vE "^R4N1_${MACHINE}_[0-9]+_"); [ -z "$x" ] && p "docker ps 无 R2a_/R2b_/R3*/R4_/R4N1x_/j009_ 容器, 也无非本机编号的 R4N1_ 容器" || f "有占卡容器: $(echo "$x" | tr '\n' ' ')"
    echo "  [info] 主包容器 (允许): $(main_any_cn | tr '\n' ' ')"
    # MPS: 主包自己的守护 (pipe 在 $HOME/mps_R4N1/) 认出并排除; 其余 MPS 进程 = 残留, 先认人再 quit, 这里只认人, FAIL
    x=$(mps_unattributed); [ -z "$x" ] && p "nvidia-cuda-mps 进程: $(ps -eo args= | grep -c '[n]vidia-cuda-mps') 个, 全部认作主包 R4N1 的 (pipe 在 $HOME/mps_R4N1/)" || f "认不出归属的 MPS 进程 (先认人再 quit; 不 kill): $(echo "$x" | tr '\n' ';') -> bash $HERE/tools/mps_residue.sh; 别人的 -> 报 K/调度"
    [ "$X_MPS" = off ] && p "X_MPS=off: 本包全程不用 MPS" || p "X_MPS=auto: 主编排在时不用 MPS; 主编排退出且机上无 MPS 进程时起自己的全新 \$HOME/mps_R4N1x/${MACHINE}_<TS>"
    if [ $bad = 0 ]; then echo "  ... ${GUARD_RECHECK_S:-60}s 后复查 (R2b M1: 空档漏报)"; sleep ${GUARD_RECHECK_S:-60}; x=$(gmx_unattributed); [ -z "$x" ] && p "60 s 后仍无主包容器外的 gmx" || f "60 s 后出现主包容器外的 gmx: $x"; fi
    x=$(df -Pk "$(dirname $J)" 2>/dev/null | awk 'NR==2{printf "%d",$4/1048576}'); [ "${x:-0}" -ge 10 ] && p "磁盘可用 ${x} GiB" || f "磁盘可用 ${x:-?} GiB < 10 (AMENDMENT_01: SEL_KEEP_FRAMES=1 不删帧, 门槛 5->10)"
  else echo "  [info] MODE=local: 跳过 gmx/容器/MPS/磁盘冲突检查 (仅 box 冒烟)"; fi
  # 5b [TRR-AMEND] 取起点规则自检: 参数 + 容器内 trjconv 经 stdin (-i) 取组号能跑通 (用 start.gro 当 1 帧 "轨迹")
  if [ "$SEL_RULE" = 1 ]; then [ "$GATE_MODE" = host ] && p "SEL_RULE=1 取起点规则: relax 每 ${SEL_NSTOUT} 步写 trr, 末 ${SEL_WIN_PS} ps 逐帧闸门, 选最后合格帧 (SEL_KEEP_FRAMES=$SEL_KEEP_FRAMES)" || echo "  [warn] SEL_RULE=1 但 GATE_MODE=$GATE_MODE: 无自动逐帧闸门, 回退旧行为 (末帧+-t cpt)"
    case "$SEL_NSTOUT$SEL_WIN_PS" in *[!0-9]*|"") f "SEL_NSTOUT/SEL_WIN_PS 须为整数";; esac
  else echo "  [warn] SEL_RULE=0: 旧行为 (relax 末帧 + -t relax.cpt), 与已作废的预跑 0/6 读数同款起点, 不建议"; fi
  # 6 gmx 版本 + 闸门可执行 (真跑一次 builder 级闸门, 期望 PASS)
  GMXV=$(gmx_version); [ -n "$GMXV" ] && check_gmxv && p "gmx 版本 $GMXV" || f "gmx 版本检查失败 ('$GMXV', 期望 ${EXPECT_GMX:-2026.3})"
  if [ "$GATE_MODE" = host ]; then
    $GATE_PY -c 'import numpy, scipy, MDAnalysis' >/dev/null 2>&1 && p "闸门依赖 numpy/scipy/MDAnalysis 可导入 ($GATE_PY)" || f "GATE_PY=$GATE_PY 导不进 numpy/scipy/MDAnalysis (设 GATE_PY=<含依赖的 python>, 或 GATE_MODE=manual)"
    x=$(mktemp -d)
    if [ -n "$REFH" ]; then ( cd $x && $GATE_PY $HERE/gate/t0_gate_hii.py $INP/$REFH/start.gro --level relax --box0 $(exp_of $REFH BOX0) --expect-lipids $(exp_of $REFH EXP_LIP) --expect-w $(exp_of $REFH EXP_W) --json gh.json ) >/dev/null 2>&1 && p "H_II 闸门自检: $REFH/start.gro L2 PASS (rc=0)" || f "H_II 闸门自检失败 (应 PASS): $REFH"; fi
    if [ -n "$REFL" ]; then ( cd $x && $GATE_PY $HERE/gate/t0_gate_launch.py $INP/$REFL/start.gro --level builder --arm lam --expect-lipids $(exp_of $REFL EXP_LIP) --expect-w $(exp_of $REFL EXP_W) --json g.json ) >/dev/null 2>&1 && p "片层闸门自检: $REFL/start.gro PASS (rc=0)" || f "片层闸门自检失败 (应 PASS): $REFL"
      [ -n "$REFH" ] && { ( cd $x && $GATE_PY $HERE/gate/t0_gate_hii.py $INP/$REFL/start.gro --level relax --box0 $(exp_of $REFL BOX0) --expect-lipids $(exp_of $REFL EXP_LIP) --expect-w $(exp_of $REFL EXP_W) --json nh.json ) >/dev/null 2>&1; [ $? = 3 ] && p "H_II 闸门负自检: 片层起点判不合格 rc=3" || f "H_II 闸门负自检: 片层起点未得 rc=3"; }; fi
    ( cd $x && $GATE_PY $HERE/gate/t0_gate_launch.py $HERE/proof/neg_selftest_bridged.gro --level builder --arm lam --expect-lipids 960 --expect-w 720 --json h.json ) >/dev/null 2>&1 && f "闸门负自检: 已知桥连帧竟 PASS" || p "闸门负自检: 已知桥连帧 (R3 DOPC relax 末帧) 判不合格 rc!=0"
  else p "GATE_MODE=manual: 须有人在 $OUT/manual_gate/<build>.PASS|.VOID 放闸门结论 (每条 relax 后最长等 ${GATE_WAIT_MAX_H} h)"; fi
  if [ "$SEL_RULE" = 1 ]; then x=$OUT/seltest_$$; mkdir -p $x; ( cd $x && echo 0 | GXI=1 CN=$(cn_name seltest_$BASHPID) gx trjconv -f $INP/$REFB/start.gro -s $INP/$REFB/start.gro -sep -o t.gro ) > $x/trjconv.log 2>&1
    [ -n "$(ls $x/t*.gro 2>/dev/null)" ] && p "trjconv(stdin 组号) 自检通过" || f "trjconv 自检失败 (docker run -i / gmx trjconv?): $x/trjconv.log"; fi
  # 5c 两槽同时 grompp 自检 (真发车时两槽的第 1 条 build 会同时 grompp relax; 这里用各槽首条 build 同时跑, 验容器名不撞/2026.3 能 grompp 派生 mdp; 只写 $OUT/gpchk, 不 mdrun)
  y=$OUT/gpchk; mkdir -p $y; gpp=; for t in "chkA $(rdlines $CA | head -1)" "chkB $(rdlines $CB | head -1)"; do set -- $t
    ( SLOT_TAG=$1; b=$2; dd=$y/$1/$b/attempt_001; mkdir -p $dd; mdp=$dd/relax_$RELAX_ARM.mdp
      if [ "$SEL_RULE" = 1 ]; then awk '!($1=="nstxout"||$1=="nstvout")' $INP/$b/relax_$RELAX_ARM.mdp > $mdp; printf 'nstxout = %s\nnstvout = %s\n' $SEL_NSTOUT $SEL_NSTOUT >> $mdp; else cp $INP/$b/relax_$RELAX_ARM.mdp $mdp; fi
      gp $dd relax $mdp $INP/$b/start.gro $INP/$b/sys.top $INP/$b/index.ndx $MAXWARN_RELAX; echo "$GP_RC $GP_NW" > $dd/gp_rc_nw.txt ) & gpp="$gpp $!"; done; wait $gpp
  for t in chkA chkB; do r=$(cat $y/$t/*/attempt_001/gp_rc_nw.txt 2>/dev/null); if [ "$RELAX_ARM" = crescale_dev ]; then [ "$r" = "0 0" ] && p "两槽同时 grompp 自检 $t: rc=0 无 warning" || f "两槽同时 grompp 自检 $t 失败 (rc nwarn='$r'): $y/$t/*/attempt_001/grompp.log"
    else [ "${r%% *}" = 0 ] && p "两槽同时 grompp 自检 $t: rc=0 (literal, nwarn=${r#* })" || f "两槽同时 grompp 自检 $t 失败 ('$r'): $y/$t/*/attempt_001/grompp.log"; fi; done
  [ $bad = 0 ] && { echo "== launch_guard: ALL OK"; return 0; } || { echo "== launch_guard: FAIL (见 [FAIL])"; return 1; }; }
# ------------------------------------------------------------------ 补跑队列 (主批 10 条后空槽接活; 严格按下列优先级, 每个作业须过时间判断)
# 优先级: (1) L2 替补轮: 本机账本里有 VOID_L2 (或 relax 失败, 见 REPLACE_ON_RELAX_FAIL) 的格, 取 spares_<机>.txt 里同格未用的替补 build, 再 relax+gate+prod
#         (2) chains/supp_<机>.txt 按文件顺序 (R4N1: 见 README_R4N1.md).
# 时间判断 supp_fits: 剩余墙钟 >= need_h + SUPP_MARGIN_H(0.75=45min) 且 now+need_h < DEADLINE; 不过则记 SUPP_SKIP_NO_TIME 并看下一个候选 (更短的作业可能放得下).
supp_fits(){ local b=$1 n; n=$(need_h $b); SUPP_NEED=$n
  awk -v r=$(rem_h) -v n=$n -v m=$SUPP_MARGIN_H 'BEGIN{exit !(r>=n+m)}' && [ $(( $(date +%s) + $(awk -v n=$n 'BEGIN{printf "%d", n*3600}') )) -lt $DL ]; }
claim_supp(){ local cell v s line b; CLAIM_B=; CLAIM_ROLE=; CLAIM_NOTE=; halted && return 1
  for cell in $(for b in $(rdlines $CA; rdlines $CB; rdlines $SPARES); do cell_of $b; done | sort -u); do
    for v in $(ledger_list void); do [ "$(cell_of $v)" = "$cell" ] || continue; ledger_has replfor $v && continue
      for s in $(rdlines $SPARES); do [ "$(cell_of $s)" = "$cell" ] || continue; ledger_has claim $s && continue
        supp_fits $s || { ledger_claim skipnote ${SLOT_TAG}.$s && rec skip $s repl - - SUPP_SKIP_NO_TIME - - - - - - $SUPP_NEED "替补(for $v) 剩余不足 need+${SUPP_MARGIN_H}h"; continue; }
        ledger_claim replfor $v || continue; ledger_claim claim $s || { rmdir $OUT/ledger/replfor/$v; continue; }
        CLAIM_B=$s; CLAIM_ROLE=replacement; CLAIM_NOTE="replaces=$v"; return 0; done
      [ -n "$(for s in $(rdlines $SPARES); do [ "$(cell_of $s)" = "$cell" ] && echo $s; done)" ] || { ledger_claim noted nospare_$v && { rec skip $v repl - - NO_SPARE - - - - - - - "格 $cell 无替补 build -> 该格 n<3, 按 PREREG_R4_3day 记 NOT_EVALUABLE"; say "NO_SPARE: $v 无替补"; }; }
    done; done
  for b in $(rdlines $SUPPQ); do ledger_has claim $b && continue; only_ok $b || { ledger_claim skipnote only.$b && rec skip $b supp - - SKIP_NOT_ONLY - - - - - - - "ONLY=$ONLY_TOKS"; continue; }   # [R4N1x]
    supp_fits $b || { ledger_claim skipnote ${SLOT_TAG}.$b && rec skip $b supp - - SUPP_SKIP_NO_TIME - - - - - - $SUPP_NEED "补跑剩余不足 need+${SUPP_MARGIN_H}h"; continue; }
    ledger_claim claim $b || continue; CLAIM_B=$b; CLAIM_ROLE=supplement; CLAIM_NOTE="queue=$(basename $SUPPQ)"; return 0; done
  return 1; }
slot(){ local tag=$1 po=$2 ch=$3 b
  SLOT_TAG=$tag; say "== slot start chain=$ch pinoffset=$po NT=$NT deadline=$DEADLINE gate=$GATE_MODE relax=$RELAX_ARM"
  wait_slot ${tag#${MACHINE}_} || { say "== slot end (未起: 等待放弃)"; return 0; }   # [R4N1x]
  for b in $(rdlines $ch); do only_ok $b || { ledger_claim skipnote only.$b && rec skip $b primary - - SKIP_NOT_ONLY - - - - - - - "ONLY=$ONLY_TOKS"; continue; }
    ledger_claim claim $b || { say "$b 已被领取过 (APPEND_TO 续跑: run_build 自身幂等, 继续)"; }; x_mps_pick; say "MPS for $b: $X_MPS_NOTE"; run_build $b primary $po main; say "END $b rc=$? mps=$X_MPS_NOTE"; done
  if [ "$SUPP" = 1 ]; then while claim_supp; do x_mps_pick; say "补跑领取 $CLAIM_B ($CLAIM_ROLE $CLAIM_NOTE) need=${SUPP_NEED}h remaining=$(rem_h)h mps=$X_MPS_NOTE"; run_build $CLAIM_B $CLAIM_ROLE $po supp "$CLAIM_NOTE mps=$X_MPS_NOTE"; say "END $CLAIM_B rc=$?"; done; fi
  say "== slot end"; }
summary(){ echo "== summary $MACHINE $(date '+%F %T %z')"; printf 'build\trelax\tgate\tprod\n'
  for d in $OUT/builds/*/; do b=$(basename $d); printf '%s\t%s\t%s\t%s\n' $b $(last_state $d/relax) $(last_state $d/gate) $(last_state $d/prod); done | tee $OUT/SUMMARY.tsv
  for c in $(for b in $(rdlines $CA; rdlines $CB; rdlines $SPARES); do cell_of $b; done | sort -u); do v=$(for x in $(ledger_list void); do [ "$(cell_of $x)" = "$c" ] && echo $x; done | wc -l); g=$(for x in $OUT/builds/*/gate; do [ -d $x ] && [ "$(cell_of $(basename $(dirname $x)))" = "$c" ] && echo $x; done | wc -l); echo "L2 void_rate $c(本机): $v / $g 个已读闸 (L1 见 inputs/L1_summary.tsv)"; done | tee -a $OUT/SUMMARY.tsv
  for v in $(ledger_list void); do ledger_has replfor $v || echo "UNRESOLVED_VOID $v (无替补/时间不足 -> 该格 n 减少, 判读按 PREREG_R4_3day NOT_EVALUABLE/n<3 处理)"; done | tee -a $OUT/SUMMARY.tsv; }
# ------------------------------------------------------------------ main
if [ -n "${CHECK:-}" ]; then OUT=/tmp/R4N1x_check_$$; mkdir -p $OUT/slots; OUT_PARENT=$OUT; launch_guard; exit $?; fi
if [ -n "${DRY:-}" ]; then
  OUT=$(mktemp -d /tmp/R4N1x_dry_XXXXXX); OUT_PARENT=$OUT; mkdir -p $OUT/slots $OUT/ledger; SLOT_TAG=dry; GMXV=dry
  echo "== DRY machine=$MACHINE MODE=$MODE relax=$RELAX_ARM maxwarn(relax/prod)=$MAXWARN_RELAX/$MAXWARN_PROD deadline=$DEADLINE remaining=$(rem_h)h P=$(perf_eff) ns/day (PERF_NOM=$PERF_NOM F_THR=$F_THR) 不建输出/不起 MPS/容器"
  for t in "A $PINA $CA" "B $PINB $CB"; do set -- $t; t0=$(date +%s); echo "-- slot ${MACHINE}_$1 pin=$2 (顺序执行)"
    for b in $(rdlines $3); do n=$(need_h $b); st=$(date -d @$t0 '+%m-%d %H:%M'); t0=$((t0+$(awk -v n=$n 'BEGIN{printf "%d", n*3600}'))); echo "   $b need=${n}h  预计 $st -> $(date -d @$t0 '+%m-%d %H:%M')  $(awk -v t=$t0 -v d=$DL 'BEGIN{print (t+0>d+0)?"[超 deadline: 会被 -maxh 截断/SKIP]":""}')"
      echo "      [TRR-AMEND] SEL_RULE=$SEL_RULE ($(arm_of $b)): relax 加 nstxout=nstvout=$SEL_NSTOUT -> 末 ${SEL_WIN_PS}ps trr 帧逐帧闸门 -> 选最后合格帧作 prod -c (无 -t); 0 合格 -> VOID_L2"; echo "      relax: grompp -f relax_$RELAX_ARM.mdp -c start.gro -maxwarn $MAXWARN_RELAX; mdrun | gate($GATE_MODE) | prod: $( [ "$SEL_RULE" = 1 ] && echo "grompp -f prod_$(arm_of $b).mdp -c selected.gro (无 -t; 起点 sha 须与闸门判过的一致, 否则 VOID_SEL_MISMATCH; SEL_SKIP 时回退 -c relax.gro -t relax.cpt)" || echo "grompp -f prod_$(arm_of $b).mdp -c relax.gro -t relax.cpt" ) -maxwarn $MAXWARN_PROD; mdrun -maxh=(剩余-${TAIL_H}h)"; done; done
  echo "-- [R4N1x] 实际起点不是 '现在': 每槽等主包同槽 done (WAIT_MAIN=$WAIT_MAIN main_run=$(main_run) START_AT=${START_AT:-无}); 上面时刻按 '现在' 起算, 只看相对长度; 估计结束见 PLAN_ESTIMATE.json"
  echo "-- [R4N1x] ONLY=${ONLY_TOKS:-无(全跑)}: $(for b in $(rdlines $CA; rdlines $CB; rdlines $SUPPQ); do only_ok $b || echo -n "$b(跳过) "; done)"
  echo "-- 补跑队列 (SUPP=$SUPP; 各作业此刻的时间判断; 实际领取发生在槽主链结束时, 此处按 '现在' 评估):"
  for b in $(rdlines $SPARES) $(rdlines $SUPPQ); do supp_fits $b && r=FITS || r=SKIP_NO_TIME; echo "   $b need=${SUPP_NEED}h rem=$(rem_h)h margin=${SUPP_MARGIN_H}h -> $r"; done
  echo "   (优先级: 1 L2 替补[spares: $(rdlines $SPARES | tr '\n' ' ')] -> 2/3 supp 队列顺序 [$(rdlines $SUPPQ | tr '\n' ' ')])"
  exit 0; fi
need_cmd || exit 1
take_lock || { echo "ABORT: 同机 run_R4N1x 已在运行 (flock $J/.R4N1x_${MACHINE}.flock)"; exit 1; }; HAVE_LOCK=1
init_out $MACHINE || exit 1; exec > >(tee -a $OUT/orchestrator.log) 2>&1
echo "OUT=$OUT"; launch_guard || { echo "ABORT: 发车判据不过, 未起 MPS/容器"; exit 1; }
GMXV=${GMXV:-unknown}
{ echo "machine=$MACHINE host=$(hostname) start=$(date '+%F %T %z') deadline=$DEADLINE gmx=$GMXV mode=$MODE"; env | grep -E '^(ONLY|ONLY_FILE|WAIT_|START_AT|GO_QUIET|JMAIN|X_MPS|RELAX_ARM|MAXWARN_|K_APPROVED|F_THR|PERF_NOM|GATE_|SUPP|REPLACE_|SEL_|NT=|PINA|PINB|TAIL_H|MINRUN_H|IMG=|J=|EXPECT_GMX|PRIO|PERF_)' | sort; echo "PRIO=$PRIO NICE=$NICE CPUSH=$CPUSH"; echo "ONLY_TOKS=$ONLY_TOKS"; (cd $HERE && sha256sum run_R4N1x.sh lib_R4N1x.sh MANIFEST_sha256.txt verdict_R4_3day.py verdict_Larm.py PREREG_R4_3day.md PRE_REG_AMENDMENT_R4N1_02.md VARIANT); } > $OUT/RUN_META.txt
# [R4N1x] 不在这里起 MPS (主包可能仍在跑); 每条 build 前 x_mps_pick 决定, 见 lib_R4N1x.sh
cleanup(){ echo "[$(date '+%F %T')] INTERRUPT/EXIT: 只停本脚本容器 ${CN_PREFIX}${MACHINE}_${ORCH_PID}_*"; [ "$MODE" = local ] || { for c in $(docker ps --format '{{.Names}}' | grep "^${CN_PREFIX}${MACHINE}_${ORCH_PID}_"); do docker stop -t 120 $c >/dev/null 2>&1; done; }; }
trap 'cleanup; kill $PA $PB 2>/dev/null; wait $PA $PB 2>/dev/null; x_mps_stop; exit 143' INT TERM
( slot ${MACHINE}_A $PINA $CA ) & PA=$!
( slot ${MACHINE}_B $PINB $CB ) & PB=$!
wait $PA $PB; x_mps_stop; summary; echo "== machine $MACHINE done $(date '+%F %T %z') OUT=$OUT"
