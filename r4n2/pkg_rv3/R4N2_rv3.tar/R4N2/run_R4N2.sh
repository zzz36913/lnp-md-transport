#!/bin/bash
# [R4N2] run_R4N2.sh -- R4N1 第 2 晚包 (10-31 14:00 -> 11-01 07:30, 数据 07:30 收). 由 run_R4N1x.sh 复制, 只改 [R4N2] 标记处:
#   每槽顺序: (1) chains/ext_<机>_<A|B>.txt 续跑 (C2 H_II 400 ns -> 1.2 µs, 从本机第 1 晚终点续) -> (2) chains/<机>_<A|B>.txt 新起主链 (本包为空)
#            -> (3) 补跑循环 SUPP=1: L2 替补 (spares) -> chains/supp_<机>.txt (C4 新起) -> [FILL=1 时] chains/fill_<机>.txt (续到 2 µs, 须先有本 OUT 1.2 µs DONE)
#   K 待定 3 项只留开关: K_C2_3SYS=yes|no (必填, 无默认; no -> C2 续跑全部 SKIP_K_C2_3SYS) / K_PR_SALT=none (其它值 FAIL: 本包无 PR/盐 内容) / K_VOID_FIX_N3=off (其它值 FAIL: 第 3 晚另包)
#   第 2 晚无主包: WAIT_MAIN 默认 none, 机上任何 R4N1_/R4N1x_/R4N2_ 容器、认不出的 gmx/MPS 一律 FAIL.
# run_R4N1x.sh -- R4N1x 追加包 (PRE_REG_AMENDMENT_R4N1_02): 主包 R4N1 (已发, 不改) 某槽主链跑完后接着跑:
#   L 臂 (优先): 长盒 H_II, K1 检验; h050 T320, DOPE/DOPC, Lz 约 22 nm (DOPC 21.93 / DOPE 38.18), n=3 (+ s4 替补), 名字 R4N1_<体系>_h050_T320_hiiL_s<k>
#   C4: 350 K h100, 4 体系 × (hii, lam), n=3, 400 ns, 原 PREREG 判据; 放不下的按 K 12:42 裁剪序 (先内标 MC3H/MC3, 再 lam 臂) 进 supp 队列 (有时间才跑, 否则第 2 晚)
# 由 run_R4N1.sh 复制, 只改 [R4N1x] 处: 等待启动器 (wait_slot, 每槽), ONLY 过滤, 追加包 MPS (x_mps_pick), launch_guard 第 5 节 (主包在跑时的冲突检查改为 "认出主包的、排除它、其余照旧 FAIL").
# 用法:  WAIT_MAIN=auto bash run_R4N1x.sh <k03|k04>    正式: 过 launch_guard 后两槽各自等主包同槽 done 再起 (见 lib_R4N1x.sh "等主槽")
#        START_AT="2026-10-30 21:00 +0800" ...           调度手动接入时间点 (此前不起; 到点后仍要求槽空)
#        touch $OUT/slots/<机>_<A|B>.GO                    调度手动接入 (确认主槽不会再起新条; 再等 GO_QUIET_S 无主包容器即起)
#        ONLY="Larm" / ONLY="DOPC_h050_T320_hiiL,C4hii" / ONLY_FILE=<文件> ...   只跑挑出来的条目 (分段闭环)
#        CHECK=1 / DRY=1 / APPEND_TO=<R4N1x_run_目录> / NEW_RUN=1 同主包
# 判读: C4 用冻结的 verdict_R4_3day.py (与主包合并 inputs, 见 README_R4N1x.md §6); L 臂用 verdict_Larm.py (只 import 冻结函数).
# 不覆写/不 rm; MPS 先认人再 quit, 只 quit 自己的 pipe, 不 kill, 不删目录; 主包的 MPS/容器/目录一概不碰 (只读其日志与 docker ps).
HERE=$(cd "$(dirname "$0")" && pwd); MACHINE=${1:?usage: bash run_R4N2.sh <k03|k04>}; ORCH_PID=$$
case $MACHINE in k03|k04) ;; *) echo "ABORT: 机器名须为 k03 或 k04"; exit 1;; esac
. "$HERE/lib_R4N2.sh"
rdlines0(){ grep -vE '^\s*(#|$)' "$1" | awk '{print $1}'; }
REFB=$(cat $HERE/chains/${MACHINE}_A.txt $HERE/chains/${MACHINE}_B.txt $HERE/chains/supp_${MACHINE}.txt 2>/dev/null | rdlines0 /dev/stdin | head -1)   # [R4N2] 估时参考 build = 本机第一条新起 build (A/B 主链为空时取 supp 第一条)
REFH=$(cat $HERE/chains/${MACHINE}_[AB].txt $HERE/chains/supp_${MACHINE}.txt | rdlines0 /dev/stdin | grep -E '_hiiL?_' | head -1); REFL=$(cat $HERE/chains/[!ef]*.txt | rdlines0 /dev/stdin | grep '_lam_' | head -1)   # 闸门自检用 (各臂一条) [R4N1x] 本包主链无 lam (全在 supp), REFL 从全部链/supp/替补文件取
CA=$HERE/chains/${MACHINE}_A.txt; CB=$HERE/chains/${MACHINE}_B.txt; SPARES=$HERE/chains/spares_${MACHINE}.txt; SUPPQ=$HERE/chains/supp_${MACHINE}.txt
rdlines(){ [ -f "$1" ] && grep -vE '^\s*(#|$)' "$1" | awk '{print $1}'; }
# [R4N2] 续跑链: "<build> <目标ns>"; rdext 输出 "build:目标"
EA=$HERE/chains/ext_${MACHINE}_A.txt; EB=$HERE/chains/ext_${MACHINE}_B.txt; FILLQ=$HERE/chains/fill_${MACHINE}.txt; FILL=${FILL:-0}
rdext(){ [ -f "$1" ] && grep -vE '^\s*(#|$)' "$1" | awk '{print $1":"$2}'; }
rdkeys(){ [ -f "$1" ] && grep -vE '^\s*(#|$)' "$1" | awk '{print $1 ($2==""?"":":"$2)}'; }
K_C2_3SYS=${K_C2_3SYS:-}; K_PR_SALT=${K_PR_SALT:-none}; K_VOID_FIX_N3=${K_VOID_FIX_N3:-off}
PRIOR_RUNS=${PRIOR_RUNS:-"$HOME/R4N1/R4N1_run_${MACHINE}_* $HOME/R4N1x/R4N1x_run_${MACHINE}_*"}   # 第 1 晚本机 run 目录 (只读): 新起 build 在这里已 DONE/VOID -> FAIL
k_c2_skip(){ case $1 in *_h050_T350_*) [ "$K_C2_3SYS" = yes ] || return 0;; esac; return 1; }   # 0 = 该 ext 条因 K 决定 #1 跳过
# ------------------------------------------------------------------ 发车判据 (R2b REVIEW §4 同款多条件 + R3 专项)
f(){ echo "  [FAIL] $*"; bad=1; }; p(){ echo "  [ok]   $*"; }
launch_guard(){ local b x dup P n2; bad=0
  echo "== launch_guard machine=$MACHINE MODE=$MODE variant=$(cat $HERE/VARIANT 2>/dev/null) $(date '+%F %T %z')"
  [ -n "$(cat $HERE/VARIANT 2>/dev/null)" ] && p "VARIANT=$(cat $HERE/VARIANT)" || f "缺 VARIANT 文件"
  # 1 包完整
  ( cd $HERE && sha256sum -c MANIFEST_sha256.txt --quiet ) >/dev/null 2>&1 && p "MANIFEST sha256 全 OK" || f "包与 MANIFEST_sha256.txt 不符 (cd $HERE && sha256sum -c MANIFEST_sha256.txt)"
  # 2 参数/开关
  [ "$MAXWARN_PROD" = 0 ] && p "MAXWARN_PROD=0" || f "MAXWARN_PROD=$MAXWARN_PROD (须 0; prod 警告须看见, 非 0 需改包)"
  case $RELAX_ARM in
    crescale_dev) [ "$MAXWARN_RELAX" = 0 ] && p "RELAX_ARM=crescale_dev (偏离 SI 协议的开发臂), MAXWARN_RELAX=0" || f "crescale_dev 不需要 maxwarn, MAXWARN_RELAX=$MAXWARN_RELAX 须 0";;
    literal) if [ "$K_APPROVED_LITERAL" = yes ] && [ "$MAXWARN_RELAX" = 2 ]; then p "RELAX_ARM=literal, K_APPROVED_LITERAL=yes, MAXWARN_RELAX=2 (逐字核对 2 条警告; 不符则 HALT)"; else f "literal 须同时 K_APPROVED_LITERAL=yes 且 MAXWARN_RELAX=2 (现 '$K_APPROVED_LITERAL'/$MAXWARN_RELAX)"; fi;;
    *) f "RELAX_ARM=$RELAX_ARM 非法";; esac
  if [ -n "${NSTEPS_OVERRIDE_RELAX}${NSTEPS_OVERRIDE_PROD}" ]; then [ "$MODE" = local ] && p "NSTEPS_OVERRIDE_* 已设 (MODE=local 冒烟)" || f "NSTEPS_OVERRIDE_* 只允许 MODE=local"; else p "无 nsteps 覆盖"; fi
  [ -z "${ALLOW_BUSY:-}" ] && p "未设 ALLOW_BUSY" || f "ALLOW_BUSY 已设 (本包不接受)"
  # [R4N2] K 待定 3 项 (只留开关, 不放内容)
  if [ -n "$( (rdext $EA; rdext $EB; [ "$FILL" = 1 ] && rdext $FILLQ) | grep '_h050_T350_')" ]; then case "$K_C2_3SYS" in
      yes) p "K_C2_3SYS=yes: C2 (MC3 无起点, 3 体系) 按 '四体系同跑' 计, C2 续跑照跑";; no) p "K_C2_3SYS=no: C2 续跑全部 SKIP_K_C2_3SYS (N2-a 整格延后), 其余照跑";;
      *) f "K_C2_3SYS 未填 ('$K_C2_3SYS'): K 决定 #1 (C2 三体系算不算四体系同跑) 须显式 yes|no";; esac; else p "本机无 C2 续跑条目 (K_C2_3SYS 不影响)"; fi
  [ "$K_PR_SALT" = none ] && p "K_PR_SALT=none (PR/盐 预注册修订: 本包无内容)" || f "K_PR_SALT=$K_PR_SALT: 本包未实现 PR/盐 修订, 须 K 批准后另出包+审查"
  [ "$K_VOID_FIX_N3" = off ] && p "K_VOID_FIX_N3=off (VOID 修复属第 3 晚)" || f "K_VOID_FIX_N3=$K_VOID_FIX_N3: 本包未实现, 第 3 晚另包"
  case "$FILL" in 0) p "FILL=0: 不跑 fill (续到 2 µs)";; 1) [ "$K_C2_3SYS" = yes ] && p "FILL=1: 补跑队列空后续 fill_${MACHINE}.txt ($(rdext $FILLQ | wc -l) 条, 须本 OUT 1.2 µs DONE; 需 K 另批算力)" || f "FILL=1 须 K_C2_3SYS=yes";; *) f "FILL=$FILL 须 0|1";; esac
  # 3 时间窗
  if [ "$(rem_s)" -gt 0 ]; then p "距 DEADLINE($DEADLINE) 剩 $(rem_h) h"; else f "已过 DEADLINE"; fi
  # [R4N2-rv1] DEADLINE 硬上限 (不可经 env 改): 11-01 08:00 GLM 交还前停机. 晚于上限 -> FAIL
  DL_CAP="2026-11-01 07:30 +0800"; if [ "$(date -d "$DEADLINE" +%s 2>/dev/null || echo 9999999999)" -le "$(date -d "$DL_CAP" +%s)" ]; then p "DEADLINE <= 硬上限 $DL_CAP"; else f "DEADLINE=$DEADLINE 晚于硬上限 $DL_CAP (08:00 GLM 交还) 或无法解析"; fi
  # AMENDMENT_01 (REVIEW S2, K 12:14): 完整版硬门槛 = 只允许在 FULL_CUTOFF 前新启动; 之后拒跑, 改用缩减版 (APPEND_TO 续跑同一套 run 不算新启动)
  if [ "$(cat $HERE/VARIANT 2>/dev/null)" = full ] && [ -z "${APPEND_TO:-}" ]; then
    if [ $(date +%s) -lt $(date -d "$FULL_CUTOFF" +%s) ]; then p "完整版: 现在早于 FULL_CUTOFF ($FULL_CUTOFF), 允许新启动"; else f "完整版只允许在 $FULL_CUTOFF 之前新启动; 现在 $(date '+%F %T %z') -> 拒跑, 请改用 R4N1_reduced 包"; fi; fi
  P=$(perf_eff); n2=$(need_h $REFB)
  echo "  [info] 有效速率 ${P} ns/day/槽 (PERF_NOM=$PERF_NOM F_THR=$F_THR; 估计非实测), 一条 $REFB (relax+闸+prod, 珠数缩放, 估算) 约需 ${n2} h; 剩余 $(rem_h) h ->" \
        "$(awk -v r=$(rem_h) -v n=$n2 -v t=$TAIL_H 'BEGIN{ if(r-t>=n) print "主批第 1 波可完整跑满"; else print "第 1 波 prod 会被 -maxh 截断; 用 NSTEPS 更短的包或向 K 报告"}')"
  # AMENDMENT_01 (REVIEW S3): 包与输出都须在 $HOME 下 (gatewrap 容器只挂 $HOME 和 /tmp); MODE=local 冒烟只提示
  for x in "$HERE" "$J"; do case "$(readlink -m "$x")/" in "$(readlink -m "$HOME")"/*) p "在 \$HOME 下: $x";; *) [ "$MODE" = local ] && echo "  [info] MODE=local: $x 不在 \$HOME 下 (仅 box 冒烟允许)" || f "$x 不在 \$HOME ($HOME) 下 (gate 容器只挂 \$HOME 和 /tmp)";; esac; done
  # 4 输入/链
  need_cmd || bad=1
  for b in $(rdlines $CA; rdlines $CB; rdlines $SPARES; rdlines $SUPPQ); do valid_name $b || { f "链/替补/补跑里有非法 build 或缺 expect.env: $b"; continue; }
    for x in start.gro sys.top index.ndx relax_$RELAX_ARM.mdp prod_$(arm_of $b).mdp $(grep -E '^#include' $INP/$b/sys.top 2>/dev/null | sed 's/.*"\(.*\)".*/\1/' | sort -u); do [ -s $INP/$b/$x ] || f "缺 $INP/$b/$x"; done
    [ "$(exp_of $b EXP_ARM)" = "$(arm_of $b)" ] || f "$b expect.env EXP_ARM=$(exp_of $b EXP_ARM) 与名字不符"; [ "T$(exp_of $b EXP_TEMP)" = "$(echo $b | sed -E 's/.*_(T[0-9]+)_.*/\1/')" ] || f "$b expect.env EXP_TEMP 与名字不符"
    [ "$(arm_of $b)" = hii ] && [ -z "$(exp_of $b BOX0)" ] && f "$b 缺 BOX0 (hii L2 闸门要用)"; done
  for b in $HIST_BAN; do (rdlines $CA; rdlines $CB; rdlines $SPARES; rdlines $SUPPQ) | grep -qx "$b" && f "禁用 build 入链: $b"; done
  [ -f $CA ] && [ -f $CB ] && [ -f $EA ] && [ -f $EB ] && [ -n "$(rdlines $CA; rdlines $CB; rdext $EA; rdext $EB; rdlines $SUPPQ)" ] && p "chains: ext A=$(rdext $EA | wc -l) B=$(rdext $EB | wc -l) | 新起 A=$(rdlines $CA | wc -l) B=$(rdlines $CB | wc -l) spares=$(rdlines $SPARES | wc -l) 补跑队列=$(rdlines $SUPPQ | wc -l) fill=$(rdext $FILLQ | wc -l)" || f "缺链文件或全空"
  dup=$( (rdlines $CA; rdlines $CB; rdlines $SPARES; rdlines $SUPPQ) | sort | uniq -d | tr '\n' ' '); [ -z "$dup" ] && p "链/替补/补跑无重复 build" || f "重复 build: $dup"
  dup=$(for x in $HERE/chains/*.txt; do rdkeys $x; done | sort | uniq -d | tr '\n' ' '); [ -z "$dup" ] && p "两机全部 chains/spares/supp 文件之间无同一 build 重复 (账本只按机, 跨机重复会被当成 2 个独立重复实验)" || f "跨机重复 build: $dup"
  # [R4N2] 新起 build 不得在第 1 晚本机 run 里已 DONE/VOID (账本为准; 只读 PRIOR_RUNS)
  for b in $(rdlines $CA; rdlines $CB; rdlines $SPARES; rdlines $SUPPQ); do x=; for g in $PRIOR_RUNS; do [ -d $g/builds/$b ] || continue
      done_dir $g/builds/$b/prod DONE >/dev/null && x="$x prod_DONE@$(basename $g)"; done_dir $g/builds/$b/gate VOID_L2 >/dev/null && x="$x VOID_L2@$(basename $g)"
      [ -z "$x" ] && echo "  [info] $b 在 $(basename $g) 有记录但未 DONE/VOID (新 OUT 从头跑)"; done
    [ -n "$x" ] && f "新起 build $b 第 1 晚已有结论:$x (重跑=重复实验; 删出队列)"; done
  for g0 in $PRIOR_RUNS; do [ -d "$g0" ] || f "PRIOR_RUNS 项 $g0 未命中任何目录 (glob 写错/目录名不对 -> 查重形同虚设; 显式给出第 1 晚本机 run 目录)"; done   # [R4N2-rv1]
  [ -n "$PRIOR_RUNS" ] && p "新起 build 与第 1 晚本机账本无重复 (PRIOR_RUNS=$(for g in $PRIOR_RUNS; do [ -d $g ] && basename $g; done | tr '\n' ' '))"
  # [R4N2] 续跑条目: 名字/臂/源 (源只读核对: DONE + laststep + tpr/cpt sha = SHA256_out.txt)
  for x in $(rdext $EA; rdext $EB; [ "$FILL" = 1 ] && rdext $FILLQ); do b=${x%%:*}; n2=${x##*:}
    valid_name $b && [ "$(arm_of $b)" = hii ] || { f "ext 条目非法/非 hii/缺 expect.env: $x"; continue; }
    case "$n2" in ''|*[!0-9]*) f "ext 目标须为整数 ns: $x"; continue;; esac
    k_c2_skip $b && { echo "  [info] $x: K_C2_3SYS=$K_C2_3SYS -> 将 SKIP"; continue; }
    if rdext $FILLQ | grep -qx "$x" && ! (rdext $EA; rdext $EB) | grep -qx "$x"; then echo "  [info] fill $x: 源 = 本 OUT 低一段 DONE (起跑时才有)"; continue; fi
    if ext_src $b $n2; then p "ext $b -> ${n2} ns: 源 $EXT_SRC_KIND $EXT_SRC_DIR ($ES_MSG)"; else f "ext $b -> ${n2} ns 无合格源: $ES_MSG"; fi; done
  # [R4N1x] ONLY: 每个 tok 须至少命中本机一条 build (防拼错后静默什么都不跑)
  if [ -n "$ONLY_TOKS" ]; then for x in $ONLY_TOKS; do n2=0; for b in $(rdlines $CA; rdlines $CB; rdlines $SPARES; rdlines $SUPPQ); do for g in $(groups_of $b); do [ "$g" = "$x" ] && n2=$((n2+1)); done; done
      [ $n2 -gt 0 ] && p "ONLY tok '$x' 命中本机 $n2 条" || f "ONLY tok '$x' 不命中本机任何 build (拼错? 本机格: $( (rdlines $CA; rdlines $CB; rdlines $SPARES; rdlines $SUPPQ) | while read b; do cell_of $b; done | sort -u | tr '\n' ' '))"; done
    echo "  [info] ONLY 生效: 本机将跑 $( (rdlines $CA; rdlines $CB; rdlines $SUPPQ) | while read b; do only_ok $b && echo $b; done | wc -l) 条主链/补跑 (+替补按 VOID)"; else p "ONLY 未设: 全跑"; fi
  # [R4N1x] 等主槽参数
  [ -z "$START_AT" ] || { date -d "$START_AT" +%s >/dev/null 2>&1 && p "START_AT=$START_AT 可解析 ($(date -d "$START_AT" '+%F %T %z'))" || f "START_AT='$START_AT' 无法解析"; }
  x=$(main_run); case "$WAIT_MAIN" in none) p "WAIT_MAIN=none: 不依赖主包, 只要求起跑时本槽无 ^R4N1_${MACHINE}_ 主包容器";; auto) [ -n "$x" ] && p "WAIT_MAIN=auto -> 主 run 目录 $x" || f "WAIT_MAIN=auto 但 $JMAIN/R4N1_run_${MACHINE}_* 不是恰好 1 个 (有 $(ls -1d $JMAIN/R4N1_run_${MACHINE}_* 2>/dev/null | wc -l) 个) -> 请显式 WAIT_MAIN=<目录>";;
    *) [ -d "$x/slots" ] && p "WAIT_MAIN=$x (有 slots/)" || f "WAIT_MAIN=$x 不是主 run 目录 (无 slots/)";; esac
  [ -n "$x" ] && for t in A B; do [ -f $x/slots/${MACHINE}_$t.log ] && echo "  [info] 主槽 ${MACHINE}_$t 日志末行: $(tail -1 $x/slots/${MACHINE}_$t.log | cut -c1-160)"; done
  # 5 进程/容器/MPS 冲突 (R2b M1: 60 s 复查; 不抢占)
  # [R4N1x] 主包 R4N1 允许在跑: 它的编排进程 (run_R4N1.sh)、容器 (^R4N1_<机>_)、容器内 gmx、它的 MPS 守护 (pipe 在 $HOME/mps_R4N1/ 下) 被认出并排除;
  #         其余一切照主包规则 FAIL (含: 认不出归属的 gmx、其它 R2a/R2b/R3/R4/j009 容器或脚本、另一个 run_R4N1x、认不出的 MPS 进程). 改动写在 README_R4N1x.md §4, 不是放宽.
  if [ "$MODE" = docker ]; then
    x=$(gmx_unattributed); [ -z "$x" ] && p "gmx 进程: $(pgrep -c gmx) 个, 全部在主包 ^R4N1_${MACHINE}_ 容器内 (认出并排除)" || f "有不属于主包容器的 gmx 进程: $x"
    x=$(procs_other $$ 'R2a_machine|R2a_slot|R2b_machine|R2b_slot|run_R2|run_prerun|preflight_R3|run_R3\.sh|run_R4\.sh|run_R4N1x\.sh|run_R4N2\.sh'"$( [ "$WAIT_MAIN" = none ] && echo '|run_R4N1\.sh')"); [ -z "$x" ] && p "无 R2a/R2b/prerun/run_R3/run_R4/run_R4N1x/其它 run_R4N2 脚本进程 (WAIT_MAIN=$WAIT_MAIN; none 时 run_R4N1.sh 也算; 已排除本进程及其祖先/后代)" || f "有相关脚本进程: $(echo "$x" | head -3 | tr '\n' ';')"   # [R4N2]
    x=$(procs_other $$ 'run_R4N1\.sh'); [ -z "$x" ] && echo "  [info] 主包 run_R4N1.sh 编排进程: 无" || echo "  [info] 主包 run_R4N1.sh 编排进程在跑 (允许; 本包等它的槽): $(echo "$x" | head -2 | cut -c1-120 | tr '\n' ';')"
    if [ -n "${HAVE_LOCK:-}" ]; then p "已持有 flock $J/.R4N2_${MACHINE}.flock"; elif test_lock; then p "flock 可得 (无同机 run_R4N2 在跑)"; else f "flock 被占用: 同机已有 run_R4N2 在跑"; fi
    x=$(docker ps --format '{{.Names}}' 2>/dev/null | grep -E '^(R2a_|R2b_|R3|R4_|R4N1x_|R4N2_|j009_)|^R4N1_' | { [ "$WAIT_MAIN" = none ] && cat || grep -vE "^R4N1_${MACHINE}_[0-9]+_"; }); [ -z "$x" ] && p "docker ps 无 R2a_/R2b_/R3*/R4_/R4N1_/R4N1x_/R4N2_/j009_ 占卡容器 (WAIT_MAIN=$WAIT_MAIN)" || f "有占卡容器: $(echo "$x" | tr '\n' ' ')"   # [R4N2] WAIT_MAIN=none: R4N1_ 容器也算占卡
    echo "  [info] 主包容器 (允许): $(main_any_cn | tr '\n' ' ')"
    # MPS: 主包自己的守护 (pipe 在 $HOME/mps_R4N1/) 认出并排除; 其余 MPS 进程 = 残留, 先认人再 quit, 这里只认人, FAIL
    x=$(mps_unattributed); [ -z "$x" ] && p "nvidia-cuda-mps 进程: $(ps -eo args= | grep -c '[n]vidia-cuda-mps') 个, 全部认作主包 R4N1 的 (pipe 在 $HOME/mps_R4N1/)" || f "认不出归属的 MPS 进程 (先认人再 quit; 不 kill): $(echo "$x" | tr '\n' ';') -> bash $HERE/tools/mps_residue.sh; 别人的 -> 报 K/调度"
    [ "$X_MPS" = off ] && p "X_MPS=off: 本包全程不用 MPS" || p "X_MPS=auto [R4N2]: 机上无 MPS 进程时起自己的全新 \$HOME/mps_R4N2/${MACHINE}_<TS>_<n>; 每条 build 前验活 (进程+pipe+get_server_list), 死了改名旧 env 重起 (上限 X_MPS_MAX_START=$X_MPS_MAX_START), 不行降级 none; 事件见 \$OUT/slots/x_mps_events.log"
    if [ $bad = 0 ]; then echo "  ... ${GUARD_RECHECK_S:-60}s 后复查 (R2b M1: 空档漏报)"; sleep ${GUARD_RECHECK_S:-60}; x=$(gmx_unattributed); [ -z "$x" ] && p "60 s 后仍无主包容器外的 gmx" || f "60 s 后出现主包容器外的 gmx: $x"; fi
    x=$(df -Pk "$(dirname $J)" 2>/dev/null | awk 'NR==2{printf "%d",$4/1048576}'); [ "${x:-0}" -ge 10 ] && p "磁盘可用 ${x} GiB" || f "磁盘可用 ${x:-?} GiB < 10 (AMENDMENT_01: SEL_KEEP_FRAMES=1 不删帧, 门槛 5->10)"
  else echo "  [info] MODE=local: 跳过 gmx/容器/MPS/磁盘冲突检查 (仅 box 冒烟)"; fi
  # 5b [TRR-AMEND] 取起点规则自检: 参数 + 容器内 trjconv 经 stdin (-i) 取组号能跑通 (用 start.gro 当 1 帧 "轨迹")
  if [ "$SEL_RULE" = 1 ]; then [ "$GATE_MODE" = host ] && p "SEL_RULE=1 取起点规则: relax 每 ${SEL_NSTOUT} 步写 trr, 末 ${SEL_WIN_PS} ps 逐帧闸门, 选最后合格帧 (SEL_KEEP_FRAMES=$SEL_KEEP_FRAMES)" || echo "  [warn] SEL_RULE=1 但 GATE_MODE=$GATE_MODE: 无自动逐帧闸门, 回退旧行为 (末帧+-t cpt)"
    case "$SEL_NSTOUT$SEL_WIN_PS" in *[!0-9]*|"") f "SEL_NSTOUT/SEL_WIN_PS 须为整数";; esac
  else echo "  [warn] SEL_RULE=0: 旧行为 (relax 末帧 + -t relax.cpt), 与已作废的预跑 0/6 读数同款起点, 不建议"; fi
  # 6 gmx 版本 + 闸门可执行 (真跑一次 builder 级闸门, 期望 PASS)
  GMXV=$(gmx_version); [ -n "$GMXV" ] && check_gmxv && p "gmx 版本 $GMXV" || f "gmx 版本检查失败 ('$GMXV', 期望 ${EXPECT_GMX:-2026.3})"
  if [ "$GATE_MODE" = host ]; then
    $GATE_PY -c 'import numpy, scipy, MDAnalysis' >/dev/null 2>&1 && p "闸门依赖 numpy/scipy/MDAnalysis 可导入 ($GATE_PY)" || f "GATE_PY=$GATE_PY 导不进 numpy/scipy/MDAnalysis (设 GATE_PY=<含依赖的 python>, 或 GATE_MODE=manual)"
    x=$(mktemp -d)
    if [ -n "$REFH" ]; then ( cd $x && $GATE_PY $HERE/gate/t0_gate_hii.py $INP/$REFH/start.gro --level relax --box0 $(exp_of $REFH BOX0) --expect-lipids $(exp_of $REFH EXP_LIP) --expect-w $(exp_of $REFH EXP_W) --json gh.json ) >/dev/null 2>&1 && p "H_II 闸门自检: $REFH/start.gro L2 PASS (rc=0)" || f "H_II 闸门自检失败 (应 PASS): $REFH"; fi
    if [ -n "$REFL" ]; then ( cd $x && $GATE_PY $HERE/gate/t0_gate_launch.py $INP/$REFL/start.gro --level builder --arm lam --expect-lipids $(exp_of $REFL EXP_LIP) --expect-w $(exp_of $REFL EXP_W) --json g.json ) >/dev/null 2>&1 && p "片层闸门自检: $REFL/start.gro PASS (rc=0)" || f "片层闸门自检失败 (应 PASS): $REFL"
      [ -n "$REFH" ] && { ( cd $x && $GATE_PY $HERE/gate/t0_gate_hii.py $INP/$REFL/start.gro --level relax --box0 $(exp_of $REFL BOX0) --expect-lipids $(exp_of $REFL EXP_LIP) --expect-w $(exp_of $REFL EXP_W) --json nh.json ) >/dev/null 2>&1; [ $? = 3 ] && p "H_II 闸门负自检: 片层起点判不合格 rc=3" || f "H_II 闸门负自检: 片层起点未得 rc=3"; }; fi
    ( cd $x && $GATE_PY $HERE/gate/t0_gate_launch.py $HERE/proof/neg_selftest_bridged.gro --level builder --arm lam --expect-lipids 960 --expect-w 720 --json h.json ) >/dev/null 2>&1 && f "闸门负自检: 已知桥连帧竟 PASS" || p "闸门负自检: 已知桥连帧 (R3 DOPC relax 末帧) 判不合格 rc!=0"
  else p "GATE_MODE=manual: 须有人在 $OUT/manual_gate/<build>.PASS|.VOID 放闸门结论 (每条 relax 后最长等 ${GATE_WAIT_MAX_H} h)"; fi
  if [ "$SEL_RULE" = 1 ]; then x=$OUT/seltest_$$; mkdir -p $x; ( cd $x && echo 0 | GXI=1 CN=$(cn_name seltest_$BASHPID) gx trjconv -f $INP/$REFB/start.gro -s $INP/$REFB/start.gro -sep -o t.gro ) > $x/trjconv.log 2>&1
    [ -n "$(ls $x/t*.gro 2>/dev/null)" ] && p "trjconv(stdin 组号) 自检通过" || f "trjconv 自检失败 (docker run -i / gmx trjconv?): $x/trjconv.log"; fi
  # 5c 两槽同时 grompp 自检 (真发车时两槽的第 1 条 build 会同时 grompp relax; 这里用各槽首条 build 同时跑, 验容器名不撞/2026.3 能 grompp 派生 mdp; 只写 $OUT/gpchk, 不 mdrun)
  y=$OUT/gpchk; mkdir -p $y; gpp=; GPB=($( (rdlines $CA; rdlines $CB; rdlines $SUPPQ) | head -2)); [ -n "${GPB[1]:-}" ] || GPB[1]=${GPB[0]}   # [R4N2] 本包 A/B 主链空: 取前两条新起 build
  for t in "chkA ${GPB[0]}" "chkB ${GPB[1]}"; do set -- $t
    ( SLOT_TAG=$1; b=$2; dd=$y/$1/$b/attempt_001; mkdir -p $dd; mdp=$dd/relax_$RELAX_ARM.mdp
      if [ "$SEL_RULE" = 1 ]; then awk '!($1=="nstxout"||$1=="nstvout")' $INP/$b/relax_$RELAX_ARM.mdp > $mdp; printf 'nstxout = %s\nnstvout = %s\n' $SEL_NSTOUT $SEL_NSTOUT >> $mdp; else cp $INP/$b/relax_$RELAX_ARM.mdp $mdp; fi
      gp $dd relax $mdp $INP/$b/start.gro $INP/$b/sys.top $INP/$b/index.ndx $MAXWARN_RELAX; echo "$GP_RC $GP_NW" > $dd/gp_rc_nw.txt ) & gpp="$gpp $!"; done; wait $gpp
  for t in chkA chkB; do r=$(cat $y/$t/*/attempt_001/gp_rc_nw.txt 2>/dev/null); if [ "$RELAX_ARM" = crescale_dev ]; then [ "$r" = "0 0" ] && p "两槽同时 grompp 自检 $t: rc=0 无 warning" || f "两槽同时 grompp 自检 $t 失败 (rc nwarn='$r'): $y/$t/*/attempt_001/grompp.log"
    else [ "${r%% *}" = 0 ] && p "两槽同时 grompp 自检 $t: rc=0 (literal, nwarn=${r#* })" || f "两槽同时 grompp 自检 $t 失败 ('$r'): $y/$t/*/attempt_001/grompp.log"; fi; done
  [ $bad = 0 ] && { echo "== launch_guard: ALL OK"; return 0; } || { echo "== launch_guard: FAIL (见 [FAIL])"; return 1; }; }
# ------------------------------------------------------------------ 补跑队列 (主批 10 条后空槽接活; 严格按下列优先级, 每个作业须过时间判断)
# 优先级: (1) L2 替补轮: 本机账本里有 VOID_L2 (或 relax 失败, 见 REPLACE_ON_RELAX_FAIL) 的格, 取 spares_<机>.txt 里同格未用的替补 build, 再 relax+gate+prod
#         (2) chains/supp_<机>.txt 按文件顺序 (R4N1: 见 README_R4N1.md).
# 时间判断 supp_fits: 剩余墙钟 >= need_h + SUPP_MARGIN_H(0.75=45min) 且 now+need_h < DEADLINE; 不过则记 SUPP_SKIP_NO_TIME 并看下一个候选 (更短的作业可能放得下).
supp_fits(){ local b=$1 n; n=$(need_h $b); SUPP_NEED=$n
  awk -v r=$(rem_h) -v n=$n -v m=$SUPP_MARGIN_H 'BEGIN{exit !(r>=n+m)}' && [ $(( $(date +%s) + $(awk -v n=$n 'BEGIN{printf "%d", n*3600}') )) -lt $DL ]; }
claim_supp(){ local cell v s line b; CLAIM_B=; CLAIM_ROLE=; CLAIM_NOTE=; halted && return 1
  CLAIM_T=; for cell in $(for b in $(rdlines $CA; rdlines $CB; rdlines $SPARES); do cell_of $b; done | sort -u); do
    for v in $(ledger_list void); do [ "$(cell_of $v)" = "$cell" ] || continue; ledger_has replfor $v && continue
      for s in $(rdlines $SPARES); do [ "$(cell_of $s)" = "$cell" ] || continue; ledger_has claim $s && continue
        supp_fits $s || { ledger_claim skipnote ${SLOT_TAG}.$s && rec skip $s repl - - SUPP_SKIP_NO_TIME - - - - - - $SUPP_NEED "替补(for $v) 剩余不足 need+${SUPP_MARGIN_H}h"; continue; }
        ledger_claim replfor $v || continue; ledger_claim claim $s || { rmdir $OUT/ledger/replfor/$v; continue; }
        CLAIM_B=$s; CLAIM_ROLE=replacement; CLAIM_NOTE="replaces=$v"; return 0; done
      [ -n "$(for s in $(rdlines $SPARES); do [ "$(cell_of $s)" = "$cell" ] && echo $s; done)" ] || { ledger_claim noted nospare_$v && { rec skip $v repl - - NO_SPARE - - - - - - - "格 $cell 无替补 build -> 该格 n<3, 按 PREREG_R4_3day 记 NOT_EVALUABLE"; say "NO_SPARE: $v 无替补"; }; }
    done; done
  for b in $(rdlines $SUPPQ); do ledger_has claim $b && continue; only_ok $b || { ledger_claim skipnote only.$b && rec skip $b supp - - SKIP_NOT_ONLY - - - - - - - "ONLY=$ONLY_TOKS"; continue; }   # [R4N1x]
    supp_fits $b || { ledger_claim skipnote ${SLOT_TAG}.$b && rec skip $b supp - - SUPP_SKIP_NO_TIME - - - - - - $SUPP_NEED "补跑剩余不足 need+${SUPP_MARGIN_H}h"; continue; }
    ledger_claim claim $b || continue; CLAIM_B=$b; CLAIM_ROLE=supplement; CLAIM_NOTE="queue=$(basename $SUPPQ)"; CLAIM_T=; return 0; done
  # [R4N2] (3) fill (FILL=1): 续到更长; 只有本 OUT 低一段已 DONE 且无低段在跑时才领 (否则留给跑完低段的槽)
  if [ "$FILL" = 1 ]; then for x in $(rdext $FILLQ); do b=${x%%:*}; t=${x##*:}; ledger_has claim ext$t.$b && continue; k_c2_skip $b && continue; only_ok_ext $b fill || continue
      [ "$(ext_from_ns $b $t)" -gt 400 ] && ! ext_lower_busy $b $t || continue
      SUPP_NEED=$(need_h_ext $b $t); awk -v r=$(rem_h) -v n=$SUPP_NEED -v m=$SUPP_MARGIN_H 'BEGIN{exit !(r>=n+m)}' || { ledger_claim skipnote ${SLOT_TAG}.fill$t.$b && rec skip $b fill ext$t - SUPP_SKIP_NO_TIME - - - - - - $SUPP_NEED "fill 剩余不足 need+${SUPP_MARGIN_H}h"; continue; }
      ledger_claim claim ext$t.$b || continue; CLAIM_B=$b; CLAIM_T=$t; CLAIM_ROLE=fill; CLAIM_NOTE="queue=$(basename $FILLQ)"; return 0; done; fi
  return 1; }
slot(){ local tag=$1 po=$2 ch=$3 b
  SLOT_TAG=$tag; say "== slot start chain=$ch pinoffset=$po NT=$NT deadline=$DEADLINE gate=$GATE_MODE relax=$RELAX_ARM"
  wait_slot ${tag#${MACHINE}_} || { say "== slot end (未起: 等待放弃)"; return 0; }   # [R4N1x]
  # [R4N2] (1) 续跑链 ext_<机>_<槽>.txt
  local ech=$HERE/chains/ext_${tag}.txt x t; for x in $(rdext $ech); do b=${x%%:*}; t=${x##*:}
    k_c2_skip $b && { ledger_claim skipnote k.$b && rec skip $b ext ext$t - SKIP_K_C2_3SYS - - - - - - - "K_C2_3SYS=$K_C2_3SYS (K 决定 #1)"; continue; }
    only_ok_ext $b ext || { ledger_claim skipnote only.ext$t.$b && rec skip $b ext ext$t - SKIP_NOT_ONLY - - - - - - - "ONLY=$ONLY_TOKS"; continue; }
    ledger_claim claim ext$t.$b || say "ext$t.$b 已被领取过 (APPEND_TO 续跑: run_ext 幂等, 继续)"; XB=$b; x_mps_pick; say "MPS for $b ext$t: $X_MPS_NOTE"; run_ext $b $t ext $po main; say "END $b ext$t rc=$? mps=$X_MPS_NOTE"; done
  for b in $(rdlines $ch); do only_ok $b || { ledger_claim skipnote only.$b && rec skip $b primary - - SKIP_NOT_ONLY - - - - - - - "ONLY=$ONLY_TOKS"; continue; }
    ledger_claim claim $b || { say "$b 已被领取过 (APPEND_TO 续跑: run_build 自身幂等, 继续)"; }; XB=$b; x_mps_pick; say "MPS for $b: $X_MPS_NOTE"; run_build $b primary $po main; say "END $b rc=$? mps=$X_MPS_NOTE"; done
  if [ "$SUPP" = 1 ]; then while claim_supp; do XB=$CLAIM_B; x_mps_pick; say "补跑领取 $CLAIM_B ${CLAIM_T:+ext$CLAIM_T }($CLAIM_ROLE $CLAIM_NOTE) need=${SUPP_NEED}h remaining=$(rem_h)h mps=$X_MPS_NOTE"
      if [ -n "$CLAIM_T" ]; then run_ext $CLAIM_B $CLAIM_T $CLAIM_ROLE $po supp; else run_build $CLAIM_B $CLAIM_ROLE $po supp "$CLAIM_NOTE mps=$X_MPS_NOTE"; fi; say "END $CLAIM_B ${CLAIM_T:+ext$CLAIM_T }rc=$?"; done; fi
  say "== slot end"; }
summary(){ echo "== summary $MACHINE $(date '+%F %T %z')"; printf 'build\trelax\tgate\tprod\n'
  for d in $OUT/builds/*/; do b=$(basename $d); printf '%s\t%s\t%s\t%s%s\n' $b $(last_state $d/relax) $(last_state $d/gate) $(last_state $d/prod) "$(for e in $(ls -1d $d/ext[0-9]* 2>/dev/null); do printf ' %s=%s' $(basename $e) $(last_state $e); done)"; done | tee $OUT/SUMMARY.tsv   # [R4N2] 第 4 列附 ext 段
  for c in $(for b in $(rdlines $CA; rdlines $CB; rdlines $SPARES); do cell_of $b; done | sort -u); do v=$(for x in $(ledger_list void); do [ "$(cell_of $x)" = "$c" ] && echo $x; done | wc -l); g=$(for x in $OUT/builds/*/gate; do [ -d $x ] && [ "$(cell_of $(basename $(dirname $x)))" = "$c" ] && echo $x; done | wc -l); echo "L2 void_rate $c(本机): $v / $g 个已读闸 (L1 见 inputs/L1_summary.tsv)"; done | tee -a $OUT/SUMMARY.tsv
  for v in $(ledger_list void); do ledger_has replfor $v || echo "UNRESOLVED_VOID $v (无替补/时间不足 -> 该格 n 减少, 判读按 PREREG_R4_3day NOT_EVALUABLE/n<3 处理)"; done | tee -a $OUT/SUMMARY.tsv; }
# ------------------------------------------------------------------ main
if [ -n "${CHECK:-}" ]; then OUT=/tmp/R4N2_check_$$; mkdir -p $OUT/slots; OUT_PARENT=$OUT; launch_guard; exit $?; fi
if [ -n "${DRY:-}" ]; then
  OUT=$(mktemp -d /tmp/R4N2_dry_XXXXXX); OUT_PARENT=$OUT; mkdir -p $OUT/slots $OUT/ledger; SLOT_TAG=dry; GMXV=dry
  echo "== DRY machine=$MACHINE MODE=$MODE relax=$RELAX_ARM maxwarn(relax/prod)=$MAXWARN_RELAX/$MAXWARN_PROD deadline=$DEADLINE remaining=$(rem_h)h P=$(perf_eff) ns/day (PERF_NOM=$PERF_NOM F_THR=$F_THR) 不建输出/不起 MPS/容器"
  for t in "A $PINA $CA" "B $PINB $CB"; do set -- $t; t0=$(date +%s); echo "-- slot ${MACHINE}_$1 pin=$2 (顺序执行)"
    for x in $(rdext $HERE/chains/ext_${MACHINE}_$1.txt); do b=${x%%:*}; T=${x##*:}; k_c2_skip $b && { echo "   ext $b -> ${T}ns  SKIP_K_C2_3SYS (K_C2_3SYS='$K_C2_3SYS')"; continue; }   # [R4N2]
      n=$(need_h_ext $b $T); st=$(date -d @$t0 '+%m-%d %H:%M'); t0=$((t0+$(awk -v n=$n 'BEGIN{printf "%d", n*3600}'))); ext_src $b $T && sr="源 $EXT_SRC_KIND $EXT_SRC_DIR" || sr="源: $ES_MSG"
      echo "   ext $b 400->${T}ns need=${n}h  预计 $st -> $(date -d @$t0 '+%m-%d %H:%M') | convert-tpr -nsteps $(ext_steps $b $T); mdrun -deffnm ext -s ext.tpr -cpi src.cpt -noappend | $sr"; done
    for b in $(rdlines $3); do n=$(need_h $b); st=$(date -d @$t0 '+%m-%d %H:%M'); t0=$((t0+$(awk -v n=$n 'BEGIN{printf "%d", n*3600}'))); echo "   $b need=${n}h  预计 $st -> $(date -d @$t0 '+%m-%d %H:%M')  $(awk -v t=$t0 -v d=$DL 'BEGIN{print (t+0>d+0)?"[超 deadline: 会被 -maxh 截断/SKIP]":""}')"
      echo "      [TRR-AMEND] SEL_RULE=$SEL_RULE ($(arm_of $b)): relax 加 nstxout=nstvout=$SEL_NSTOUT -> 末 ${SEL_WIN_PS}ps trr 帧逐帧闸门 -> 选最后合格帧作 prod -c (无 -t); 0 合格 -> VOID_L2"; echo "      relax: grompp -f relax_$RELAX_ARM.mdp -c start.gro -maxwarn $MAXWARN_RELAX; mdrun | gate($GATE_MODE) | prod: $( [ "$SEL_RULE" = 1 ] && echo "grompp -f prod_$(arm_of $b).mdp -c selected.gro (无 -t; 起点 sha 须与闸门判过的一致, 否则 VOID_SEL_MISMATCH; SEL_SKIP 时回退 -c relax.gro -t relax.cpt)" || echo "grompp -f prod_$(arm_of $b).mdp -c relax.gro -t relax.cpt" ) -maxwarn $MAXWARN_PROD; mdrun -maxh=(剩余-${TAIL_H}h)"; done; done
  echo "-- [R4N1x] 实际起点不是 '现在': 每槽等主包同槽 done (WAIT_MAIN=$WAIT_MAIN main_run=$(main_run) START_AT=${START_AT:-无}); 上面时刻按 '现在' 起算, 只看相对长度; 估计结束见 PLAN_ESTIMATE.json"
  echo "-- [R4N1x] ONLY=${ONLY_TOKS:-无(全跑)}: $(for b in $(rdlines $CA; rdlines $CB; rdlines $SUPPQ); do only_ok $b || echo -n "$b(跳过) "; done)"
  echo "-- 补跑队列 (SUPP=$SUPP; 各作业此刻的时间判断; 实际领取发生在槽主链结束时, 此处按 '现在' 评估):"
  for b in $(rdlines $SPARES) $(rdlines $SUPPQ); do supp_fits $b && r=FITS || r=SKIP_NO_TIME; echo "   $b need=${SUPP_NEED}h rem=$(rem_h)h margin=${SUPP_MARGIN_H}h -> $r"; done
  echo "-- [R4N2] fill (FILL=$FILL): $(rdext $FILLQ | tr '\n' ' ')"; echo "-- [R4N2] K: K_C2_3SYS='$K_C2_3SYS' K_PR_SALT=$K_PR_SALT K_VOID_FIX_N3=$K_VOID_FIX_N3 | MPS X_MPS=$X_MPS 上限 $X_MPS_MAX_START"
  echo "   (优先级: 1 L2 替补[spares: $(rdlines $SPARES | tr '\n' ' ')] -> 2/3 supp 队列顺序 [$(rdlines $SUPPQ | tr '\n' ' ')])"
  exit 0; fi
need_cmd || exit 1
take_lock || { echo "ABORT: 同机 run_R4N2 已在运行 (flock $J/.R4N2_${MACHINE}.flock)"; exit 1; }; HAVE_LOCK=1
init_out $MACHINE || exit 1; exec > >(tee -a $OUT/orchestrator.log) 2>&1
echo "OUT=$OUT"; launch_guard || { echo "ABORT: 发车判据不过, 未起 MPS/容器"; exit 1; }
GMXV=${GMXV:-unknown}
{ echo "machine=$MACHINE host=$(hostname) start=$(date '+%F %T %z') deadline=$DEADLINE gmx=$GMXV mode=$MODE"; env | grep -E '^(K_|FILL|EXT_|PRIOR_|DEADLINE|ONLY|ONLY_FILE|WAIT_|START_AT|GO_QUIET|JMAIN|X_MPS|RELAX_ARM|MAXWARN_|K_APPROVED|F_THR|PERF_NOM|GATE_|SUPP|REPLACE_|SEL_|NT=|PINA|PINB|TAIL_H|MINRUN_H|IMG=|J=|EXPECT_GMX|PRIO|PERF_)' | sort; echo "PRIO=$PRIO NICE=$NICE CPUSH=$CPUSH"; echo "ONLY_TOKS=$ONLY_TOKS K_C2_3SYS=$K_C2_3SYS K_PR_SALT=$K_PR_SALT K_VOID_FIX_N3=$K_VOID_FIX_N3 FILL=$FILL X_MPS_MAX_START=$X_MPS_MAX_START EXT_SRC_RUNS=$EXT_SRC_RUNS"; (cd $HERE && sha256sum run_R4N2.sh lib_R4N2.sh MANIFEST_sha256.txt verdict_R4_3day.py verdict_Larm.py PREREG_R4_3day.md PRE_REG_AMENDMENT_R4N1_02.md VARIANT); } > $OUT/RUN_META.txt
# [R4N1x] 不在这里起 MPS (主包可能仍在跑); 每条 build 前 x_mps_pick 决定, 见 lib_R4N1x.sh
cleanup(){ echo "[$(date '+%F %T')] INTERRUPT/EXIT: 只停本脚本容器 ${CN_PREFIX}${MACHINE}_${ORCH_PID}_*"; [ "$MODE" = local ] || { for c in $(docker ps --format '{{.Names}}' | grep "^${CN_PREFIX}${MACHINE}_${ORCH_PID}_"); do docker stop -t 120 $c >/dev/null 2>&1; done; }; }
trap 'cleanup; kill $PA $PB 2>/dev/null; wait $PA $PB 2>/dev/null; x_mps_stop; exit 143' INT TERM
( slot ${MACHINE}_A $PINA $CA ) & PA=$!
( slot ${MACHINE}_B $PINB $CB ) & PB=$!
wait $PA $PB; x_mps_stop; summary; echo "== machine $MACHINE done $(date '+%F %T %z') OUT=$OUT"
