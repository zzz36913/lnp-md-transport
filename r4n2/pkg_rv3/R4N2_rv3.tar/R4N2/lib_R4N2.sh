#!/bin/bash
# [R4N2] lib_R4N2.sh -- R4N1 第 2 晚包 (10-31 14:00 -> 11-01 07:30). 由 lib_R4N1x.sh (第 1 晚追加包, 已审已跑) 复制, 只改 [R4N2] 标记处:
#   (a) MPS 修复: x_mps_pick 判 own 前验守护活着 + pipe 可用 (死了 -> 改名旧 env + 重起一次 / 降级 none, 日志写明); x_mps_stop 收尾把 x_mps.env 改名 (不 rm), 防 APPEND_TO 复用死 pipe (10-30 C4 无 MPS 约 1/3 速的原因).
#   (b) 续跑 (ext): 链文件第 2 列 ext=<目标 ns> -> 从第 1 晚 400 ns 终点 (prod.tpr+prod.cpt, sha 对 SHA256_out.txt) convert-tpr -nsteps <目标步数> 续到目标 (tpr init-step=0, 总步数=目标; dump 复核); 新 attempt + -noappend, 旧目录只读.
#   (c) 输出 $HOME/R4N2, 容器前缀 R4N2_, flock .R4N2_<机>.flock, MPS 根 $HOME/mps_R4N2; 默认 DEADLINE 2026-11-01 07:30 +0800; 默认 WAIT_MAIN=none (第 2 晚无主包).
#   (d) K 待定开关 (只留开关不放内容): K_C2_3SYS / K_PR_SALT / K_VOID_FIX_N3 (见 run_R4N2.sh launch_guard).
#   判据/闸门/mdp/冻结 verdict 一字不改.
# lib_R4N1x.sh -- R4N1x 追加包 (PRE_REG_AMENDMENT_R4N1_02: C4 + L 臂) 公共函数, 由 lib_R4N1.sh (主包, 已审已发) 复制后只改下列 [R4N1x] 标记处; 其余逐字相同.
# [R4N1x] 改动: 名字多一个臂 hiiL (长盒 H_II, 几何/闸门/mdp 同 hii); 输出 $HOME/R4N1x; 容器前缀 R4N1x_; flock .R4N1x_<机>.flock; MPS 根 $HOME/mps_R4N1x; HIST_BAN 空; ONLY 过滤; FULL_CUTOFF 不适用 (VARIANT=append).
# 原注释: lib_R4N1.sh -- R4 第 1 晚 (R4N1: T×水合 2×2, H_II 起点 + 350 K 片层臂) 发车包公共函数 (被 run_R4N1.sh source). 由 D1v2/lib_R4.sh 改写 (D1v2 已在 k03/k04 + gmx 2026.3 实跑过全链).
# R4N1 改动 (只列改动): 名字 R4N1_<DOPE|DOPC|MC3H|MC3>_h<050|100>_T<320|350>_<hii|lam>_s<k>; 格 = 体系_水合_温度_臂; 输入 itp 在每个 build 目录内 (不再用 inputs/ff);
#   H_II 臂也写 trr + 末 5 ns 逐帧取起点 (闸门 = gate/t0_gate_hii.py --level relax, BOX0 读 expect.env), 片层臂闸门同 D1v2 (t0_gate_launch.py prod0 lam);
#   两臂 VOID_L2/relax 失败都进替补账本; 默认 DEADLINE 2026-10-31 07:30 +0800; 容器前缀 R4N1_; 输出 $HOME/R4N1; PERF_NOM=14258 @15420 珠 (D1v2 实测 DOPC h050);
#   MPS: 每次发车用全新 MPSROOT=$HOME/mps_R4N1/<机>_<TS> (不需要删任何目录); mps_stop 只对本次自己的 pipe 发 quit, 不 kill 任何进程; 残留 MPS = 先认人 (owner/pid/etime/pipe) 再 quit (tools/mps_residue.sh), 不 kill, 不删目录.
# 硬约束: 只用 gmx + 用户态 MPS; 不碰 GLM/ZCode/任何端口/key; 不独占显存/不重启 (须 K 批); 只 stop 本脚本起的 R4N1_<机>_<pid>_* 容器; 不 rm 任何既有文件; 旧 attempt 永不覆写.
export PYTHONDONTWRITEBYTECODE=1
HERE=${HERE:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}
INP=$HERE/inputs; FF=$INP          # itp 在 inputs/<b>/ 内, sys.top 用相对 #include
MODE=${MODE:-docker}                       # docker (Spark) | local (box 冒烟: GMX_LOCAL)
IMG=${IMG:-ghcr.io/novomcp/gromacs-md:spark}; G=${G:-/usr/local/gromacs/bin/gmx}
GMX_LOCAL=${GMX_LOCAL:-gmx}
NT=${NT:-5}; PINA=${PINA:-15}; PINB=${PINB:-5}
J=${J:-$HOME/R4N2}                          # [R4N2] 输出根; 实际输出 $J/R4N2_run_<机>_<TS>
DEADLINE=${DEADLINE:-"2026-11-01 07:30 +0800"}   # [R4N2] 第 2 晚
FULL_CUTOFF="2026-10-30 19:30 +0800"   # [R4N1x] 仅对 VARIANT=full 生效; 本包 VARIANT=append, 不适用
#   # AMENDMENT_01 (REVIEW S2): 完整版新启动硬门槛, 不可用 env 覆盖   # 显式 +0800, 不依赖 Spark 的 TZ
# ---- 逐步 maxwarn: 默认 0; 只有下面两个变量, 无其它旁路 ----
MAXWARN_RELAX=${MAXWARN_RELAX:-0}          # relax 步 (crescale_dev 必须 0; literal 须 2 且 K_APPROVED_LITERAL=yes)
MAXWARN_PROD=${MAXWARN_PROD:-0}            # prod 步 (必须 0, 非 0 则 ABORT: 需改包而不是改变量)
RELAX_ARM=${RELAX_ARM:-crescale_dev}       # crescale_dev (默认, 偏离 SI 协议) | literal (Berendsen, 需 K 批准)
K_APPROVED_LITERAL=${K_APPROVED_LITERAL:-}
# ---- 时间/吞吐 (f 的读取位置见 perf_eff) ----
PERF_NOM=${PERF_NOM:-14258}                # ns/day/槽 @ PERF_REF_BEADS 珠 (D1v2 实测 DOPC h050 lam prod, 2 槽/机 MPS); 按珠数线性缩放 = 估算 (350 K / H_II 盒形未实测)
PERF_REF_BEADS=${PERF_REF_BEADS:-15420}    # D1v2 DOPC h050 lam 体系珠数
# ---- 优先级开关 (规则7: 可关 GLM/提 MD 优先级; 独占显存/重启须 K 批, 本包不做) ----
PRIO=${PRIO:-low}                          # low: mdrun -nice 10 + docker --cpu-shares 512 (与他人共机时让路) | raised: -nice 0 + --cpu-shares 2048 (GLM 已停时)
case $PRIO in low) NICE=10; CPUSH=512;; raised) NICE=0; CPUSH=2048;; *) echo "ABORT: PRIO=$PRIO 须 low|raised"; exit 1;; esac
F_THR=${F_THR:-1.0}                        # 吞吐系数 f: 有效速率 = PERF_NOM*F_THR (规划敏感性 1.0/0.8/0.5)
PERF_OVERRIDE_FILE=${PERF_OVERRIDE_FILE:-$J/R4N2_perf_override.env}   # 预跑结果到后: 写 F_THR=0.9 或 PERF_NOM=... 到此文件 (包外, 不入 MANIFEST), 补跑判断每次现读
RELAX_FRAC=${RELAX_FRAC:-0.75}             # relax 速率 = RELAX_FRAC * prod 速率 (规划假设)
OVH_H=${OVH_H:-0.1}; GATE_H=${GATE_H:-0.15} # 每条额外开销 / 闸门耗时 (假设)
TAIL_H=${TAIL_H:-0.25}                     # prod -maxh = 剩余 - TAIL_H (留 checkpoint+退出)
MINRUN_H=${MINRUN_H:-0.6}                  # 主批: 剩余不足不开新条 -> SKIP_NO_TIME
SUPP_MARGIN_H=${SUPP_MARGIN_H:-0.75}       # 补跑: 剩余 >= 所需 + 45 min 才发
SUPP=${SUPP:-1}
GATE_MODE=${GATE_MODE:-host}               # host (Spark 上 $GATE_PY 跑 gate/t0_gate_launch.py) | manual (等人把 .PASS/.VOID 放进 $OUT/manual_gate/)
GATE_PY=${GATE_PY:-python3}
GATE_WAIT_MAX_H=${GATE_WAIT_MAX_H:-0.75}
REPLACE_ON_RELAX_FAIL=${REPLACE_ON_RELAX_FAIL:-1}   # relax 崩溃/未跑满的 build 是否按 L2 void 同等进替补账本 (决策开关)
HIST_BAN=${HIST_BAN:-}   # [R4N1x] 本包 40/40 L1 PASS, 无禁用 build
# ---- [TRR-AMEND 2026-10-28 取起点规则] 判据阈值一个未改; 只新增"从 relax 末 SEL_WIN_PS 内取最后一个合格帧作 prod 起点" (见 PRE_REG_AMENDMENT_R3_trr.md) ----
SEL_RULE=${SEL_RULE:-1}                    # 1=启用 (R4N1: lam 与 hii 两臂都启用, 闸门按臂); 0=旧行为 (relax 末帧 + -t relax.cpt)
SEL_NSTOUT=${SEL_NSTOUT:-5000}             # relax 期间 trr 写出间隔 (步; 15 fs*5000=75 ps) -> nstxout=nstvout=此值, 不写 f
SEL_WIN_PS=${SEL_WIN_PS:-5000}             # 只在 relax 末尾这么多 ps (5 ns, ~67 帧) 内逐帧判定
SEL_KEEP_FRAMES=${SEL_KEEP_FRAMES:-1}      # AMENDMENT_01 (REVIEW S5, K 12:14): 默认 1 = 全留, 不删帧; 0 = prod 前删除非选中帧 .gro (旧 D1v2 行为, 本包不用)
GMXV=unknown
CN_PREFIX=${CN_PREFIX:-R4N2_}              # [R4N2] 容器名 R4N2_<机>_<pid>_<标签> (第 1 晚为 R4N1_/R4N1x_, 互不匹配)
say(){ echo "[$(date '+%F %T')] ${SLOT_TAG:-R4N1}: $*" | tee -a "${OUT:-/tmp}/slots/${SLOT_TAG:-main}.log" 2>/dev/null; }
# ---------- 时间 ----------
DL=$(date -d "$DEADLINE" +%s 2>/dev/null) || { echo "ABORT: DEADLINE='$DEADLINE' 无法解析"; exit 1; }
rem_s(){ echo $((DL-$(date +%s))); }
rem_h(){ awk -v r=$(rem_s) 'BEGIN{printf "%.3f", r/3600}'; }
# ---------- 吞吐 f 读取位置 ----------
# 有效速率 ns/day = min( PERF_NOM*F_THR [可被 $PERF_OVERRIDE_FILE 改写], 本机已测 prod 'Performance:' 的最小值 [$OUT/THROUGHPUT.tsv] )
perf_eff(){ local f=$F_THR n=$PERF_NOM obs
  if [ -f "$PERF_OVERRIDE_FILE" ]; then eval "$(grep -E '^(F_THR|PERF_NOM)=[0-9.]+$' "$PERF_OVERRIDE_FILE")" 2>/dev/null; f=${F_THR:-$f}; n=${PERF_NOM:-$n}; fi
  obs=; [ "${USE_OBSERVED:-1}" = 1 ] && obs=$(awk -F'\t' '($3=="prod"||$3=="ext") && $4+0>0{ if(m==""||$4+0<m)m=$4+0 } END{print m}' "$OUT/THROUGHPUT.tsv" 2>/dev/null)
  awk -v n=$n -v f=$f -v o="${obs:-}" 'BEGIN{p=n*f; if(o!=""&&o+0<p)p=o+0; printf "%.1f", p}'; }
mdp_nsteps(){ awk '$1=="nsteps"{print $3; exit}' "$1"; }
mdp_dt(){ awk '$1=="dt"{print $3; exit}' "$1"; }
# need_h <build> -> relax(15ns @ RELAX_FRAC*P) + GATE_H + prod(ns @ P) + OVH_H
need_h(){ local b=$1 arm pm rm P; arm=$(arm_of $b); pm=$INP/$b/prod_$arm.mdp; rm=$INP/$b/relax_$RELAX_ARM.mdp; P=$(awk -v p=$(perf_eff) -v r=$PERF_REF_BEADS -v n=$(exp_of $b EXP_ATOMS) 'BEGIN{if(n+0<=0)n=r; printf "%.1f", p*r/n}')   # 珠数缩放 (估算)
  awk -v P=$P -v rf=$RELAX_FRAC -v g=$GATE_H -v o=$OVH_H -v pn=$(mdp_nsteps $pm) -v pd=$(mdp_dt $pm) -v rn=$(mdp_nsteps $rm) -v rd=$(mdp_dt $rm) \
   'BEGIN{pns=pn*pd/1000; rns=rn*rd/1000; printf "%.3f", rns/(rf*P)*24 + g + pns/P*24 + o}'; }
# ---------- 名字解析 ----------
arm_of(){ case $1 in *_lam_*) echo lam;; *_hii_*|*_hiiL_*) echo hii;; *) echo bad;; esac; }   # [R4N1x] hiiL = 长盒 H_II, 用 prod_hii.mdp / hii 闸门
NAMERE='^R4N1_(DOPE|DOPC|MC3H|MC3)_(h[0-9][0-9][0-9])_(T[0-9][0-9][0-9])_(hii|hiiL|lam)_s([0-9]+)$'
cell_of(){ [[ $1 =~ $NAMERE ]] && echo ${BASH_REMATCH[1]}_${BASH_REMATCH[2]}_${BASH_REMATCH[3]}_${BASH_REMATCH[4]} || echo bad; }   # 格 = 体系_水合_温度_臂
valid_name(){ [[ $1 =~ $NAMERE ]] || return 1
  [ -f $INP/$1/expect.env ] || return 1; for x in $HIST_BAN; do [ "$1" = "$x" ] && return 1; done; return 0; }
# expect.env (builder 写): EXP_LIP EXP_W EXP_CL EXP_ATOMS EXP_ARM EXP_TEMP BOX0
exp_of(){ awk -F= -v k=$2 '$1==k{print $2}' $INP/$1/expect.env 2>/dev/null; }
# ---------- gmx 调用 ----------
need_cmd(){ if [ "$MODE" = local ]; then command -v "$GMX_LOCAL" >/dev/null 2>&1 || [ -x "$GMX_LOCAL" ] || { echo "ABORT: MODE=local 但找不到 $GMX_LOCAL"; return 1; }
  else command -v docker >/dev/null 2>&1 || { echo "ABORT: 没有 docker"; return 1; }; fi; }
# [TRR-AMEND] GXI=1 => docker run -i (trjconv 要从 stdin 读组号 'echo 0 | GXI=1 gx trjconv ...'; 不设则与旧版逐字相同).
# gx: 在 $PWD 跑 gmx. GXG=1 给容器 GPU (只 mdrun). 容器名 $CN (调用者设). TMOPFX='timeout -s TERM -k 180 <秒>' 时给该条命令加外层超时 (grompp 时为空).
gx(){ if [ "$MODE" = local ]; then $TMOPFX env GMXLIB=$FF $GMX_LOCAL "$@" 2>&1; else
  $TMOPFX docker run --rm ${GXI:+-i} --name ${CN:-$(cn_name x$BASHPID)} --cpu-shares $CPUSH ${GXG:+--gpus all} ${MPSARGS-} --entrypoint /bin/sh -u $(id -u):$(id -g) -e HOME=/tmp -e GMXLIB=$FF -v $HERE:$HERE:ro -v $OUT_PARENT:$OUT_PARENT -w "$PWD" $IMG -c "exec 2>&1; $G $*"; fi; }
# 容器名唯一且落在 cleanup 的 ^R4N1_<机>_<pid>_ 范围: R4N1_<机>_<ORCH_PID>_<SLOT_TAG>_<后缀>; 后缀须含 build/阶段/attempt 或 BASHPID (F2: 旧默认名 R3_x$$ 在两槽子 shell 里 $$ 相同 -> 重名)
cn_name(){ echo "${CN_PREFIX}${MACHINE}_${ORCH_PID}_${SLOT_TAG:-nos}_$1" | tr -c 'A-Za-z0-9_.\n-' '_'; }
gmx_version(){ ( cd /tmp; OUT_PARENT=${OUT_PARENT:-/tmp} CN=$(cn_name ver_$BASHPID) gx --version 2>&1 | grep -m1 'GROMACS version' | awk '{print $NF}' ); }
check_gmxv(){ case "$GMXV" in ${EXPECT_GMX:-2026.3}*) return 0;; esac; [ "${EXPECT_GMX:-}" = any ] && return 0; echo "ABORT: gmx 版本 '$GMXV' != 期望 ${EXPECT_GMX:-2026.3} (box 冒烟请设 EXPECT_GMX=any)"; return 1; }
# ---------- 进程冲突扫描 (F1) / 防双开 ----------
# procs_other <egrep 模式>: 列出 args 命中模式、且不是 "本 shell / 本 shell 的祖先 (ssh 外层 bash -c ... run_R3.sh ...) / 本 shell 的后代 (子 shell, $(...), ps, awk)" 的进程.
procs_other(){ ps -eo pid=,ppid=,args= | awk -v me=${1:?} -v pat="$2" '
  { pid=$1; pp[pid]=$2; $1=""; $2=""; ln[pid]=$0 }
  END{ for(a=me; a>1 && !(a in anc); a=pp[a]) anc[a]=1
       for(p in ln){ if(p in anc) continue; d=0; for(q=p; q>1; q=pp[q]) if(q==me){d=1;break}; if(d) continue
         if(ln[p] ~ pat) print p ln[p] } }'; }
# take_lock: flock 防同机双开 (fd 9 随进程退出自动释放, 不需要 rm); 已被占用则返回 1
take_lock(){ mkdir -p "$J" && exec 9>>"$J/.R4N2_${MACHINE}.flock" && flock -n 9; }
test_lock(){ mkdir -p "$J" && ( exec 9>>"$J/.R4N2_${MACHINE}.flock"; flock -n 9 ); }
# ---------- 输出目录/attempt/状态 (不覆写) ----------
init_out(){ local M=$1
  if [ -n "${APPEND_TO:-}" ]; then [ -d "$APPEND_TO" ] || { echo "ABORT: APPEND_TO 不存在"; return 1; }; OUT=$(cd "$APPEND_TO" && pwd); APPEND=1
  else TS=$(date +%m%d_%H%M%S); mkdir -p "$J" || return 1
    # 幂等: 同机已有 R4N1_run_<机>_* 时不默默另起一套 (会重复跑同一批 build); 续跑用 APPEND_TO=该目录, 确要另起一套须显式 NEW_RUN=1
    if [ -n "$(ls -1d $J/R4N2_run_${M}_* 2>/dev/null)" ] && [ "${NEW_RUN:-}" != 1 ]; then echo "ABORT: 已有 $(ls -1d $J/R4N2_run_${M}_* | tr '\n' ' ')-> 续跑设 APPEND_TO=<该目录>; 确要新起一套设 NEW_RUN=1"; return 1; fi
    OUT=$J/R4N2_run_${M}_$TS; mkdir "$OUT" 2>/dev/null || { echo "ABORT: $OUT 已存在, 不覆盖 (续跑用 APPEND_TO=该目录)"; return 1; }; fi
  OUT_PARENT=$(dirname "$OUT"); mkdir -p "$OUT/slots" "$OUT/ledger" "$OUT/manual_gate"; export OUT OUT_PARENT; }
new_attempt(){ local s=$1 n d; mkdir -p "$s"; n=$(ls -1d "$s"/attempt_[0-9][0-9][0-9] 2>/dev/null | sed 's/.*attempt_//' | sort -n | tail -1); n=$((10#${n:-0}))
  while :; do n=$((n+1)); d=$(printf '%s/attempt_%03d' "$s" $n); mkdir "$d" 2>/dev/null && { echo "$d"; return 0; }; done; }
last_attempt(){ ls -1d "$1"/attempt_[0-9][0-9][0-9] 2>/dev/null | sort | tail -1; }
last_state(){ local d; d=$(last_attempt "$1"); [ -n "$d" ] && [ -f "$d/STATUS" ] && cut -d' ' -f1 "$d/STATUS" || echo NONE; }
setstat(){ ( set -o noclobber; echo "$2 ${3:-}" > "$1/STATUS" ) 2>/dev/null || echo "WARN: $1/STATUS 已存在, 不覆盖" >&2; }
warn_extract(){ awk '/^WARNING [0-9]+/{p=1} /^(Number of degrees|There w(as|ere) [0-9]+ (NOTE|WARNING))/{p=0} p' "$1"; }
nanchk(){ grep -ciE '(^|[^a-z])nan([^a-z]|$)|fatal error|LINCS WARNING' "$1" 2>/dev/null; }
REC_HEADER=$'ts\tmachine\tslot\tstage\tbuild\trole\tarm_or_mdp\tattempt_dir\tstate\tgmx_version\tmaxwarn\tgrompp_rc\tn_warn\tmdrun_rc\tlaststep\tperformance_ns_day\tremaining_h\tneed_h\tnote'
# rec <stage> <build> <role> <arm_or_mdp> <attempt_dir> <state> <maxwarn> <grompp_rc> <n_warn> <mdrun_rc> <laststep> <perf> <need_h> <note>  (只 >>, 单行 <4096B, O_APPEND 原子)
rec(){ [ -f "$OUT/ALL_RECORDS.tsv" ] || printf '%s\n' "$REC_HEADER" >> "$OUT/ALL_RECORDS.tsv"
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$(date '+%F %T %z')" "${MACHINE:--}" "${SLOT_TAG:--}" "$1" "$2" "$3" "$4" "$5" "$6" "$GMXV" "${7:--}" "${8:--}" "${9:--}" "${10:--}" "${11:--}" "${12:--}" "$(rem_h)" "${13:--}" "${14:--}" >> "$OUT/ALL_RECORDS.tsv"; }
# ---------- 账本 (机器内两槽共享; mkdir 原子) ----------
ledger_claim(){ mkdir -p "$OUT/ledger/$1" && mkdir "$OUT/ledger/$1/$2" 2>/dev/null; }          # 成功=抢到
ledger_has(){ [ -d "$OUT/ledger/$1/$2" ]; }
ledger_list(){ ls -1 "$OUT/ledger/$1" 2>/dev/null; }
ledger_add(){ mkdir -p "$OUT/ledger/$1" && mkdir "$OUT/ledger/$1/$2" 2>/dev/null; return 0; }
halted(){ [ -f "$OUT/HALT" ]; }
halt(){ ( set -o noclobber; echo "$(date '+%F %T') ${SLOT_TAG:-}: $*" > "$OUT/HALT" ) 2>/dev/null; say "HALT: $*"; }
# ---------- MPS (用户态守护; 规则: MPS 残留先认人再 quit; 不 kill, 不删目录) ----------
# MPSROOT 每次发车新建 ($HOME/mps_R4N1/<机>_<TS>), 已存在即 ABORT -> 永远不需要清空/删除旧目录. 残留 (别人的或上一批的) 由 launch_guard 报 owner/pid/etime/pipe 后 FAIL, 交人处理 (tools/mps_residue.sh).
mps_start(){ [ "$MODE" = local ] && return 0; [ -n "${NOMPS:-}" ] && return 0; MPSROOT=${MPSROOT:-$HOME/mps_R4N2/${MACHINE}_$(date +%m%d_%H%M%S)}
  [ -e "$MPSROOT" ] && { echo "ABORT: MPSROOT=$MPSROOT 已存在 (本包每次用全新目录; 不复用/不清空)"; return 1; }
  export MPSPIPE=$MPSROOT/pipe MPSLOG=$MPSROOT/log; mkdir -p $MPSPIPE $MPSLOG; echo "$MPSROOT" > $OUT/slots/${MACHINE}_mpsroot.txt
  CUDA_MPS_PIPE_DIRECTORY=$MPSPIPE CUDA_MPS_LOG_DIRECTORY=$MPSLOG nvidia-cuda-mps-control -d || { echo "ABORT: MPS 起不来"; return 1; }; sleep 3
  ps -eo user=,pid=,etime=,args= | grep '[n]vidia-cuda-mps' > $OUT/slots/${MACHINE}_mps_start.txt
  export MPSARGS="--ipc=host -v $MPSPIPE:$MPSPIPE -v $MPSLOG:$MPSLOG -e CUDA_MPS_PIPE_DIRECTORY=$MPSPIPE -e CUDA_MPS_LOG_DIRECTORY=$MPSLOG"; MPS_UP=1; }
# mps_stop: 只对本次自己的 pipe 目录发 quit (控制守护自己退出并带走它的 server); 之后列出仍在的 nvidia-cuda-mps 进程 (owner/pid/etime/args) 写报告; 不 kill.
mps_stop(){ [ -n "${MPS_UP:-}" ] || return 0; echo quit | CUDA_MPS_PIPE_DIRECTORY=$MPSPIPE CUDA_MPS_LOG_DIRECTORY=$MPSLOG timeout 20 nvidia-cuda-mps-control > $OUT/slots/${MACHINE}_mps_quit.txt 2>&1; sleep 5
  ps -eo user=,pid=,etime=,args= | grep '[n]vidia-cuda-mps' > $OUT/slots/${MACHINE}_mps_after_quit.txt
  [ -s $OUT/slots/${MACHINE}_mps_after_quit.txt ] && say "WARN: quit 后仍有 MPS 进程 (未 kill; 先认人再处理, 见 $OUT/slots/${MACHINE}_mps_after_quit.txt 与 tools/mps_residue.sh)"; MPS_UP=; }
# ---------- grompp ----------
# gp <attempt_dir> <tag> <mdp> <gro> <top> <ndx> <maxwarn> [extra...] -> GP_RC GP_NW; grompp.log / warnings.txt
gp(){ local d=$1 tag=$2 mdp=$3 gro=$4 top=$5 ndx=$6 mw=$7 cn; shift 7
  cn=$(cn_name gp_${tag}_$(basename $(dirname $(dirname "$d")))_$(basename "$d"))   # 含 机/pid/槽/阶段tag/build/attempt; 同一 attempt 目录只会 grompp 一次
  ( cd "$d" && CN=$cn gx grompp -f "$mdp" -c "$gro" -p "$top" -n "$ndx" -o $tag.tpr -po ${tag}_out.mdp "$@" -maxwarn $mw ) > "$d/grompp.log" 2>&1; GP_RC=$?
  warn_extract "$d/grompp.log" > "$d/warnings.txt"; GP_NW=$(grep -c '^WARNING' "$d/grompp.log"); }
norm_ws(){ tr -s ' \t\n' ' ' < "$1" | sed 's#\[file [^] ]*/#[file #g; s/^ //; s/ $//'; }   # 去掉 grompp 报告里的 mdp 目录前缀, 其余逐字
# ---------- mdrun (单次; 后台+wait 使 TERM trap 立即生效; 外层 timeout=剩余+600) ----------
# run_mdrun <attempt_dir> <deffnm> <pinoff> <maxh> <timeout_s> [mdrun 额外参数...] -> MD_RC; 日志 <deffnm>.log, stdout mdrun.out
run_mdrun(){ local d=$1 f=$2 po=$3 mh=$4 to=$5; shift 5; local pin gpuf
  if [ "$MODE" = local ]; then pin=${PINFLAGS-"-pin off"}; gpuf=${GPUFLAGS-"-nb cpu -update cpu"}; else pin=${PINFLAGS-"-pin on -pinoffset $po -pinstride 1"}; gpuf=${GPUFLAGS-"-nb gpu -update cpu"}; fi
  MD_CN=${CN_PREFIX}${MACHINE}_${ORCH_PID}_${SLOT_TAG}_${f}_$(basename $d)
  echo "mdrun -deffnm $f -ntmpi 1 -ntomp $NT $gpuf $pin -nice $NICE -maxh $mh $*  (PRIO=$PRIO cpu-shares=$CPUSH)" > $d/mdrun_cmd.txt; echo "container=$MD_CN" >> $d/mdrun_cmd.txt
  ( cd "$d" && GXG=1 CN=$MD_CN TMOPFX="timeout -s TERM -k 180 $to" gx mdrun -deffnm $f -ntmpi 1 -ntomp $NT $gpuf $pin -nice $NICE -maxh $mh "$@" ) > "$d/mdrun.out" 2>&1 & MDP=$!
  wait $MDP; MD_RC=$?
  if [ $MD_RC = 124 ] || [ $MD_RC = 137 ]; then [ "$MODE" = local ] || docker stop -t 120 $MD_CN >/dev/null 2>&1; fi; }
laststep_of(){ awk '/^ +Step +Time/{getline; s=$1} END{print s+0}' "$1" 2>/dev/null; }
perf_of(){ grep -E '^Performance:' "$1" 2>/dev/null | tail -1 | awk '{print $2}'; }
# ======================= 单条 build 流水线: relax -> 闸门(L2 起点资格) -> prod =======================
PROD_MIN_H=${PROD_MIN_H:-0.5}              # 闸门通过后 prod 可用 -maxh 低于此值 -> SKIP_NO_TIME_PROD (不白起)
NSTEPS_OVERRIDE_RELAX=${NSTEPS_OVERRIDE_RELAX:-}; NSTEPS_OVERRIDE_PROD=${NSTEPS_OVERRIDE_PROD:-}   # 仅 MODE=local 冒烟
USE_OBSERVED=${USE_OBSERVED:-1}
thr_rec(){ [ -n "$4" ] || return 0; [ -f "$OUT/THROUGHPUT.tsv" ] || printf 'ts\tbuild\tstage\tperf_ns_day\tlaststep\tslot\n' >> "$OUT/THROUGHPUT.tsv"
  printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$(date '+%F %T %z')" "$1" "$2" "$4" "$3" "${SLOT_TAG:--}" >> "$OUT/THROUGHPUT.tsv"; }
inputs_sha(){ ( cd $INP/$1 && sha256sum start.gro sys.top index.ndx relax_$RELAX_ARM.mdp prod_$2.mdp *.itp expect.env ) > "$3/inputs_sha256.txt" 2>&1; }
done_dir(){ local s=$1 d st; for d in $(ls -1d "$s"/attempt_[0-9][0-9][0-9] 2>/dev/null | sort -r); do [ -f $d/STATUS ] && [ "$(cut -d' ' -f1 $d/STATUS)" = "$2" ] && { echo $d; return 0; }; done; return 1; }
consec_fail(){ # consec_fail <kind>: 机器内同类 grompp 失败计数 (>=2 即判系统性问题, HALT)
  ledger_add gpfail_$1 "$(date +%s)_$$_$RANDOM"; [ "$(ledger_list gpfail_$1 | wc -l)" -ge 2 ]; }
# ---- relax ----
step_relax(){ local b=$1 po=$2 d mdp tgt mh to ls rc st nn
  mdp=$INP/$b/relax_$RELAX_ARM.mdp; d=$(new_attempt $OUT/builds/$b/relax); inputs_sha $b $(arm_of $b) $d
  # [TRR-AMEND] (R4N1: 两臂) 在 attempt 目录生成派生 mdp (同名 relax_$RELAX_ARM.mdp, 使 grompp 警告里 [file ...] 文本不变), = 原 mdp 逐字 + 末尾追加 nstxout/nstvout (不写 f; 其余输出/参数一字不改).
  #         原 mdp 若自带 nstxout/nstvout 行 (精确键名, 不含 nstxout-compressed) 则先滤掉再追加. 原 inputs/*/relax_*.mdp 与其 MANIFEST sha 不动.
  if [ "$SEL_RULE" = 1 ]; then
    awk '!($1=="nstxout"||$1=="nstvout")' $mdp > $d/relax_$RELAX_ARM.mdp
    printf '; [TRR-AMEND] appended by run_R4N1 (取起点规则, 同 R3): relax 期间写 x,v 供末 5 ns 逐帧闸门; 不写 f\nnstxout                  = %s\nnstvout                  = %s\n' $SEL_NSTOUT $SEL_NSTOUT >> $d/relax_$RELAX_ARM.mdp
    ( cd $d && sha256sum relax_$RELAX_ARM.mdp ) >> $d/inputs_sha256.txt; diff <(cat $mdp) <(cat $d/relax_$RELAX_ARM.mdp) > $d/mdp_diff_trr.txt; mdp=$d/relax_$RELAX_ARM.mdp; fi
  gp $d relax $mdp $INP/$b/start.gro $INP/$b/sys.top $INP/$b/index.ndx $MAXWARN_RELAX
  if [ $GP_RC != 0 ]; then setstat $d GROMPP_FAIL "rc=$GP_RC nw=$GP_NW"; rec relax $b $ROLE relax_$RELAX_ARM $d GROMPP_FAIL $MAXWARN_RELAX $GP_RC $GP_NW - - - $NEEDH "grompp 失败, 不自动改 maxwarn/改臂"
    consec_fail relax && halt "relax grompp 连续失败(系统性), 不烧后续 build; 见 $d/grompp.log"; return 1; fi
  if [ "$RELAX_ARM" = literal ]; then   # 2 条警告须与 B1_warnings_expected.txt 逐字一致 (空白折叠后), 否则不跑 (2026.3 的条数/文字可能不同)
    if [ "$GP_NW" != 2 ] || [ "$(norm_ws $d/warnings.txt)" != "$(norm_ws $HERE/B1_warnings_expected.txt)" ]; then
      setstat $d WARN_MISMATCH "nw=$GP_NW 与 B1 原文不符"; rec relax $b $ROLE relax_$RELAX_ARM $d WARN_MISMATCH $MAXWARN_RELAX $GP_RC $GP_NW - - - $NEEDH "literal 警告与预期原文不符 -> 停, 回 K"
      halt "literal relax 警告与 B1 原文不符 ($d/warnings.txt)"; return 1; fi; fi
  tgt=${NSTEPS_OVERRIDE_RELAX:-$(mdp_nsteps $mdp)}; mh=$(awk -v h=$(rem_h) -v t=$TAIL_H 'BEGIN{x=h-t; if(x>1)x=1; if(x<0.05)x=0.05; printf "%.3f",x}'); to=$(( $(rem_s) + 600 )); [ $to -gt 300 ] || to=300
  say "relax $b arm=$RELAX_ARM maxwarn=$MAXWARN_RELAX nsteps=$tgt maxh=$mh"
  run_mdrun $d relax $po $mh $to ${NSTEPS_OVERRIDE_RELAX:+-nsteps $NSTEPS_OVERRIDE_RELAX}
  ls=$(laststep_of $d/relax.log); nn=$(nanchk $d/relax.log); thr_rec $b relax $ls "$(perf_of $d/relax.log)"
  if [ $MD_RC = 0 ] && [ "${ls:-0}" -ge "$tgt" ] && [ "${nn:-1}" = 0 ] && [ -s $d/relax.gro ] && [ -s $d/relax.cpt ]; then st=DONE; else st=RELAX_FAIL; fi
  setstat $d $st "rc=$MD_RC laststep=$ls/$tgt nan=$nn"; rec relax $b $ROLE relax_$RELAX_ARM $d $st $MAXWARN_RELAX $GP_RC $GP_NW $MD_RC $ls "$(perf_of $d/relax.log)" $NEEDH "arm=$RELAX_ARM"
  [ $st = DONE ]; }
# ---- [TRR-AMEND] 取起点规则: relax 末 SEL_WIN_PS 内的 trr 帧逐帧用同一个 t0_gate (prod0 级, lam, 960/720) 判定, 选"最后一个"合格帧作 prod 起点 ----
# 判据/阈值/退出码语义与 step_gate 完全相同 (同一命令行, 只是输入换成 trjconv 取出的单帧 gro, 带速度). 不合格帧不看 prod 结果, 只看起点读数.
# 输出 $OUT/builds/<b>/select/attempt_NNN/{frames.tsv,SELECTED_FRAME.txt,selected.gro,gate_frames/*.json,frames/}; 设置 SEL_GRO (给 step_gate) ; 无合格帧/无 trr 则 SEL_GRO=relax.gro (末帧) -> step_gate 照旧判 VOID_L2 (走原有 relax-gate-fail 路径).
# STATUS: SEL_OK (有合格帧, selected.gro 存在) | SEL_NONE (有帧但 0 合格) | SEL_SKIP (无 trr/GATE_MODE!=host/trjconv 失败: 回退旧行为, 即 relax 末帧 + -t relax.cpt, 记录原因)
# [M2] gro_has_vel <gro>: 所有原子行定宽 >=68 列 (x,y,z 各 8 + vx,vy,vz 各 8, trjconv 默认精度) 且速度字段非全零. (不用 NF==9: 残基号/原子号过大时字段会粘连)
gro_has_vel(){ awk 'NR==2{n=$1+0} NR>2&&NR<=n+2{ if(length($0)<68) bad=1; else if(substr($0,45,24) ~ /[1-9]/) nz=1 } END{exit !(n>0 && !bad && nz)}' "$1"; }
# [M3] sel_verify <build> <sel>: prod 起点 selected.gro 的 sha256 必须 = select 记录 (SELECTED_FRAME.txt) = step_gate 判 PASS 那次的输入 (gate/attempt_*/input.txt 的路径与 sha). 不符返回 1, SELV_MSG 说明.
sel_verify(){ local b=$1 sel=$2 gd s1 s2 s3 gi; SELV_MSG=; s1=$(sha256sum "$sel" 2>/dev/null | cut -d' ' -f1)
  gd=$(done_dir $OUT/builds/$b/gate PASS) || { SELV_MSG="无 PASS 的闸门 attempt"; return 1; }
  gi=$(sed -n 's/^relax_gro=//p' $gd/input.txt | head -1); s2=$(sed -n '2p' $gd/input.txt | cut -d' ' -f1); s3=$(sed -n 's/^selected_gro_sha256=//p' $(dirname "$sel")/SELECTED_FRAME.txt | head -1)
  [ -n "$s1" ] && [ "$s1" = "$s2" ] && [ "$s1" = "$s3" ] && [ "$(readlink -f "$gi")" = "$(readlink -f "$sel")" ] && return 0
  SELV_MSG="prod 起点 $sel sha=$s1 | 闸门判过 $gi sha=$s2 | SELECTED_FRAME sha=$s3"; return 1; }
sel_gro_of(){ local d; d=$(done_dir $OUT/builds/$1/select SEL_OK) && echo $d/selected.gro; }
# [R4N1] 按臂的起点闸 (L2): gate_run <build> <gro> <json名> ; 退出码 0 PASS / 3 不合格 / 其它=执行错误. 判据: hii = PREREG_R4_3day §4 L2 (wpol==1, n_tube==4, 盒变化 <=30%, 组成); lam = D1v2 同款 prod0 2/2/2/2.
gate_run(){ local b=$1 g=$2 j=$3
  if [ "$(arm_of $b)" = hii ]; then $GATE_PY $HERE/gate/t0_gate_hii.py $g --level relax --box0 $(exp_of $b BOX0) --expect-lipids $(exp_of $b EXP_LIP) --expect-w $(exp_of $b EXP_W) --json $j
  else $GATE_PY $HERE/gate/t0_gate_launch.py $g --level prod0 --arm lam --expect-lipids $(exp_of $b EXP_LIP) --expect-w $(exp_of $b EXP_W) --json $j; fi; }
step_select(){ local b=$1 rd=$2 d fd gd T B n=0 nq=0 i f t rc v r65 last= lastt= sh mdp
  SEL_GRO=$rd/relax.gro; [ "$SEL_RULE" = 1 ] || return 0
  d=$(new_attempt $OUT/builds/$b/select); fd=$d/frames; gd=$d/gate_frames; mkdir -p $fd $gd
  if [ "$GATE_MODE" != host ]; then setstat $d SEL_SKIP "GATE_MODE=$GATE_MODE: 无自动闸门, 回退旧行为 (末帧)"; rec select $b $ROLE trr_select $d SEL_SKIP - - - - - - $NEEDH "GATE_MODE=$GATE_MODE"; return 0; fi
  if [ ! -s $rd/relax.trr ] || [ ! -s $rd/relax.tpr ]; then setstat $d SEL_SKIP "无 relax.trr/relax.tpr"; rec select $b $ROLE trr_select $d SEL_SKIP - - - - - - $NEEDH "无 trr: 回退旧行为"; return 0; fi
  mdp=$rd/relax_$RELAX_ARM.mdp; T=$(awk -v n=${NSTEPS_OVERRIDE_RELAX:-$(mdp_nsteps $mdp)} -v dt=$(mdp_dt $mdp) 'BEGIN{printf "%.3f", n*dt}'); B=$(awk -v t=$T -v w=$SEL_WIN_PS 'BEGIN{b=t-w; if(b<0)b=0; printf "%.3f", b}')
  ( cd $fd && echo 0 | GXI=1 CN=$(cn_name sel_$(basename $(dirname $d))_$(basename $d)) gx trjconv -f $rd/relax.trr -s $rd/relax.tpr -b $B -e $T -sep -o fr.gro ) > $d/trjconv.log 2>&1; rc=$?
  n=$(ls -1 $fd/fr*.gro 2>/dev/null | wc -l)
  if [ $rc != 0 ] || [ $n = 0 ]; then setstat $d SEL_SKIP "trjconv rc=$rc nframes=$n"; rec select $b $ROLE trr_select $d SEL_SKIP - - - - - - $NEEDH "trjconv 失败: 回退旧行为, 见 $d/trjconv.log"; return 0; fi
  printf 'idx\tt_ps\tgate_rc\tverdict\treading_0.65_v1\tfile\ttries\n' > $d/frames.tsv; local nerr=0 tries qf=() qt=() k nvb=0 nexp dtm lastframe_t wmsg=
  for f in $(ls -1 $fd/fr*.gro | sort -V); do i=$(basename $f .gro); i=${i#fr}; t=$(head -1 $f | grep -o 't= *[0-9.]*' | sed 's/t= *//'); tries=0
    # [M1] 闸门 t0_gate_launch 约定 rc=0 PASS / rc=3 不合格(VOID); 其他 rc (docker/python 瞬时错误) 重试 SEL_GATE_RETRY(默认2) 次, 仍失败 -> 该帧 ERR (不计入合格)
    while :; do tries=$((tries+1)); fj=$gd/f${i}_try$tries.json; ( cd $gd && gate_run $b $f $(basename $fj) ) > $gd/f${i}_try$tries.out 2>&1; rc=$?   # 每次重试单独文件, 不删 (AMENDMENT_01 S5)
      [ $rc = 0 ] || [ $rc = 3 ] && break; [ $tries -gt ${SEL_GATE_RETRY:-2} ] && break; sleep ${SEL_RETRY_S:-2}; done
    if [ $rc = 0 ] || [ $rc = 3 ]; then
      v=$(tr -d ' \n' < $fj 2>/dev/null | grep -o '"verdict":"[^"]*"' | head -1 | cut -d'"' -f4); r65=$(tr -d ' \n' < $fj 2>/dev/null | grep -o '"0.65":{"v1":\[[0-9,]*\]' | sed 's/.*"v1"://')
    else v=ERR; r65=; nerr=$((nerr+1)); fi
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' $i $t $rc ${v:--} ${r65:--} $(basename $f) $tries >> $d/frames.tsv; lastframe_t=$t
    if [ $rc = 0 ]; then nq=$((nq+1)); qf+=($f); qt+=($t); fi; done
  # [M1] 帧数/末帧时间 sanity: 期望 n≈SEL_WIN_PS/(SEL_NSTOUT*dt) (默认 67), 末帧 t≈T; 不符只记 WARN (不改行为)
  dtm=$(mdp_dt $mdp); nexp=$(awk -v w=$SEL_WIN_PS -v o=$SEL_NSTOUT -v dt=$dtm 'BEGIN{printf "%.2f", w/(o*dt)}')
  awk -v n=$n -v e=$nexp 'BEGIN{d=n-e; if(d<0)d=-d; exit !(d<=1.5)}' || wmsg="WARN: 窗口帧数 $n 与期望 ≈$nexp 不符"
  awk -v a=${lastframe_t:-0} -v T=$T -v iv=$(awk -v o=$SEL_NSTOUT -v dt=$dtm 'BEGIN{print o*dt}') 'BEGIN{d=a-T; if(d<0)d=-d; exit !(d<=iv+0.01)}' || wmsg="$wmsg WARN: 末帧 t=${lastframe_t:-?} 与 T=$T 不符"
  [ $nerr -gt 0 ] && wmsg="$wmsg WARN: ERR 帧 $nerr 个 (闸门执行错误, 重试后仍失败, 不计合格)"
  [ -n "$wmsg" ] && { echo "$wmsg" > $d/WARN.txt; say "select $b: $wmsg"; }
  # [M2] 从最后一个合格帧往前找第一个"带速度"的 gro (见 gro_has_vel); 无速度的合格帧不选并记 novel_frames.txt
  last=; lastt=; k=$(( ${#qf[@]} - 1 ))
  while [ $k -ge 0 ] && [ $nerr -le ${SEL_ERR_MAX:-3} ]; do if gro_has_vel ${qf[$k]}; then last=${qf[$k]}; lastt=${qt[$k]}; break; else nvb=$((nvb+1)); echo "no-velocity: $(basename ${qf[$k]}) t=${qt[$k]}" >> $d/novel_frames.txt; fi; k=$((k-1)); done
  if [ $nerr -gt ${SEL_ERR_MAX:-3} ]; then   # [M1] ERR 帧过多: 选帧不可信 -> SEL_SKIP, 回退原路径 (relax 末帧, step_gate 照判, 合格才 prod -t relax.cpt)
    { echo "build=$b"; echo "selected_t_ps=SKIP"; echo "n_frames_window=$n"; echo "n_err=$nerr"; echo "n_qualified=$nq"; echo "window_ps=[$B,$T]"; echo "-> ERR 帧>${SEL_ERR_MAX:-3}: SEL_SKIP, 按原路径末帧判"; } > $d/SELECTED_FRAME.txt
    setstat $d SEL_SKIP "ERR frames=$nerr>${SEL_ERR_MAX:-3}"; rec select $b $ROLE trr_select $d SEL_SKIP - - - - - - $NEEDH "ERR 帧 $nerr>${SEL_ERR_MAX:-3}: 回退旧行为"; say "select $b: ERR 帧 $nerr -> SEL_SKIP (末帧原路径)"; last=
  elif [ -n "$last" ]; then cp $last $d/selected.gro; sh=$(sha256sum $d/selected.gro | cut -d' ' -f1)
    { echo "build=$b"; echo "selected_t_ps=$lastt"; echo "selected_file=$(basename $last)"; echo "n_frames_window=$n"; echo "n_qualified=$nq"; echo "n_err=$nerr"; echo "n_qualified_novel=$nvb"; echo "qualified_fraction=$(awk -v a=$nq -v b=$n 'BEGIN{printf "%.4f",a/b}')"
      echo "window_ps=[$B,$T]"; echo "selected_gro_sha256=$sh"; echo "trr_sha256=$(sha256sum $rd/relax.trr | cut -d' ' -f1)"; echo "rule=last qualified frame (with velocities) in window (gate = $( [ $(arm_of $b) = hii ] && echo 't0_gate_hii relax L2' || echo 't0_gate_launch prod0 lam'), expect from inputs/$b/expect.env, thresholds unchanged)"; [ -n "$wmsg" ] && echo "$wmsg"; } > $d/SELECTED_FRAME.txt
    SEL_GRO=$d/selected.gro; setstat $d SEL_OK "t_ps=$lastt qualified=$nq/$n err=$nerr"; rec select $b $ROLE trr_select $d SEL_OK - - - - - - $NEEDH "selected_t_ps=$lastt qualified=$nq/$n err=$nerr novel=$nvb sha=${sh:0:12}"; say "select $b: 选中帧 t=$lastt ps, 合格 $nq/$n (ERR $nerr, 无速度跳过 $nvb)"
  else { echo "build=$b"; echo "selected_t_ps=NONE"; echo "n_frames_window=$n"; echo "n_qualified=$nq"; echo "n_err=$nerr"; echo "n_qualified_novel=$nvb"; echo "qualified_fraction=0.0000"; echo "window_ps=[$B,$T]"; echo "-> 按原有 relax-gate-fail 路径作废 (step_gate 对末帧判 VOID_L2)"; } > $d/SELECTED_FRAME.txt
    setstat $d SEL_NONE "qualified=$nq/$n novel=$nvb"; rec select $b $ROLE trr_select $d SEL_NONE - - - - - - $NEEDH "qualified=$nq/$n (无速度 $nvb) -> 作废"; say "select $b: $nq/$n 帧合格(无速度 $nvb) -> VOID"; fi
  # 清理 (prod 前, 仅 SEL_KEEP_FRAMES=0 时): 只删本函数刚生成的非选中帧 .gro; trr/frames.tsv/各帧 json 保留. 本包默认 1 = 不删
  if [ "$SEL_KEEP_FRAMES" != 1 ]; then for f in $(ls -1 $fd/fr*.gro); do [ "$f" = "${last:-}" ] || rm -f -- "$f"; done; fi
  return 0; }
# ---- 闸门 (L2: relax 末帧 = prod 帧 0; v1/v2 同款 t0_gate; 只用起点读数, 不看 prod 结果) ----
step_gate(){ local b=$1 rd=$2 gin=${3:-$2/relax.gro} arm=$(arm_of $1) d rc st w0 t   # [TRR-AMEND] 第 3 参数 = 被判定的起点帧 (默认=旧行为 relax.gro)
  d=$(new_attempt $OUT/builds/$b/gate); echo "relax_gro=$gin" > $d/input.txt; sha256sum $gin >> $d/input.txt
  if [ "$GATE_MODE" = manual ]; then w0=$(date +%s); say "gate(manual) 等 $OUT/manual_gate/$b.PASS|.VOID (输入 $gin; 最长 ${GATE_WAIT_MAX_H}h)"
    while :; do [ -f $OUT/manual_gate/$b.PASS ] && { rc=0; break; }; [ -f $OUT/manual_gate/$b.VOID ] && { rc=3; break; }
      t=$(( $(date +%s) - w0 )); if awk -v t=$t -v m=$GATE_WAIT_MAX_H 'BEGIN{exit !(t/3600>=m)}' || [ $(rem_s) -lt 600 ]; then rc=99; break; fi; sleep ${GATE_POLL_S:-30}; done
  else ( cd $d && gate_run $b $gin gate.json ) > $d/gate.out 2>&1; rc=$?; fi
  case $rc in 0) st=PASS;; 3) st=VOID_L2;; 99) st=GATE_TIMEOUT;; *) st=GATE_ERROR;; esac
  setstat $d $st "rc=$rc mode=$GATE_MODE"; rec gate $b $ROLE t0_gate_L2_$arm $d $st - - - $rc - - $NEEDH "mode=$GATE_MODE reading=$(grep -o '"verdict": *"[^"]*"' $d/gate.json 2>/dev/null | head -1)"
  case $st in VOID_L2) ledger_add void $b;; GATE_ERROR) halt "闸门执行错误 (python 依赖?) 见 $d/gate.out";; esac
  GATE_ST=$st; [ $st = PASS ]; }
# ---- prod ----
step_prod(){ local b=$1 po=$2 rd=$3 sel=${4:-} arm=$(arm_of $1) mdp d prev tgt mh to ls rc st nn lg res=""   # [TRR-AMEND] 第 4 参数 sel = 取起点规则选中的 selected.gro (空=旧行为)
  mdp=$INP/$b/prod_$arm.mdp; tgt=${NSTEPS_OVERRIDE_PROD:-$(mdp_nsteps $mdp)}
  mh=$(awk -v h=$(rem_h) -v t=$TAIL_H 'BEGIN{printf "%.3f", h-t}'); if ! awk -v m=$mh -v p=$PROD_MIN_H 'BEGIN{exit !(m>=p)}'; then
    d=$(new_attempt $OUT/builds/$b/prod); setstat $d SKIP_NO_TIME_PROD "maxh=$mh<$PROD_MIN_H"; rec prod $b $ROLE prod_$arm $d SKIP_NO_TIME_PROD - - - - - - $NEEDH "闸门后剩余不足, relax+gate 结果保留"; return 1; fi
  prev=$(last_attempt $OUT/builds/$b/prod); to=$(( $(rem_s) + 600 ))
  tpr=$(ls -1 $OUT/builds/$b/prod/attempt_*/prod.tpr 2>/dev/null | head -1); cpt=$(ls -1 $OUT/builds/$b/prod/attempt_*/prod*.cpt 2>/dev/null | grep -v _prev | tail -1)
  if [ -n "$prev" ] && [ -n "$tpr" ] && [ -n "$cpt" ] && [ "$(last_state $OUT/builds/$b/prod)" != DONE ]; then   # 续跑: 新 attempt + -noappend (旧 attempt 一个字节都不动)
    d=$(new_attempt $OUT/builds/$b/prod); res="-s $tpr -cpi $cpt -noappend"; printf 'tpr=%s\ncpt=%s\n' $tpr $cpt > $d/RESUME_FROM.txt; GP_RC=0; GP_NW=-
  else d=$(new_attempt $OUT/builds/$b/prod); inputs_sha $b $arm $d
    if [ -n "$sel" ] && ! sel_verify $b $sel; then   # [M3] prod 起点必须就是闸门判过的 selected.gro (sha256 比对); 不一致 -> VOID 并记日志, 不 grompp
      setstat $d VOID_SEL_MISMATCH "起点与闸门判过的帧不一致"; echo "$SELV_MSG" > $d/VOID_SEL_MISMATCH.txt; rec prod $b $ROLE prod_$arm $d VOID_SEL_MISMATCH - - - - - - $NEEDH "起点 sha 与闸门判过的不一致: $SELV_MSG"
      say "VOID $b: prod 起点与闸门判过的帧不一致 ($SELV_MSG)"; ledger_add void $b; return 1; fi
    # [TRR-AMEND] 有 sel: -c selected.gro (带速度, 即闸门判过的那一帧), 不带 -t (grompp 的 -t 会用 cpt 的末帧坐标/速度覆盖 -c); 无 sel: 旧行为 relax 末帧 + -t relax.cpt
    if [ -n "$sel" ]; then echo "start_gro=$sel" > $d/START_FRAME.txt; sha256sum $sel >> $d/START_FRAME.txt; cp $(dirname $sel)/SELECTED_FRAME.txt $d/SELECTED_FRAME.txt 2>/dev/null
      gp $d prod $mdp $sel $INP/$b/sys.top $INP/$b/index.ndx $MAXWARN_PROD
    else gp $d prod $mdp $rd/relax.gro $INP/$b/sys.top $INP/$b/index.ndx $MAXWARN_PROD -t $rd/relax.cpt; fi
    if [ $GP_RC != 0 ]; then setstat $d GROMPP_FAIL "rc=$GP_RC nw=$GP_NW"; rec prod $b $ROLE prod_$arm $d GROMPP_FAIL $MAXWARN_PROD $GP_RC $GP_NW - - - $NEEDH "prod grompp 失败 (不重试)"
      consec_fail prod && halt "prod grompp 连续失败(系统性); 见 $d/grompp.log"; return 1; fi; fi
  say "prod $b arm=$arm nsteps=$tgt maxh=$mh ${res:+(resume)}"
  run_mdrun $d prod $po $mh $to ${NSTEPS_OVERRIDE_PROD:+-nsteps $NSTEPS_OVERRIDE_PROD} $res
  lg=$(ls -1 $d/prod*.log 2>/dev/null | tail -1); ls=$(laststep_of $lg); nn=$(nanchk $lg)
  if [ $MD_RC = 0 ] && [ "${ls:-0}" -ge "$tgt" ] && grep -q '^Finished mdrun' "$lg" 2>/dev/null; then st=DONE; [ "${nn:-1}" = 0 ] || st=NUMERIC_FAIL
  elif [ $MD_RC = 0 ] && grep -q '^Finished mdrun' "$lg" 2>/dev/null; then st=TRUNC; elif [ $MD_RC = 124 ] || [ $MD_RC = 137 ]; then st=TRUNC_TIMEOUT; else st=FAIL; fi
  ( cd $d && sha256sum prod*.tpr prod*.xtc prod*.edr prod*.log prod*.cpt prod*.gro 2>/dev/null > SHA256_out.txt )
  thr_rec $b prod $ls "$(perf_of $lg)"; setstat $d $st "rc=$MD_RC laststep=$ls/$tgt nan=$nn"
  rec prod $b $ROLE prod_$arm $d $st $MAXWARN_PROD ${GP_RC:--} ${GP_NW:--} $MD_RC $ls "$(perf_of $lg)" $NEEDH "target=$tgt"; [ $st = DONE ]; }
# run_build <build> <role> <pinoff> <kind main|supp> [note]
run_build(){ local b=$1 po=$3 kind=$4 s rd; ROLE=$2; valid_name $b || { say "REFUSE 非法/禁用 build 名 $b"; rec skip $b $ROLE - - REFUSE_NAME - - - - - - - "名字非法/无 expect.env"; return 9; }
  mkdir -p $OUT/builds/$b; NEEDH=$(need_h $b); halted && { rec skip $b $ROLE - - SKIP_HALT - - - - - - - $NEEDH "HALT 文件存在"; return 3; }
  if [ $kind = main ] && ! awk -v h=$(rem_h) -v m=$MINRUN_H 'BEGIN{exit !(h>=m)}'; then say "SKIP_NO_TIME $b 剩余 $(rem_h)h < $MINRUN_H"; rec skip $b $ROLE - - SKIP_NO_TIME - - - - - - - $NEEDH "主批剩余不足"; return 3; fi
  s=$(last_state $OUT/builds/$b/prod); [ "$s" = DONE ] && { say "$b prod 已 DONE, 跳过"; return 0; }
  [ "$(last_state $OUT/builds/$b/gate)" = VOID_L2 ] && { say "$b 已 VOID_L2, 跳过"; return 5; }
  if ! rd=$(done_dir $OUT/builds/$b/relax DONE); then
    if ! step_relax $b $po; then [ "$REPLACE_ON_RELAX_FAIL" = 1 ] && [ "$(last_state $OUT/builds/$b/relax)" = RELAX_FAIL ] && ledger_add void $b; return 4; fi
    rd=$(done_dir $OUT/builds/$b/relax DONE); fi
  if ! done_dir $OUT/builds/$b/gate PASS >/dev/null; then
    step_select $b $rd   # [TRR-AMEND] 取起点规则 (R4N1: 两臂, SEL_RULE=1; 否则 SEL_GRO=relax.gro 同旧行为)
    step_gate $b $rd $SEL_GRO || { say "$b 闸门 $GATE_ST -> 不进 prod"; return 5; }; fi
  step_prod $b $po $rd $( [ "$SEL_RULE" = 1 ] && sel_gro_of $b ); }
# ======================================================================= [R4N2] 续跑 (ext): 第 1 晚 400 ns 终点 -> 目标 ns (默认 1200 = 1.2 µs)
# 链文件: chains/ext_<机>_<A|B>.txt 与 chains/fill_<机>.txt, 每行 "<build> <目标 ns>". 目录 $OUT/builds/<b>/ext<目标>/attempt_NNN (新目录, 源目录只读不碰).
# 源 (ext_src): (1) 本 OUT 里比目标低的最高一段 ext<T'> DONE; 否则 (2) 先前 run 的 prod DONE: EXT_SRC_RUNS (默认 $HOME/R4N1/R4N1_run_<机>_*) 里恰好 1 个
#   builds/<b>/prod/attempt_*/STATUS=DONE (0 个 -> EXT_NO_SRC, 不从头跑; >1 个 -> EXT_SRC_AMBIG, 要人指定 EXT_SRC_RUNS).
#   源须: STATUS DONE 且 laststep=目标步数 (prod: 20000000), 有 tpr 和 cpt (不用 _prev), 二者 sha256 = 源目录 SHA256_out.txt 里的记录 (防被改/半写).
# 新起: cp 源 tpr/cpt -> attempt/src.tpr src.cpt (EXT_SRC.txt 记源路径+sha); gmx convert-tpr -s src.tpr -nsteps <目标步数> -o ext.tpr; mdrun -deffnm ext -s ext.tpr -cpi src.cpt -noappend
# 续 (本 OUT 里该段有未 DONE 的 attempt 且有 ext.cpt): 新 attempt, -s <首个 attempt 的 ext.tpr> -cpi <最新 ext.cpt> -noappend.
# DONE = mdrun rc 0 + 最后 log 的 laststep >= 目标步数 + "Finished mdrun" + nan/LINCS 0. 输出文件 ext.partNNNN.* (mdrun -noappend 命名), SHA256_out.txt 同 prod.
EXT_SRC_RUNS=${EXT_SRC_RUNS:-"$HOME/R4N1/R4N1_run_${MACHINE}_*"}
ext_steps(){ awk -v t=$2 -v dt=$(mdp_dt $INP/$1/prod_$(arm_of $1).mdp) 'BEGIN{printf "%d", t*1000/dt + 0.5}'; }
ext_from_ns(){ local b=$1 T=$2 x best=; for x in $(ls -1d $OUT/builds/$b/ext[0-9]* 2>/dev/null); do x=${x##*/ext}; [ "$x" -lt "$T" ] && [ "$(last_state $OUT/builds/$b/ext$x)" = DONE ] && { [ -z "$best" ] || [ $x -gt $best ]; } && best=$x; done
  [ -n "$best" ] && echo $best || awk -v n=$(mdp_nsteps $INP/$b/prod_$(arm_of $b).mdp) -v dt=$(mdp_dt $INP/$b/prod_$(arm_of $b).mdp) 'BEGIN{printf "%d", n*dt/1000+0.5}'; }
need_h_ext(){ local b=$1 T=$2 P f; f=$(ext_from_ns $b $T); P=$(awk -v p=$(perf_eff) -v r=$PERF_REF_BEADS -v n=$(exp_of $b EXP_ATOMS) 'BEGIN{if(n+0<=0)n=r; printf "%.1f", p*r/n}')
  awk -v P=$P -v T=$T -v f=$f -v o=$OVH_H 'BEGIN{d=T-f; if(d<0)d=0; printf "%.3f", d/P*24 + o}'; }
# ext_lower_busy <b> <T>: 本 OUT 有比 T 低的段目录但其最后状态不是 DONE (正在跑/截断) -> 0 (忙, 不许跳段); EXT_LB = 该段
ext_lower_busy(){ local x; EXT_LB=; for x in $(ls -1d $OUT/builds/$1/ext[0-9]* 2>/dev/null); do x=${x##*/ext}; [ "$x" -lt "$2" ] && [ "$(last_state $OUT/builds/$1/ext$x)" != DONE ] && { EXT_LB=ext$x; return 0; }; done; return 1; }
sha_ok(){ local dir=$1 f=$2 want got; want=$(awk -v f="$f" '$2==f||$2=="*"f{print $1; exit}' $dir/SHA256_out.txt 2>/dev/null); got=$(sha256sum $dir/$f 2>/dev/null | cut -d' ' -f1); [ -n "$want" ] && [ "$want" = "$got" ]; }
# ext_src_check <srcdir> <prefix prod|ext> <need_step>: 设 ES_TPR ES_CPT ES_MSG; 0=合格
ext_src_check(){ local d=$1 pf=$2 need=$3 st ls td; ES_TPR=; ES_CPT=; ES_MSG=
  st=$(cut -d' ' -f1 $d/STATUS 2>/dev/null); [ "$st" = DONE ] || { ES_MSG="$d STATUS=$st 非 DONE"; return 1; }
  ls=$(sed -n 's/.*laststep=\([0-9]*\)\/.*/\1/p' $d/STATUS); [ "${ls:-0}" -ge "$need" ] || { ES_MSG="$d laststep=$ls < $need"; return 1; }
  [ -s $d/$pf.cpt ] || { ES_MSG="$d 无 $pf.cpt"; return 1; }; sha_ok $d $pf.cpt || { ES_MSG="$d/$pf.cpt sha 与 SHA256_out.txt 不符/无记录"; return 1; }
  if [ -s $d/$pf.tpr ]; then td=$d; else td=$(dirname $(sed -n 's/^tpr=//p' $d/RESUME_FROM.txt 2>/dev/null | head -1) 2>/dev/null); fi
  [ -n "$td" ] && [ -s $td/$pf.tpr ] || { ES_MSG="$d 找不到 $pf.tpr (本目录无, RESUME_FROM.txt 也无)"; return 1; }
  sha_ok $td $pf.tpr || { ES_MSG="$td/$pf.tpr sha 与 SHA256_out.txt 不符/无记录"; return 1; }
  ES_TPR=$td/$pf.tpr; ES_CPT=$d/$pf.cpt; ES_MSG="ok laststep=$ls"; return 0; }
# ext_src <b> <T>: 设 EXT_SRC_DIR EXT_SRC_KIND ES_TPR ES_CPT ES_MSG
ext_src(){ local b=$1 T=$2 f d c n=0 g; EXT_SRC_DIR=; EXT_SRC_KIND=; f=$(ext_from_ns $b $T)
  if [ -d $OUT/builds/$b/ext$f ]; then d=$(done_dir $OUT/builds/$b/ext$f DONE) || { ES_MSG="本 OUT ext$f 无 DONE"; return 1; }
    ext_src_check $d ext $(ext_steps $b $f) || return 1; EXT_SRC_DIR=$d; EXT_SRC_KIND=ext$f; return 0; fi
  for g in $EXT_SRC_RUNS; do for d in $(ls -1d $g/builds/$b/prod 2>/dev/null); do c=$(done_dir $d DONE) && { n=$((n+1)); EXT_SRC_DIR=$c; }; done; done
  [ $n = 0 ] && { ES_MSG="EXT_SRC_RUNS=($EXT_SRC_RUNS) 里无 $b prod DONE"; EXT_SRC_KIND=none; return 1; }
  [ $n -gt 1 ] && { ES_MSG="EXT_SRC_RUNS 里 $b prod DONE 有 $n 个 (须恰好 1 个; 设 EXT_SRC_RUNS=<目录> 指定)"; EXT_SRC_KIND=ambig; EXT_SRC_DIR=; return 1; }
  ext_src_check $EXT_SRC_DIR prod $(ext_steps $b $f) || return 1; EXT_SRC_KIND=prior_prod; return 0; }
# run_ext <build> <目标ns> <role> <pinoff> <kind main|supp>
run_ext(){ local b=$1 T=$2 po=$4 kind=$5 s d tgt mh to ls nn lg st res tpr0 cpt0 v; ROLE=$3; XB=$b
  valid_name $b || { rec skip $b $ROLE ext$T - REFUSE_NAME - - - - - - - "名字非法/无 expect.env"; return 9; }
  [ "$(arm_of $b)" = hii ] || { rec skip $b $ROLE ext$T - REFUSE_EXT_ARM - - - - - - - "本包 ext 只用于 hii"; return 9; }
  s=$OUT/builds/$b/ext$T; mkdir -p $s; NEEDH=$(need_h_ext $b $T); tgt=$(ext_steps $b $T)
  halted && { rec skip $b $ROLE ext$T - SKIP_HALT - - - - - - $NEEDH "HALT 文件存在"; return 3; }
  [ "$(last_state $s)" = DONE ] && { say "$b ext$T 已 DONE, 跳过"; return 0; }
  ext_lower_busy $b $T && { say "$b ext$T: 低一段 ($EXT_LB) 未 DONE, 不跳段续跑"; rec skip $b $ROLE ext$T - EXT_WAIT_LOWER - - - - - - $NEEDH "低一段 $EXT_LB 未 DONE"; return 6; }
  if [ $kind = main ] && ! awk -v h=$(rem_h) -v m=$MINRUN_H 'BEGIN{exit !(h>=m)}'; then rec skip $b $ROLE ext$T - SKIP_NO_TIME - - - - - - $NEEDH "剩余 $(rem_h)h < MINRUN_H"; return 3; fi
  mh=$(awk -v h=$(rem_h) -v t=$TAIL_H 'BEGIN{printf "%.3f", h-t}'); if ! awk -v m=$mh -v p=$PROD_MIN_H 'BEGIN{exit !(m>=p)}'; then
    d=$(new_attempt $s); setstat $d SKIP_NO_TIME_PROD "maxh=$mh<$PROD_MIN_H"; rec ext $b $ROLE ext$T $d SKIP_NO_TIME_PROD - - - - - - $NEEDH "剩余不足"; return 1; fi
  to=$(( $(rem_s) + 600 )); tpr0=$(ls -1 $s/attempt_*/ext.tpr 2>/dev/null | head -1); cpt0=$(ls -1 $s/attempt_*/ext.cpt 2>/dev/null | tail -1)
  if [ -n "$tpr0" ] && [ -n "$cpt0" ]; then d=$(new_attempt $s); res="-s $tpr0 -cpi $cpt0 -noappend"; printf 'tpr=%s\ncpt=%s\n' $tpr0 $cpt0 > $d/RESUME_FROM.txt
  else
    if ! ext_src $b $T; then d=$(new_attempt $s); st=EXT_NO_SRC; [ "$EXT_SRC_KIND" = ambig ] && st=EXT_SRC_AMBIG
      setstat $d $st "$ES_MSG"; rec ext $b $ROLE ext$T $d $st - - - - - - $NEEDH "$ES_MSG (不从头跑)"; say "$st $b ext$T: $ES_MSG"; return 6; fi
    d=$(new_attempt $s); cp $ES_TPR $d/src.tpr && cp $ES_CPT $d/src.cpt || { setstat $d EXT_COPY_FAIL "cp 失败"; rec ext $b $ROLE ext$T $d EXT_COPY_FAIL - - - - - - $NEEDH "cp 源失败"; return 6; }
    { echo "build=$b target_ns=$T target_steps=$tgt"; echo "src_kind=$EXT_SRC_KIND"; echo "src_dir=$EXT_SRC_DIR"; echo "src_check=$ES_MSG"; echo "src_tpr=$ES_TPR $(sha256sum $ES_TPR | cut -d' ' -f1)"; echo "src_cpt=$ES_CPT $(sha256sum $ES_CPT | cut -d' ' -f1)"
      ( cd $d && sha256sum src.tpr src.cpt ); } > $d/EXT_SRC.txt
    ( cd $d && CN=$(cn_name cvt_$(basename $s)_$(basename $d)) gx convert-tpr -s src.tpr -nsteps $tgt -o ext.tpr ) > $d/convert.log 2>&1; GP_RC=$?; GP_NW=-
    if [ $GP_RC != 0 ] || [ ! -s $d/ext.tpr ]; then setstat $d EXT_CONVERT_FAIL "rc=$GP_RC"; rec ext $b $ROLE ext$T $d EXT_CONVERT_FAIL - $GP_RC - - - - $NEEDH "convert-tpr 失败, 见 $d/convert.log"
      consec_fail ext && halt "convert-tpr 连续失败(系统性); 见 $d/convert.log"; return 6; fi
    v=$( cd $d && CN=$(cn_name dmp_$(basename $s)_$(basename $d)) gx dump -s ext.tpr 2>/dev/null | awk '$1=="nsteps"{print $3; exit}' ); echo "ext.tpr nsteps(dump)=${v:-?} 期望 $tgt" >> $d/EXT_SRC.txt
    [ -z "$v" ] && { echo "WARN nsteps 未复核 (gmx dump 无输出); DONE 仍要求 laststep>=$tgt" >> $d/EXT_SRC.txt; rec ext $b $ROLE ext$T $d EXT_TPR_UNVERIFIED - 0 - - - - $NEEDH "gmx dump 未读到 nsteps (未复核, 不 HALT)"; say "WARN $b ext$T: dump 未读到 nsteps"; }   # [R4N2-rv1]
    [ -n "$v" ] && [ "$v" != "$tgt" ] && { setstat $d EXT_TPR_BAD "nsteps=$v!=$tgt"; rec ext $b $ROLE ext$T $d EXT_TPR_BAD - 0 - - - - $NEEDH "ext.tpr nsteps=$v 期望 $tgt"; halt "ext.tpr nsteps 不符 ($d)"; return 6; }
    ( cd $d && sha256sum ext.tpr ) >> $d/EXT_SRC.txt; res="-s ext.tpr -cpi src.cpt -noappend"; fi
  say "ext $b -> ${T} ns (nsteps=$tgt) maxh=$mh need≈${NEEDH}h ${tpr0:+(resume)} mps=${X_MPS_NOTE:-?}"
  run_mdrun $d ext $po $mh $to $res
  lg=$(ls -1 $d/ext*.log 2>/dev/null | sort -V | tail -1); ls=$(laststep_of $lg); nn=$(nanchk $lg)
  if [ $MD_RC = 0 ] && [ "${ls:-0}" -ge "$tgt" ] && grep -q '^Finished mdrun' "$lg" 2>/dev/null; then st=DONE; [ "${nn:-1}" = 0 ] || st=NUMERIC_FAIL
  elif [ $MD_RC = 0 ] && grep -q '^Finished mdrun' "$lg" 2>/dev/null; then st=TRUNC; elif [ $MD_RC = 124 ] || [ $MD_RC = 137 ]; then st=TRUNC_TIMEOUT; else st=FAIL; fi
  ( cd $d && sha256sum ext*.tpr ext*.xtc ext*.edr ext*.log ext*.cpt ext*.gro 2>/dev/null > SHA256_out.txt )
  thr_rec $b ext $ls "$(perf_of $lg)"; setstat $d $st "rc=$MD_RC laststep=$ls/$tgt nan=$nn"
  rec ext $b $ROLE ext$T $d $st $MAXWARN_PROD ${GP_RC:--} - $MD_RC $ls "$(perf_of $lg)" $NEEDH "target_ns=$T mps=${X_MPS_NOTE:-?}"; [ $st = DONE ]; }
# ======================================================================= [R4N1x] 追加: ONLY 过滤 / 等主槽 / 追加包 MPS
# ---- ONLY: 只跑挑出来的条目 (分段闭环: 中途判读后只跑其中一部分). 空 = 全跑.
#  ONLY="tok1,tok2 tok3" 或 ONLY_FILE=<文件, 每行一个 tok, # 注释>; tok = build 名 | 格名 (体系_水合_温度_臂, 如 DOPC_h050_T320_hiiL) | 组名:
#    Larm (全部 hiiL) | C4hii | C4lam | C4ruler (C4 的 DOPE/DOPC 两臂) | C4IS (C4 的 MC3H/MC3 两臂) | C4 (C4 全部)
#  不在 ONLY 里的主链/补跑条目记 SKIP_NOT_ONLY (不进账本 claim, 之后 APPEND_TO 换 ONLY 可再跑); 替补只顶本次跑过的 VOID 主种子, 天然跟着 ONLY 走.
ONLY_TOKS=$( { echo "${ONLY:-}" | tr ', ' '\n\n'; [ -n "${ONLY_FILE:-}" ] && grep -vE '^\s*(#|$)' "$ONLY_FILE" | awk '{print $1}'; } | grep -v '^$' | sort -u | tr '\n' ' ')
groups_of(){ local b=$1 c; c=$(cell_of $b); case $b in *_hiiL_*) echo Larm;; esac
  case $b in *_h050_T350_hii_*) echo C2;; esac   # [R4N2] C2 (ext 用 tok: C2 / ext / fill, 见 only_ok_ext)
  case $b in *_h100_T350_*) echo C4; case $b in *_hii_*) echo C4hii;; *_lam_*) echo C4lam;; esac
    case $b in R4N1_DOPE_*|R4N1_DOPC_*) echo C4ruler;; R4N1_MC3H_*|R4N1_MC3_*) echo C4IS;; esac;; esac; echo $c; echo $b; }
only_ok_ext(){ [ -z "$ONLY_TOKS" ] && return 0; local t; for t in $ONLY_TOKS; do case $t in ext|fill) [ $t = ${2:-ext} ] && return 0;; esac; done; only_ok $1; }   # [R4N2]
only_ok(){ [ -z "$ONLY_TOKS" ] && return 0; local g t; for g in $(groups_of $1); do for t in $ONLY_TOKS; do [ "$g" = "$t" ] && return 0; done; done; return 1; }
# ---- 等主槽: 主包 (已发, 不改) 的完成标记只有日志行: $MAINRUN/slots/<机>_<槽>.log 的 "== slot end" 与 $MAINRUN/orchestrator.log 的 "== machine <机> done"
#   (主包 RUN_META.txt 只在开头写一次, 没有 done 字段 -> 用这两行作 "RUN_META/slot 标 done" 的等价物, README §3 写明).
#  WAIT_MAIN=auto (默认: 找 $JMAIN/R4N1_run_<机>_* 唯一一个) | <主 run 目录> | none (不依赖主包, 只要求本槽无主包容器)
#  START_AT="<date -d 可解析的时间>" (调度手动接入时间点): 此前不起; 到点后按下面的 "槽空" 条件起.
#  GO 文件 $OUT/slots/<机>_<槽>.GO (调度手动接入, 任何时刻放): 视为 "调度确认主槽不会再起新条", 只再要求 GO 文件已放 >= GO_QUIET_S(120 s)
#     且 本槽连续 >= GO_QUIET_S 没观测到主包容器 (按 WAIT_POLL_S 轮询观测; 从开始等待起算, 轮询间隙里一闪而过的容器看不到).
#  槽空 (任一): MAIN_DONE (主槽日志最后一个 slot 标记是 "== slot end", 或主机日志在最后一个 "OUT=" 之后有 "machine <机> done") | MAIN_GONE (主 run 目录在且主 flock 可得 = 主编排已退出)
#              | MAIN_IDLE (本槽无主包容器且主槽日志 >= WAIT_IDLE_S 没更新; 默认 1200 s, 防把闸门 python 的空档误判为完) | GO | WAIT_MAIN=none
#  任何情况下, 起跑那一刻本槽必须无主包容器 (^R4N1_<机>_<pid>_<机>_<槽>_; 防同一 pin 双开), 这一条不可绕过.
#  等待中剩余 < MINRUN_H -> 放弃本槽 (rec WAIT_GAVE_UP), 不起; HALT ($OUT/HALT) -> 放弃.
# [R4N2] WAIT_MAIN 默认 none: 第 2 晚没有主包
JMAIN=${JMAIN:-$HOME/R4N1}; WAIT_MAIN=${WAIT_MAIN:-none}; WAIT_POLL_S=${WAIT_POLL_S:-60}; WAIT_IDLE_S=${WAIT_IDLE_S:-1200}; GO_QUIET_S=${GO_QUIET_S:-120}; START_AT=${START_AT:-}
main_run(){ case "$WAIT_MAIN" in none) echo;; auto) local x; x=$(ls -1d $JMAIN/R4N1_run_${MACHINE}_* 2>/dev/null); [ $(echo "$x" | grep -c .) = 1 ] && echo "$x";; *) echo "$WAIT_MAIN";; esac; }
main_slot_cn(){ [ "$MODE" = local ] && { [ -n "${FAKE_MAIN_CN_FILE:-}" ] && grep -E "^R4N1_${MACHINE}_[0-9]+_${MACHINE}_$1_" "$FAKE_MAIN_CN_FILE" 2>/dev/null; return 0; }
  docker ps --format '{{.Names}}' 2>/dev/null | grep -E "^R4N1_${MACHINE}_[0-9]+_${MACHINE}_$1_"; }   # $1 = A|B; local 冒烟用 FAKE_MAIN_CN_FILE 模拟 docker ps
main_any_cn(){ [ "$MODE" = local ] && { [ -n "${FAKE_MAIN_CN_FILE:-}" ] && grep -E "^R4N1_${MACHINE}_" "$FAKE_MAIN_CN_FILE" 2>/dev/null; return 0; }; docker ps --format '{{.Names}}' 2>/dev/null | grep -E "^R4N1_${MACHINE}_"; }
main_lock_free(){ local mr=$1; [ -n "$mr" ] && [ -d "$mr" ] || return 1; [ -e "$JMAIN/.R4N1_${MACHINE}.flock" ] || return 0   # 主 run 目录在而锁文件不在 = 不是在跑的主包
  ( exec 8<"$JMAIN/.R4N1_${MACHINE}.flock"; flock -n -s 8 ) 2>/dev/null; }   # 只读打开 + 共享锁试探 (主包持有排他锁时失败); 主 run 目录已存在说明主包早已拿过锁, 不会与其 take_lock 竞争
slot_free_reason(){ local x=$1 mr lg ml age; mr=$(main_run)
  [ -n "$(main_slot_cn $x)" ] && { echo; return; }
  [ -f "$OUT/slots/${MACHINE}_$x.GO" ] && { local nw=$(date +%s); [ $(( nw - $(stat -c %Y "$OUT/slots/${MACHINE}_$x.GO") )) -ge $GO_QUIET_S ] && [ $(( nw - ${LAST_CN_SEEN:-$nw} )) -ge $GO_QUIET_S ] && echo GO; return; }   # GO: 文件放了 >= GO_QUIET_S 且 本槽最后一次看到主包容器 (或开始等待) 已 >= GO_QUIET_S
  [ "$WAIT_MAIN" = none ] && { echo NONE; return; }
  [ -n "$mr" ] || { echo; return; }
  lg=$mr/slots/${MACHINE}_$x.log; ml=$mr/orchestrator.log
  grep -E '== slot (start|end)' "$lg" 2>/dev/null | tail -1 | grep -q '== slot end' && { echo MAIN_DONE; return; }; grep -E "^OUT=|== machine $MACHINE done" "$ml" 2>/dev/null | tail -1 | grep -q "== machine $MACHINE done" && { echo MAIN_DONE; return; }   # [REVIEW v3] 只认"最后一个"标记: 主包 APPEND_TO 续跑会在同一日志追加新的 slot start / OUT=, 旧的 slot end / machine done 不再算
  main_lock_free "$mr" && { echo MAIN_GONE; return; }
  [ -f "$lg" ] && age=$(( $(date +%s) - $(stat -c %Y "$lg") )) && [ $age -ge $WAIT_IDLE_S ] && { echo MAIN_IDLE_${age}s; return; }
  echo; }
wait_slot(){ local x=$1 r t0=$(date +%s) n=0 sa
  ledger_has slotstart ${MACHINE}_$x && [ -z "$(main_slot_cn $x)" ] && { say "wait: 本槽此前已起过 (ledger slotstart), 本槽无主包容器 -> 直接续"; return 0; }
  [ -n "$START_AT" ] && { sa=$(date -d "$START_AT" +%s 2>/dev/null) || { say "wait: START_AT='$START_AT' 无法解析 -> 放弃"; return 1; }; }
  say "wait: 等主槽 ${MACHINE}_$x (WAIT_MAIN=$WAIT_MAIN main_run=$(main_run) START_AT=${START_AT:-无} GO=$OUT/slots/${MACHINE}_$x.GO idle=${WAIT_IDLE_S}s poll=${WAIT_POLL_S}s)"
  LAST_CN_SEEN=$t0   # 开始等待时尚无观测历史 -> 保守地从此刻算起
  while :; do
    [ -n "$(main_slot_cn $x)" ] && LAST_CN_SEEN=$(date +%s)
    halted && { say "wait: HALT -> 放弃本槽"; rec skip - - - - WAIT_HALT - - - - - - - "等待中 HALT"; return 1; }
    awk -v h=$(rem_h) -v m=$MINRUN_H 'BEGIN{exit !(h>=m)}' || { say "wait: 剩余 $(rem_h)h < MINRUN_H -> 放弃本槽"; rec skip - - - - WAIT_GAVE_UP - - - - - - - "等待到剩余不足"; return 1; }
    if [ -z "${sa:-}" ] || [ $(date +%s) -ge $sa ]; then r=$(slot_free_reason $x)
      if [ -n "$r" ]; then sleep ${WAIT_CONFIRM_S:-5}; [ -n "$(main_slot_cn $x)" ] && { say "wait: $r 但复查时本槽出现主包容器 -> 继续等"; continue; }
        ledger_add slotstart ${MACHINE}_$x; echo "$(date '+%F %T %z') reason=$r waited=$(( $(date +%s) - t0 ))s main_run=$(main_run)" >> $OUT/slots/${MACHINE}_${x}_wait.txt
        say "wait: 起跑 reason=$r (等了 $(( $(date +%s) - t0 )) s)"; rec skip - - - - WAIT_START - - - - - - - "reason=$r waited=$(( $(date +%s) - t0 ))s"; return 0; fi; fi
    n=$((n+1)); [ $((n % 10)) = 1 ] && say "wait: 仍在等 (已 $(( $(date +%s) - t0 )) s; 主槽容器: $(main_slot_cn $x | tr '\n' ' ')${sa:+; START_AT 未到})"
    sleep $WAIT_POLL_S; done; }
# ---- 追加包 MPS (X_MPS=auto 默认 | off): 主包 MPS 守护是主包自己的, 本包不连、不 quit、不 kill.
#  主编排仍在 (主 flock 被占) -> 本条不用 MPS (独立 CUDA 上下文, 与主包 MPS 客户端时间片共享 GPU; 风险见 README §5);
#  主编排已退出 且 机上无任何 nvidia-cuda-mps 进程 -> 本包起一次自己的全新 MPSROOT ($HOME/mps_R4N1x/<机>_<TS>; mkdir 原子, 两槽共用, 写 $OUT/slots/x_mps.env);
#  机上仍有 MPS 进程 (主包没收干净 / 别人的) -> 不起, 不 quit, 只记认人报告, 本条不用 MPS. 结束时只对自己起的 pipe 发 quit.
X_MPS=${X_MPS:-auto}
# [R4N2] MPS 修复 (10-30 事故: APPEND_TO 续跑时 $OUT/slots/x_mps.env 还在, 但它指的守护已在上一段收尾 quit 掉 -> 旧代码直接判 own,
#   容器拿到死 pipe, CUDA 静默退回非 MPS, C4 两槽约 4,700 ns/day, 正常约 14,000).
#  x_mps_alive <pipe>: 三条都满足才算活: (1) 有本用户的 nvidia-cuda-mps-control 进程, 其 /proc/<pid>/environ 的 CUDA_MPS_PIPE_DIRECTORY == <pipe>;
#                      (2) <pipe>/control 存在 (socket 或 fifo); (3) echo get_server_list | timeout 10 nvidia-cuda-mps-control 返回 0 (只查询, 不起守护).
#  x_mps_pick: 全程持 $OUT/slots/.x_mps.lock (fd 7, flock -w 120; 两槽串行判, 不再靠 peer 轮询):
#    env 在且守护活 -> own; env 在但守护死 (守护进程还在但 pipe 不通 = 挂死: 先对这个自己的 pipe 发 quit) -> 把 env 改名 x_mps.env.dead_<TS> (不 rm), 写事件日志, 然后按无 env 处理 (重起一次全新 MPSROOT);
#    重起次数超过 X_MPS_MAX_START (默认 3, 含首次与 APPEND_TO 续跑那次) -> none_dead_budget; 起后再验活, 不活 -> 对该 pipe 发 quit, 降级 none_start_fail.
#    每次判定写 $OUT/slots/x_mps_events.log 一行 (时刻 槽 build 结论 pipe).
#  x_mps_stop: 对 env 指的 pipe 发 quit, 再把 x_mps.env 改名 x_mps.env.stopped_<TS> (不 rm), 下一次 APPEND_TO 不会再复用.
X_MPS_MAX_START=${X_MPS_MAX_START:-3}   # 每 OUT 最多起几次 (含首次; APPEND_TO 续跑那次也算)
x_mps_ev(){ echo "$(date '+%F %T %z') ${SLOT_TAG:--} ${XB:--} $*" >> $OUT/slots/x_mps_events.log; }
x_mps_ctl_pids(){ ps -u "$(id -u)" -o pid=,args= 2>/dev/null | awk '$2 ~ /(^|\/)nvidia-cuda-mps-control$/ {print $1}'; }
x_mps_alive(){ local pipe=$1 p e ok=; [ -n "$pipe" ] || return 1
  for p in $(x_mps_ctl_pids); do e=$(tr '\0' '\n' < /proc/$p/environ 2>/dev/null | sed -n 's/^CUDA_MPS_PIPE_DIRECTORY=//p'); [ "$e" = "$pipe" ] && { ok=$p; break; }; done
  [ -n "$ok" ] || { X_MPS_WHY="无 pipe=$pipe 的 control 守护进程"; return 1; }
  [ -S "$pipe/control" ] || [ -p "$pipe/control" ] || { X_MPS_WHY="守护 pid=$ok 在, 但 $pipe/control 不存在"; return 1; }
  echo get_server_list | CUDA_MPS_PIPE_DIRECTORY=$pipe timeout 10 nvidia-cuda-mps-control > /dev/null 2>&1 || { X_MPS_WHY="守护 pid=$ok 在, 但 get_server_list 不通"; return 1; }
  X_MPS_WHY="pid=$ok pipe 可用"; return 0; }
x_mps_pick(){ MPSARGS=; X_MPS_NOTE=none; [ "$MODE" = local ] && [ -z "${X_MPS_TEST:-}" ] && { X_MPS_NOTE=local; return 0; }; [ "$X_MPS" = off ] && { X_MPS_NOTE=off; return 0; }
  exec 7>>$OUT/slots/.x_mps.lock; flock -w 120 7 || { X_MPS_NOTE=none_lock_timeout; x_mps_ev "$X_MPS_NOTE"; exec 7>&-; return 0; }
  _x_mps_pick_locked; x_mps_ev "$X_MPS_NOTE ${X_MPS_WHY:-}"; flock -u 7; exec 7>&-; return 0; }
_x_mps_pick_locked(){ local mr R ts n MPSPIPE= MPSLOG=; X_MPS_WHY=; mr=$(main_run)
  if [ -f $OUT/slots/x_mps.env ]; then . $OUT/slots/x_mps.env
    if x_mps_alive "$MPSPIPE"; then X_MPS_NOTE=own; return 0; fi
    ts=$(date +%m%d_%H%M%S); mv $OUT/slots/x_mps.env $OUT/slots/x_mps.env.dead_$ts
    say "MPS: x_mps.env 指的守护不可用 ($X_MPS_WHY) -> 已改名 x_mps.env.dead_$ts (未删), 尝试重起"; MPSARGS=
    case "$X_MPS_WHY" in 守护*在*) # 本包自己起的守护还在但 pipe 不通 (挂死): 只对这个自己的 pipe 发 quit (认人 = 本 OUT 的 env 指的 pipe; 不 kill)
      echo quit | CUDA_MPS_PIPE_DIRECTORY=$MPSPIPE timeout 20 nvidia-cuda-mps-control > $OUT/slots/x_mps_quit_dead_$ts.txt 2>&1; sleep ${X_MPS_STOP_WAIT_S:-5}
      x_mps_ev "dead_own_quit pipe=$MPSPIPE ($X_MPS_WHY)";; esac; fi
  if [ -n "$mr" ] && ! main_lock_free "$mr"; then X_MPS_NOTE=none_main_running; return 0; fi
  if [ -n "$(ps -eo args= | grep '[n]vidia-cuda-mps')" ]; then ps -eo user=,pid=,etime=,args= | grep '[n]vidia-cuda-mps' > $OUT/slots/x_mps_residue_$(date +%H%M%S).txt; X_MPS_NOTE=none_mps_present; X_MPS_WHY="机上已有 MPS 进程 (不认作本包的; 不 quit/不 kill)"; return 0; fi
  n=$(ls -1 $OUT/ledger/xmps 2>/dev/null | grep -c '^start'); if [ "$n" -ge "$X_MPS_MAX_START" ]; then X_MPS_NOTE=none_dead_budget; X_MPS_WHY="本 OUT 已起过 $n 次 (上限 $X_MPS_MAX_START), 不再起"; say "MPS: 降级 none ($X_MPS_WHY)"; return 0; fi
  ledger_claim xmps start_$((n+1)) || { X_MPS_NOTE=none_claim_race; return 0; }
  R=${X_MPS_ROOT_BASE:-$HOME/mps_R4N2}/${MACHINE}_$(date +%m%d_%H%M%S)_$((n+1))
  if [ -e "$R" ]; then X_MPS_NOTE=none_root_exists; X_MPS_WHY="$R 已存在 (不复用)"; return 0; fi
  if ! { mkdir -p $R/pipe $R/log && CUDA_MPS_PIPE_DIRECTORY=$R/pipe CUDA_MPS_LOG_DIRECTORY=$R/log nvidia-cuda-mps-control -d; }; then X_MPS_NOTE=none_start_fail; X_MPS_WHY="nvidia-cuda-mps-control -d 失败 ($R)"; echo "start fail $R" >> $OUT/slots/x_mps_fail.txt; say "MPS: 降级 none ($X_MPS_WHY)"; return 0; fi
  sleep ${X_MPS_START_WAIT_S:-3}; ps -eo user=,pid=,etime=,args= | grep '[n]vidia-cuda-mps' > $OUT/slots/x_mps_start_$((n+1)).txt
  if ! x_mps_alive $R/pipe; then echo quit | CUDA_MPS_PIPE_DIRECTORY=$R/pipe timeout 20 nvidia-cuda-mps-control > $OUT/slots/x_mps_quit_startfail_$((n+1)).txt 2>&1
    X_MPS_NOTE=none_start_fail; X_MPS_WHY="起后验活不过: $X_MPS_WHY ($R; 已对该 pipe 发 quit)"; echo "start-verify fail $R" >> $OUT/slots/x_mps_fail.txt; say "MPS: 降级 none ($X_MPS_WHY)"; return 0; fi
  printf 'MPSPIPE=%s\nMPSLOG=%s\nMPSARGS="--ipc=host -v %s:%s -v %s:%s -e CUDA_MPS_PIPE_DIRECTORY=%s -e CUDA_MPS_LOG_DIRECTORY=%s"\n' $R/pipe $R/log $R/pipe $R/pipe $R/log $R/log $R/pipe $R/log > $OUT/slots/x_mps.env.tmp && mv $OUT/slots/x_mps.env.tmp $OUT/slots/x_mps.env
  . $OUT/slots/x_mps.env; X_MPS_NOTE=own_started; [ $n -gt 0 ] && X_MPS_NOTE=own_restarted; X_MPS_WHY="$R ($X_MPS_WHY)"; say "MPS: $X_MPS_NOTE $R"; return 0; }
x_mps_stop(){ local ts; ts=$(date +%m%d_%H%M%S); if [ ! -f $OUT/slots/x_mps.env ]; then   # [R4N2-rv1] 无 env (降级/挂死已改名) 也要写收尾残留报告, 供 08:00 GLM 交还核对
    ps -eo user=,pid=,etime=,args= | grep '[n]vidia-cuda-mps' > $OUT/slots/x_mps_after_quit.txt; echo "$(date '+%F %T %z') stop: 无 x_mps.env (未发 quit), 残留报告 x_mps_after_quit.txt" >> $OUT/slots/x_mps_events.log
    [ -s $OUT/slots/x_mps_after_quit.txt ] && echo "[warn] 收尾时机上仍有 MPS 进程 (只报告, 不 kill): $OUT/slots/x_mps_after_quit.txt"; return 0; fi
  ( . $OUT/slots/x_mps.env; echo quit | CUDA_MPS_PIPE_DIRECTORY=$MPSPIPE CUDA_MPS_LOG_DIRECTORY=$MPSLOG timeout 20 nvidia-cuda-mps-control > $OUT/slots/x_mps_quit.txt 2>&1 ); sleep ${X_MPS_STOP_WAIT_S:-5}
  mv $OUT/slots/x_mps.env $OUT/slots/x_mps.env.stopped_$ts; echo "$(date '+%F %T %z') stop: quit 已发, x_mps.env -> x_mps.env.stopped_$ts (未删)" >> $OUT/slots/x_mps_events.log
  ps -eo user=,pid=,etime=,args= | grep '[n]vidia-cuda-mps' > $OUT/slots/x_mps_after_quit.txt; [ -s $OUT/slots/x_mps_after_quit.txt ] && echo "[warn] quit 后仍有 MPS 进程 (只报告, 不 kill): $OUT/slots/x_mps_after_quit.txt"; return 0; }
# ---- [R4N1x] launch_guard 归属识别 (只读: docker ps / /proc/<pid>/cgroup / /proc/<pid>/environ)
gmx_unattributed(){ local ids= p; [ "$WAIT_MAIN" = none ] || ids=$(docker ps --no-trunc --format '{{.ID}} {{.Names}}' 2>/dev/null | awk -v m="^R4N1_${MACHINE}_[0-9]+_" '$2~m{print $1}')   # [R4N2] WAIT_MAIN=none: 不排除任何容器内 gmx
  for p in $(pgrep gmx); do [ -n "$ids" ] && grep -qF "$ids" /proc/$p/cgroup 2>/dev/null && continue; echo "$p:$(ps -o args= -p $p | cut -c1-80)"; done; }
mps_unattributed(){ local p e; for p in $(ps -eo pid=,args= | awk '/[n]vidia-cuda-mps/{print $1}'); do
    e=$(tr '\0' '\n' < /proc/$p/environ 2>/dev/null | grep '^CUDA_MPS_PIPE_DIRECTORY=' | cut -d= -f2-)
    if [ "$WAIT_MAIN" != none ]; then case "$e" in "$HOME"/mps_R4N1/*) continue;; esac; fi;   # [R4N2] WAIT_MAIN=none: 任何 MPS 进程都算残留
    echo "$p:pipe=${e:-?}:$(ps -o user=,etime=,args= -p $p)"; done; }
