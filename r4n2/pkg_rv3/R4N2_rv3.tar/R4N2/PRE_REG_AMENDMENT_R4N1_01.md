# PRE_REG_AMENDMENT_R4N1_01 — PREREG_R4_3day.md 第 1 号修订

- 时间: 2026-10-30 约 12:30 (+0800)。**发车前，零数据**: R4N1 没有任何一条在 Spark 上起跑，没有任何 R4N1 结果被看过。
- 依据: 独立审查 pkg/REVIEW_R4N1.md (PASS-WITH-FIXES) 的 M1；K 10-30 12:14 拍板“取更严读法”。
- 性质: 判据修订只有一处 (下面 1)。2–4 是包的修复，不改判据，一并列出备查。

## 1 判据修订 (M1): 两个起点都 VOID → NOT_EVALUABLE
- 原文矛盾: PREREG §5 原 L99 写“NEITHER：两个起点都 LOST 或 VOID”(按字面，两个都 VOID 也记 NEITHER)；§9 第 7 条 (L155) 写“某体系在某条件下两臂都 VOID 时，相类记 NOT_EVALUABLE 并附说明”。两节对“两臂都 VOID”给出不同结论，自相矛盾。VOID 是起点级作废，不是事件也不是删失，两臂都 VOID 时没有任何可评估的起点，不能下“两相都不保持 (NEITHER)”这一实质结论。
- 取更严读法: 两个起点都 VOID → phase_class = **NOT_EVALUABLE**。一个 VOID、另一个 LOST 仍为 NEITHER (LOST 是可评估的结果)。
- 改动位置:
  - PREREG_R4_3day.md L99 (§5 NEITHER 定义) 与 L3 (状态行)。
  - verdict_R4_3day.py L270: `if hv and lv: return 'NOT_EVALUABLE'`；L276 注释写明单臂 VOID + 另一臂 LOST 仍为 NEITHER。
  - tests/test_verdict.py L89: MC3 两臂都 VOID 的用例改为断言 NOT_EVALUABLE；新增 class PhaseClassAmend01 (L141 起) 2 项: 双 VOID → NOT_EVALUABLE；VOID + LOST → NEITHER。测试共 19 项，全过。
- 影响面: 只影响“两个起点臂都 VOID”的体系。按 R3/D1v2 的历史，这种情形最可能出现在中性 MC3 (起点级无法维持)；修订后它报“不可评估”而非 NEITHER，MC3_note 描述性说明照旧。不影响尺子 (规则 1–3)、Δ 或 F1–F4 的逻辑。
- sha: 修订后的 verdict/PREREG 重新冻结，新 sha 见 FROZEN_sha256.txt (旧 sha verdict 010f45c0…、PREREG eb00fa93… 作废)。

## 2 判据读法的说明 (S7, 不是修订)
- F1 (命门失败) 只在“所有已跑条件、到最长时长，DOPC_hii 的规则 2 都是 FAIL”时触发。只要有一个条件的规则 2 是 NOT_EVALUABLE，F1 不触发，该条件单独报“不可评估”。PREREG §F1“都不满足规则 2”可有两种读法，冻结的 verdict 一直按这一种实现；本条只是写明，代码与判据都不变。

## 3 包修复 (不改判据)
- M2 链排布: 每格 3 主 build 与其 s4 替补同机 (替补账本按机)。tools/make_chains.py plan()；DOPC_h050_T350_hii 无替补写入 README。S1: 内标 MC3/MC3H 放链尾。
- M2 补 (K 10-30 12:24, 发车前零数据): 原排布把 MC3 全放 k03、MC3H 全放 k04，机器与内标 Δ 绑在一起 (两机速度不同 → 链尾截断不对称 → Δ 被机器差异污染)。改为: 同一条件 (C1；C2 含 hii+lam 两臂；C3) 的 MC3H 与 MC3 全在同一台机 (C1→k03，C2→k04，C3 按负载→k03)，替补跟格走；同条件同臂同轮次的 MC3H/MC3 成对、在链尾相邻且严格交替 (A 槽对内 MC3H 先，B 槽 MC3 先)。尺子规则不变 (整格同机、每槽最多 2 条)，分机改为在内标负载之上按格时长贪心均衡。tools/make_chains.py plan() 加 assert 自检 (01b-1 同机、01b-2 链尾交替成对)。
- S2: VARIANT=full 在 2026-10-30 19:30 +0800 之后新启动 → launch_guard FAIL，提示用 reduced (APPEND_TO 续跑豁免)。
- S3: launch_guard 显式查包目录与输出目录在 $HOME 下 (MODE=local 只提示)。
- S5: SEL_KEEP_FRAMES 默认 1，不删帧；逐帧闸门重试不再 rm 旧 json，每次单独存；磁盘门槛 5→10 GiB。
- S6: mdp 与 gatewrap 的过时注释改正，只改注释，非注释内容逐字未变；改后 grompp box 126/126 rc=0、0 warning。
- M3: pkg/SPARK_CHECKLIST.md 补齐 (包外)。
- 未做: S4 (槽内即时替补)。K1 (Lz < 2πr 偏向 RETAIN) 不改包，README §7 写为已知局限。

## 4 不变的
阈值、判定窗、n=3、种子、协议 (relax 15 ns / prod 400 ns)、优先级 C1>C3>C2、F1→B1 的路径，全部不变。没有新种子。
