#!/usr/bin/env python3
"""merge_status_x.py -- 把主包 (R4N1) 与追加包 (R4N1x) 各自 `verdict_R4_3day.py collect` 的 runs_status.tsv 合并到新目录, 供冻结 verdict 一次 judge 全部条件 (C1-C4).
不改冻结 verdict, 不碰任何运行目录, 只读两个 runs_status.tsv, 写 <out>/runs_status.tsv + MERGE_SOURCES.json. series 路径改写成绝对路径并逐条检查存在.
同一 build 两边都出现且两边都不是 NOT_RUN -> 报错退出 (不猜取哪个); 一边 NOT_RUN 另一边有数据 -> 取有数据的一边并记 note.
用法: python3 merge_status_x.py <主包 collect 输出> <追加包 collect 输出> --out <合并目录>
然后: python3 verdict_R4_3day.py judge <合并目录> --d1v2-lam <...runs.tsv> --horizons 400,max"""
import argparse, csv, hashlib, json, os, sys
ap = argparse.ArgumentParser(); ap.add_argument('srcs', nargs='+'); ap.add_argument('--out', required=True); a = ap.parse_args()
def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
cols = None; got = {}; src = []
for d in a.srcs:
    p = os.path.join(d, 'runs_status.tsv'); src.append(dict(path=os.path.abspath(p), sha256=sha(p)))
    with open(p) as f:
        r = csv.DictReader(f, delimiter='\t'); c = r.fieldnames
        if cols is None: cols = c
        elif c != cols: sys.exit('列不一致: %s' % p)
        for row in r:
            s = row.get('series', '-')
            if s not in ('-', ''):
                cand = [s] if os.path.isabs(s) else [os.path.abspath(s), os.path.join(os.path.dirname(os.path.abspath(d)), s), os.path.join(os.path.abspath(d), 'series', os.path.basename(s))]
                hit = [x for x in cand if os.path.isfile(x)]
                if not hit: sys.exit('series 不存在: %s (%s)' % (s, p))
                row['series'] = os.path.abspath(hit[0])
            b = row['build']
            if b in got:
                o = got[b]
                if o['start'] != 'NOT_RUN' and row['start'] != 'NOT_RUN': sys.exit('build 两边都有数据, 拒绝合并: %s' % b)
                if o['start'] == 'NOT_RUN': got[b] = dict(row, note=(row.get('note', '-') + ';merge:other_NOT_RUN'))
                continue
            got[b] = row
os.makedirs(a.out, exist_ok=True); q = os.path.join(a.out, 'runs_status.tsv')
if os.path.exists(q): sys.exit('输出已存在, 不覆盖: %s' % q)
with open(q, 'w') as f:
    f.write('\t'.join(cols) + '\n')
    for b in sorted(got): f.write('\t'.join(got[b].get(c, '-') or '-' for c in cols) + '\n')
json.dump(dict(sources=src, n_builds=len(got)), open(os.path.join(a.out, 'MERGE_SOURCES.json'), 'w'), indent=1)
print('wrote', q, len(got), 'builds')
