#!/usr/bin/env python3
"""R4N1 读数库 (PREREG_R4_3day.md §3, 冻结). 只读. 与 t0_gate.py 同一极性选择/截断/尾珠正则.
  ncl/wind : 尾珠 (^[CD][0-9][AB]$) 连通分量数 / 最大分量 winding 秩, 截断 0.75 (v2 = topo_v2 完整盒矩阵; v1 = stalk_topology_analyzer 正交盒, 作一致性核对)
  npol/wpol: 极性珠 (name NH3 NC3 PO4 GL0 GL1 GL2 CNO or resname W CL NA) 分量数 / 最大分量 winding 秩, 截断 0.8
  n_tube   : 同一极性图里, winding 秩==1 且卷绕方向 (晶格整数向量 @ H) 与 z 夹角 <30° 的分量个数 (所有分量; 无大小门槛 ——
             沿 z 卷绕的分量至少要 ceil(h_z/0.8) 个珠, 小于此的分量不可能计入, 只作计算捷径, 不改定义)
  Cx/Cy/Cz : 头珠 (DOPE/DOPC: PO4; MC3/MC3H: GLA, 同 D1v2 verdict) 沿各轴 0.25 nm bin 直方图 std/mean (同 stalk_topology_analyzer 的 Cz 算法); C_max = max
"""
import math, os, re, sys
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import topo_v2 as T
T.CS_ANALYZER = os.path.join(HERE, 'stalk_topology_analyzer.py')
CS = T.load_cs_analyzer()
TAIL_RX = re.compile(r'^[CD][0-9][AB]$'); POLAR_SEL = 'name NH3 NC3 PO4 GL0 GL1 GL2 CNO or resname W CL NA'
TAIL_CUT = 0.75; POLAR_CUT = 0.8; TUBE_ANG = 30.0
HEAD = {'DOPE': 'PO4', 'DOPC': 'PO4', 'MC3': 'GLA', 'MC3H': 'GLA'}

def n_tube(pos_nm, H, cutoff=POLAR_CUT, ang=TUBE_ANG):
    n = len(pos_nm); ei, ej, ek = T.point_edges(pos_nm, H, cutoff)
    if len(ei) == 0: return 0, []
    ncl, lab = connected_components(coo_matrix((np.ones(len(ei)), (ei, ej)), shape=(n, n)), directed=False)
    sizes = np.bincount(lab); hz = T.perp_heights(H)[2]; nmin = int(math.ceil(hz / cutoff))
    tubes = []
    for c in np.where(sizes >= nmin)[0]:
        root = int(np.where(lab == c)[0][0]); m = lab[ei] == c
        size, rank, key = T.component_winding(n, ei[m], ej[m], ek[m], root)
        if rank != 1: continue
        v = np.asarray(key, float) @ H; th = math.degrees(math.acos(min(1.0, abs(v[2]) / np.linalg.norm(v))))
        if th < ang: tubes.append(dict(size=int(size), dir=list(key), angle_deg=round(th, 2)))
    return len(tubes), tubes

def contrast(pos_nm, box):
    C = []
    for ax in range(3):
        h, _ = np.histogram(np.mod(pos_nm[:, ax], box[ax]), bins=int(round(box[ax] / 0.25)), range=(0, box[ax]))
        C.append(float(h.std() / max(h.mean(), 1e-9)))
    return C

class Reader:
    def __init__(s, u):
        s.u = u; s.tails = u.atoms[[i for i, nm in enumerate(u.atoms.names) if TAIL_RX.match(nm)]]; s.polar = u.select_atoms(POLAR_SEL)
        lip = [r.resname for r in u.residues if r.resname in HEAD]; s.prim = max(set(lip), key=lip.count)
        s.head = u.select_atoms('name %s and resname %s' % (HEAD[s.prim], s.prim))
    def frame(s, ts, v1=True):
        H = T.box_matrix_from_dims(ts.dimensions); box = ts.dimensions[:3] / 10.0
        tp = s.tails.positions / 10.0; pp = s.polar.positions / 10.0
        ncl, _, wind = T.topology_v2(tp, H, TAIL_CUT); npol, _, wpol = T.topology_v2(pp, H, POLAR_CUT); nt, tubes = n_tube(pp, H)
        C = contrast(s.head.positions / 10.0, box)
        r = dict(t_ns=float(ts.time) / 1000.0, Lx=float(box[0]), Ly=float(box[1]), Lz=float(box[2]), ncl=int(ncl), wind=int(wind), npol=int(npol), wpol=int(wpol),
                 n_tube=int(nt), Cx=C[0], Cy=C[1], Cz=C[2], C_max=max(C), tubes=tubes)
        if v1:
            o = CS.tail_topology(tp, box, TAIL_CUT); p = CS.tail_topology(pp, box, POLAR_CUT)
            r['v1'] = [int(o[0]), int(o[2]), int(p[0]), int(p[2])]; r['v1_agree'] = r['v1'] == [r['ncl'], r['wind'], r['npol'], r['wpol']]
        return r

def frame_class(r):
    """PREREG §3 H_II 臂逐帧分类"""
    if r['wpol'] == 1 and r['n_tube'] >= 1: return 'HII'
    return {2: 'LAM', 3: 'NET', 0: 'DISC'}.get(r['wpol'], 'OTHER')   # wpol==1 且 n_tube==0 -> OTHER (prereg 未单列, 计为非 HII)
