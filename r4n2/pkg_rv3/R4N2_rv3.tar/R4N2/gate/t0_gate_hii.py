#!/usr/bin/env python3
"""R4N1 H_II 臂起点门 (PREREG_R4_3day.md §4, 冻结).
  --level builder (L1): 该帧 wpol==1、n_tube==4、ncl==1、wind==3 (截断 tail 0.75 / polar 0.8), 且 v1(正交盒旧读出器) 与 v2 读数一致, 且组成数对;
  --level relax   (L2): 该帧 wpol==1 且 n_tube==4, 且 Lx/Ly/Lz 相对 builder 盒 (--box0, 取 expect.env BOX0) 变化都 <=30%.
用法: t0_gate_hii.py FRAME.gro [TRAJ.xtc] [--frame k] --level builder|relax [--box0 Lx,Ly,Lz] [--expect-lipids N --expect-w N] [--json out.json]
退出码: 0=PASS, 3=VOID (L1 -> VOID_BUILD, L2 -> 该帧不合格), 2=用法错误"""
import argparse, json, os, sys
import MDAnalysis as mda
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import hii_readout as R
ap = argparse.ArgumentParser(); ap.add_argument('gro'); ap.add_argument('xtc', nargs='?'); ap.add_argument('--frame', type=int, default=0)
ap.add_argument('--level', required=True, choices=['builder', 'relax']); ap.add_argument('--box0'); ap.add_argument('--json')
ap.add_argument('--expect-lipids', type=int); ap.add_argument('--expect-w', type=int); a = ap.parse_args()
u = mda.Universe(a.gro, a.xtc) if a.xtc else mda.Universe(a.gro); ts = u.trajectory[a.frame]; rd = R.Reader(u); r = rd.frame(ts)
comp = dict(n_lipid_res=int(sum(1 for x in u.residues if x.resname in R.HEAD)), n_W=int(sum(1 for x in u.residues if x.resname == 'W')))
comp_ok = (a.expect_lipids is None or comp['n_lipid_res'] == a.expect_lipids) and (a.expect_w is None or comp['n_W'] == a.expect_w)
if a.level == 'builder':
    ok = comp_ok and r['wpol'] == 1 and r['n_tube'] == 4 and r['ncl'] == 1 and r['wind'] == 3 and r['v1_agree']; why = 'L1: wpol==1 n_tube==4 ncl==1 wind==3 v1==v2 comp'
    box_dev = None
else:
    if not a.box0: sys.exit(2)
    b0 = [float(x) for x in a.box0.split(',')]; box_dev = [abs(x / y - 1) for x, y in zip((r['Lx'], r['Ly'], r['Lz']), b0)]
    ok = comp_ok and r['wpol'] == 1 and r['n_tube'] == 4 and max(box_dev) <= 0.30; why = 'L2: wpol==1 n_tube==4 |dL/L0|<=0.30 comp'
out = dict(file=a.gro, xtc=a.xtc, frame=a.frame, level=a.level, readings=r, frame_class=R.frame_class(r), box_dev=box_dev, composition=comp, composition_ok=comp_ok,
           gate=why, verdict='PASS' if ok else ('VOID_BUILD' if a.level == 'builder' else 'FAIL_FRAME'))
print(json.dumps(out, ensure_ascii=False))
if a.json: json.dump(out, open(a.json, 'w'), indent=1)
sys.exit(0 if ok else 3)
