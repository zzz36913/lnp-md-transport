#!/usr/bin/env python3
"""R4N1 逐帧读数序列 (两臂通用; PREREG §3). 用法: series_R4N1.py TOP.gro TRAJ.xtc [TRAJ2.xtc ...] --out series.csv [--every 1] [--no-v1]
列: t_ns Lx Ly Lz ncl wind npol wpol n_tube Cx Cy Cz C_max cls tube_sizes (v1_agree 若开 v1). 只读.
多个 xtc (续跑 -noappend 的 part 文件) 按给定顺序拼接; 时间不严格递增的帧 (续跑接缝处重复帧) 跳过."""
import argparse, os, sys, warnings
warnings.filterwarnings('ignore')
import MDAnalysis as mda
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import hii_readout as R
ap = argparse.ArgumentParser(); ap.add_argument('top'); ap.add_argument('xtc', nargs='+'); ap.add_argument('--out', required=True); ap.add_argument('--every', type=int, default=1); ap.add_argument('--no-v1', action='store_true'); a = ap.parse_args()
u = mda.Universe(a.top, a.xtc if len(a.xtc) > 1 else a.xtc[0]); rd = R.Reader(u)
cols = ['t_ns', 'Lx', 'Ly', 'Lz', 'ncl', 'wind', 'npol', 'wpol', 'n_tube', 'Cx', 'Cy', 'Cz', 'C_max', 'cls', 'tube_sizes', 'v1_agree']
with open(a.out + '.tmp', 'w') as f:
    f.write(','.join(cols) + '\n')
    tlast = None
    for ts in u.trajectory[::a.every]:
        if tlast is not None and ts.time <= tlast + 1e-6: continue
        tlast = ts.time
        r = rd.frame(ts, v1=not a.no_v1); r['cls'] = R.frame_class(r); r['tube_sizes'] = '/'.join(str(t['size']) for t in r['tubes']); r.setdefault('v1_agree', '')
        f.write(','.join(('%.4f' % r[c]) if isinstance(r[c], float) else str(r[c]) for c in cols) + '\n')
os.replace(a.out + '.tmp', a.out); print('wrote', a.out, rd.prim)
