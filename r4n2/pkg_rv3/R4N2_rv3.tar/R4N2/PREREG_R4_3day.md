# PREREG R4-3day：起点稳定性 + 方法条件扫描（10-30 / 10-31 / 11-01 三晚）

状态：**冻结**（2026-10-30 11:30 SGT 主控拍板；K 已授权 3 天自主扫参）。冻结于建第 1 晚包时（2026-10-30 中午 SGT），在任何 R4-3day 数据产生之前；sha256 记在包内 `FROZEN_sha256.txt`。独立审查 2026-10-30 12:15 SGT 结论 PASS-WITH-FIXES；**修订 01（PRE_REG_AMENDMENT_R4N1_01.md，发车前、零数据）已并入，sha 以修订后为准；改后的包须复核后才跑。** 写于 2026-10-30 上午（SGT）。
本文件取代并吸收原计划中的 `PREREG_R4_D2.md`（D2 起点稳定性）。配套计划：`PLAN_R4_3day.md`。容量脚本：`capacity_R4_3day.py`，输出在 `capacity_R4_3day.out`（全部为估算）。

凡标「估算」的数字都不是实测。凡标「待核」的都需要在建包或审查时核对原始来源。

---

## 0. 问题与判据（不变）

- 问题：在 Martini 3 里，一个体系从片层（LAM）和从反六角（H_II）两个起点出发，各自能否保持？用“哪个起点稳得住”去读相偏好。
- 尺子（K 定）：**DOPE = 阳性尺，DOPC = 阴性尺**。**MC3H（+1，带 Cl⁻）和中性 MC3 = 内标**，读它们落在尺子的哪一边。
- 每个条件格四个体系同跑（K 10-29 规则），每体系 × 每起点 **n=3，不加 n**（K 10-30 11:22）。时长由我们定。
- **ρ 不再作阳性信号。** 只作描述，而且注明：D1v2 中 h100 的 ρ 下降是膜变薄造成的几何效应（VERDICT_R4_D1v2）。

## 1. 已有教训（这份预注册的出发点）

| 来源 | 条件 | 结果 | 对本设计的含义 |
|---|---|---|---|
| R2a（dd/60） | 3 w/l，320 K，c-rescale semiiso，片层 2 µs，H_II 1 µs | 14/14 条轨迹都停在起点拓扑；**DOPC_hii 3/3 保持 H_II**，即读法 A 下的假阳性 | “起点即答案”，迟滞是双向的 |
| R3（R3_verdict） | 3 w/l，320 K，**H_II prod 用 PR 各向异性 τp=12 nstpcouple=3**（已核 prod_out.mdp），1 µs | DOPE_hii 与 DOPC_hii 都是 100% wpol=1，Cz 0.12–0.28，**无差别** | 至少在 3 w/l 下，**semiiso 锁晶格不是 DOPC H_II 不塌的唯一原因**，因为各向异性下也不塌。所以压力耦合轴不进第 1 晚 |
| D1v2（VERDICT_R4_D1v2） | h050/h100，320 K，片层起点 400 ns | 两档都是 FAIL_RULER：DOPE 0/3；所有帧 wpol 都≠1，Cz 最小 0.6365。DOPE h050 s2/s3 出现持续 ncl=1（t_merge 205/330 ns），DOPC 0/3 | 片层起点 400 ns 内锁死；ncl=1 是事后观察到的候选信号 |
| D1v2 | 中性 MC3 片层 | 10/10 VOID_L2（relax 中侧向塌缩） | 中性 MC3 片层起点在本协议下无法维持 |

**本设计尚未测过的变量只剩两个：水合（R2a/R3 都是 3 w/l）和温度（全部是 320 K）。** 它们就是第 1 晚的扫描轴。

## 2. 体系与构建（冻结）

- 力场：Martini 3.0.0，PC_v2/PE_v2；MC3/MC3H 用 `MC3_MC3H.itp`（M3_Ionizable_Lipids commit 9954b0f，sha 797d2cfe）。**不用** R2a 的旧 MC3H.itp（d5a41620）。
- 每体系 960 脂；MC3H 另加 960 个 CL。
- 水合：沿用 D1v2 的水合定义（HYDRATION_R4.md）。nW_full：DOPC 32.5，DOPE 15.1，MC3/MC3H 32.5（DOPC 代理，无实验锚）。W 珠数如下：

| 体系 | h050 | h100 |
|---|---|---|
| DOPC | 3900 | 7800 |
| DOPE | 1812 | 3624 |
| MC3 | 3900 | 7800 |
| MC3H | 3900 | 7800 |

  选 D1v2 档而不是 R2a 的 3 w/l，原因有三：（a）片层臂可以直接接 D1v2 数据；（b）D1v2 的 h050 比 R2a 水多约 5 倍（DOPC 16 w/l），正好检验“缺水把 DOPC H_II 养活了”这一假设；（c）h100 的定义是“每种脂各自的完全水合”，其中 DOPE 的数值就来自 H_II 最大水合，所以对两把尺子是公平的。
- 片层起点：**完全照搬 D1v2 builder**（2 bilayer × 240/叶，APL 0.55）。
- H_II 起点：R2a builder（`gen/mk_R2a.py --prim --arm hii`，`build_lam_rect.py hii`，nx=2 ny=1，4 根管，管轴沿 z，Ly/Lx=0.866），移植到 R4 的 itp/ff/mdp。中性 MC3 用 `tmpl/mol_MC3.gro`。
  - Lz 规则（冻结）：先按几何算出管内水–头基界面的每脂面积 a_w，取 a_w 最接近 0.60 nm² 的 Lz，允许区间 0.50–0.70 nm²；仍过不了 L1 时，该体系记 VOID_BUILD 并上报，不换 builder。实际 Lz 与 a_w 写入 SYSTEM.txt，由审查核对。R2a 的 Lz=12（apl_head 0.314）属于另一种定义，**不沿用**。这是一处与 R2a 的偏差，需列入审查清单。
- 协议（D1v2 原样，只改 ref_t/gen_temp）：EM → relax 15 ns（dt 15 fs，c-rescale semiiso，τp=1，nstpcouple=2）→ L2 起点门 → prod（dt 20 fs，c-rescale semiiso，τp=4，nstpcouple=5），v-rescale 控温。xtc 每 1 ns 一帧，**必须回传 xtc**（D1v2 的教训）。
- 种子：每体系 × 起点 × 条件 3 个主种子 + 1 个替补。替补**只在主种子 VOID 时**顶上，用来凑齐可评估的 n=3，不算加 n。种子号在建包时写入清单。

## 3. 读数（冻结；新描述子已定义）

沿用 R3/R4 的冻结定义：ncl（尾珠连通分量，截断 0.75）、wind、**wpol**（极性网络 winding 秩，截断 0.8；LAM=2，H_II=1，NET=3，0=不连通/液滴）、Cz（0.25 nm bin）。

新增，仅用于 H_II 臂：
- **n_tube**：与 wpol 用同一极性选择和 0.8 nm 截断，统计 winding 秩为 1 且方向平行于起始管轴（z，夹角 <30°）的极性簇数。起点值为 4。
- **C_max**：头基层对比度，按 Cz 的同一算法分别沿 x、y、z 计算，取最大值。它与取向无关，**只用来给 LOST 分子类**，不进主判。
- 不用 R2a 的 d_NN（存在代数恒等缺陷）。

**H_II 臂逐帧分类：**
- HII 帧：wpol==1 且 n_tube≥1
- LAM 帧：wpol==2
- NET 帧：wpol==3
- DISC 帧：wpol==0

**H_II 臂逐条判定**（判定窗 = 该 run 最后 100 ns，1 ns 一帧，共 101 帧；续跑后以最长时长的最后 100 ns 为准）：
- **RETAIN**：HII 帧占比 ≥0.80
- **LOST**：HII 帧占比 ≤0.20。子类按窗内多数帧定：LAM_RETURN（并且要求 C_max≥0.6）、NET、DISC
- **PARTIAL**：介于两者之间。不算 RETAIN 也不算 LOST
- 描述量：t_loss = 第一次“连续 ≥20 ns 非 HII 帧”的起始时刻，5 ns 步长扫描；n_tube 终值（并管）。

**片层臂：**
- 主事件照搬 D1v2：wpol==1 且 Cz≤0.5，持续 ≥20 ns。
- 次级读数（预注册确认用，标明是 D1v2 事后生成的假设）：ncl==1 持续 ≥5 ns。预测 DOPE ≥2/3，DOPC 0/3。

## 4. 起点资格（L1/L2）

- 片层：照搬 D1v2（L1 builder 2/2/2/2 @0.65/0.75/0.95；L2 在 relax 最后 5 ns 逐帧检查，取最后一个合格帧，没有合格帧记 VOID_L2）。
- H_II：
  - L1（builder 帧）：wpol==1、n_tube==4、ncl==1、wind==3。
  - L2（relax 最后 5 ns 逐帧）：wpol==1 且 n_tube==4，并且三个盒长相对 builder 的变化都不超过 30%。最后一个合格帧作为 prod 起点；没有合格帧记 VOID_L2。
  - 30% 这个盒长条件是为了抓住 D1v2 中性 MC3 那类侧向塌缩，在看数据之前定死。
- **起点合格率**：每格 3 主 + 1 替补。替补顶上后可评估 n 仍 <3 时，该体系 × 起点记 NOT_EVALUABLE（n 写明）。尺子体系只要出现 NOT_EVALUABLE，该条件就记 RULER_NOT_EVALUABLE，不算 PASS。
- **中性 MC3 的 H_II 起点也 VOID 时**：记“中性 MC3 在本协议下片层与 H_II 起点都无法维持（起点级）”，作为描述性相行为结果，不进门。内标对比改记 NOT_EVALUABLE。后备选项写在 PLAN §6，由 K 拍板，不自动执行。

## 5. 判定规则（冻结）

每个条件格 c 的尺子门 RULER(c)：
1. **DOPE+（阳性）**：DOPE_hii RETAIN ≥2/3
2. **DOPC−（阴性，命门）**：DOPC_hii RETAIN 0/3，且 LOST ≥2/3（LOST 的任何子类都算“塌了”）
3. **DOPC 片层守恒**：DOPC_lam 主事件 0/3。出现任何一次 → 该条件“驱动过强”，判无效

RULER(c)=PASS 需要 1、2、3 同时成立。DOPE 片层臂不要求发生事件，因为已知片层起点会被动力学锁死；它的结果只作描述，并检验 §3 的次级假设。

**命门说明：** 整个方法的区分力完全压在“DOPC 的 H_II 会塌”这一条上。R2a（3/3）和 R3（3/3）的 DOPC_hii 都没塌。**如果本轮 DOPC_hii 再次保持（RETAIN ≥1/3），该条件尺子失败**，后续按 §7 走，不放宽门槛。

**MC3H vs 中性 MC3（内标）**：只在 RULER(c)=PASS 的条件下判。
- 每个体系给一个相类，由 {lam 起点结局, H_II 起点结局} 组合而来：
  - LAM_PREF：lam 保持，且 H_II LOST ≥2/3
  - HII_PREF：H_II RETAIN ≥2/3，且 lam 有事件 ≥2/3
  - HYST：两个起点都保持
  - NEITHER：两个起点都 LOST，或一个 LOST、另一个 VOID（两个起点都 VOID 时记 NOT_EVALUABLE，见 §9.7；PRE_REG_AMENDMENT_R4N1_01）
  - MIXED：其余情况
- 对比量 Δ = n_RETAIN(MC3_hii) − n_RETAIN(MC3H_hii)
  - Δ≥+2 → SEP_EXPECTED（假设 H4：中性 MC3 更偏非片层）
  - Δ≤−2 → SEP_REVERSE
  - 其余 → NO_SEP
- 两个体系都报相类，并说明它们各自更像 DOPE 还是更像 DOPC。
- 解释上的限制：纯 MC3H 和纯中性 MC3 只是质子化的两个端点，**不等于**内体 pH 下真实的部分质子化状态。

**条件优先级**（多个条件都 PASS 时选主条件，按偏离标准协议的程度由小到大）：C1(320 K h050) > C3(320 K h100) > C2(350 K h050) > C4(350 K h100)。

**时间稳健性：** 某条件 400 ns PASS，但续跑后在更长时长的判定窗里不再满足 1–3 → **撤回该 PASS**，在 verdict 里明文写“撤回”。最终结论只用最长时长。

## 6. N 与功效（估算）

- n=3 时，3 对 0 的 Fisher 单侧 p=0.05，双侧 p=0.10。所以这是工程放行门，不是统计显著性。
- 若 DOPC_hii 的塌陷近似指数过程，平均寿命 τ，单条在时长 T 内塌掉的概率 p=1−e^{−T/τ}，“≥2/3 塌”的概率 P=3p²(1−p)+p³（估算，忽略判定窗）：

| τ | T=400 ns | T=1.2 µs | T=2 µs |
|---|---|---|---|
| 0.3 µs | P≈0.83 | ≈1.0 | ≈1.0 |
| 1 µs | P≈0.26 | ≈0.77 | ≈0.95 |
| 3 µs | P≈0.04 | ≈0.26 | ≈0.48 |

- 0 事件上界（95%，τ > E/ln20，E 为总暴露）：DOPC_hii 3 条都不塌时，400 ns 对应 τ_loss > 0.40 µs，1.2 µs 对应 >1.2 µs，2 µs 对应 >2.0 µs（估算）。
- 结论：**400 ns 只能抓到快塌（τ≲0.5 µs）**。所以第 2–3 晚在主条件上续到 1.2 → 2 µs。

## 7. 证伪与失败分支（冻结）

- **F1（命门失败）**：所有已跑条件、到最长时长，DOPC_hii 都不满足规则 2 → 判“起点稳定性法在 Martini 3、≤2 µs 下对 DOPE/DOPC 无分辨力”。此时不出任何 MC3 相偏好结论；凡以“H_II 起点保持”为证据的 MC3H 解释（含 R2a）一律撤回。
- **F2**：所有条件下 DOPE_hii LOST ≥2/3 → 阳性尺也立不住，方法失败。
- **F3**：某条件 DOPC_lam 出现事件 → 该条件无效（驱动过强），不影响其它条件。
- **F4**：§5 的时间稳健性撤回。
- 第 1 晚全部失败时的分支见 PLAN §6；分支选择依据第 1 晚的失败类型，这里预先写定。共存起点（L/H_II 同盒）是新方法，**需要另立预注册补丁并经 K 批准**，不在本文件授权范围内。

## 8. 不做的事

- 不加 n、不放宽 0.8/0.2/2/3/0/3 等阈值、不事后改判定窗、不用 ρ 作信号。
- 不在本轮扫压力耦合，理由见 §1 R3 行；它保留为后备。
- 温度上限 350 K（理由见 PLAN §2）。不跑 >350 K。
- 结果必须附 3D 图（sim-paper-figures）。

## 9. 11:30 拍板与第 1 晚建包时补定的实现细则（冻结，均在任何 R4-3day 数据之前）

11:30 拍板（逐条写入，不再改）：
- 第 1 晚 = T×水合 2×2 中的 C1/C3/C2（完整版）或 C1/C2（缩减版）；压力耦合不扫；320 K 片层臂复用 D1v2（`D1v2_results_pull/results_xtc_prereg/runs.tsv`，sha 记在 FROZEN_sha256.txt）。19:30（SGT）为完整/缩减分界：19:30 前能发车用完整版，否则缩减版。
- 命门失败（F1）走 B1：350 K 续到 2 µs。共存起点补丁到时另立，不在本文件授权内。
- 严格 n=3，不加新种子；每格只有 1 个起点级替补（s4，只顶 VOID_BUILD / VOID_L2 / RELAX_FAIL / VOID_SEL_MISMATCH）。

建包时补定（PREREG 原文没写死、判读脚本 `verdict_R4_3day.py` 已按此实现并有单元测试）：
1. H_II 臂可评估资格：prod 观测 ≥400 ns 且判定窗（最后 100 ns）帧数 ≥99；否则 TRUNC / WINDOW_INCOMPLETE，记不可评估，**不用替补顶**。
2. 片层臂同 D1v2：有主事件即 EVENT（截断前发生也算）；无事件须观测 ≥400 ns，否则 TRUNC。
3. prod NUMERIC_FAIL / GROMPP_FAIL / 回传 xtc 与 SHA256_out.txt 不符 = 不可评估，不顶。
4. 逐帧分类：HII = wpol==1 且 n_tube≥1；wpol==1 而 n_tube==0 记 OTHER（不算 HII）。
5. 时间以 prod 第一帧为 0；多 attempt（-noappend 续跑）按序拼接；horizon H 只用 t≤H 的帧。
6. H_II 臂起点 L2 闸（`gate/t0_gate_hii.py --level relax`）与片层臂一样，在 relax 末 5 ns 逐帧判，取最后一个合格且带速度的帧作 prod 起点；全不合格 = VOID_L2。
7. 某体系在某条件下两臂都 VOID 时，相类记 NOT_EVALUABLE 并附说明（预计 MC3 片层臂在 C1/C3 为 VOID：D1v2 中 MC3 10/10 VOID_L2）。
