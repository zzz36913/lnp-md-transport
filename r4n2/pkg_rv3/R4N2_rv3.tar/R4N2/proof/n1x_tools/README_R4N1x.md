# R4N1x 追加包 (PRE_REG_AMENDMENT_R4N1_02) — 主包 R4N1 某槽跑完后接着跑

内容: **L 臂 (优先)** 长盒 H_II (h050 T320, DOPE Lz0 38.18 nm / DOPC Lz0 21.93 nm, n=3 + s4 替补) + **C4** (350 K h100, 4 体系 × hii/lam, n=3 + s4, 400 ns, 原 PREREG 判据)。共 40 个 build (L 臂 8 + C4 32)。
主包 (commit 04e94e52, pkg/R4N1_full) **一字不改**；本包解到另一个目录、写另一个输出根 `$HOME/R4N1x`，容器前缀 `R4N1x_`，flock `$HOME/R4N1x/.R4N1x_<机>.flock`，MPS 根 `$HOME/mps_R4N1x`。

## 1 排程 (全部估算: 主包槽长 × 12/9.68; 350 K 与长盒速率未实测)
| 槽 | 主包本槽结束 (估算) | 本包主链 | 本包结束 (估算) | 距 07:30 余量 |
|---|---|---|---|---|
| k03_A | 10-31 02:21 | DOPE_hiiL s1, s3; C4 DOPE_hii s3 | 06:55 | 0.57 h |
| k03_B | 02:30 | DOPE_hiiL s2; C4 DOPE_hii s1, s2 | 06:13 | 1.27 h |
| k04_A | 02:20 | DOPC_hiiL s2; C4 DOPC_hii s1, s2 | 06:14 | 1.26 h |
| k04_B | 02:15 | DOPC_hiiL s1, s3; C4 DOPC_hii s3 | 06:57 | 0.55 h |
- supp (按 K 12:42 裁剪序被裁的, 槽有余量且 supp_fits 放得下才跑, 否则记 SUPP_SKIP_NO_TIME -> 第 2 晚): k03 = C4 DOPC_lam s1–3；k04 = C4 DOPE_lam s1–3，然后内标 MC3H/MC3 hii s1–3、lam s1–3 (成对交替)。
- 替补 (只顶本机同格 VOID 主种子): k03 = DOPE_hiiL / C4 DOPE_hii / C4 DOPC_lam 的 s4；k04 = DOPC_hiiL / C4 DOPC_hii / C4 DOPE_lam / 4 个内标格的 s4。
- f=1.0 情景 (不乘 1.24, 主包按原估 9.5–9.7 h 结束): 补跑能放下 DOPC_lam ×3、DOPE_lam ×3、内标 hii s1–s2。×1.24 情景下 supp 一条也放不下。
- 每格 3 主与替补同机；同条件同臂 MC3H/MC3 同机 (k04)、相邻交替。DEADLINE 2026-10-31 07:30 +0800；没跑完的记 TRUNC，第 2 晚 APPEND_TO 续。

## 2 流水线
同主包 (README_R4N1.md §2): em1 → em2 → relax (trr, 末段逐帧闸门取起点) → 闸门 L2 → prod 400 ns → SHA256_out。hiiL 的 mdp、闸门、L2 判据与 hii 逐字相同 (arm_of: hiiL → hii)。

## 3 何时起跑 (等待启动器) 与主包 done 标记
- 主包的 done 标记只有日志行 (主包 RUN_META.txt 只在开头写一次，无 done 字段):
  - 槽 done: `$HOME/R4N1/R4N1_run_<机>_<TS>/slots/<机>_<A|B>.log` 里出现 `== slot end`
  - 机 done: 同目录 `orchestrator.log` 里出现 `== machine <机> done`
- 每槽独立等待，“槽空”任一即起 (lib_R4N1x.sh wait_slot):
  1. MAIN_DONE: 上面两行之一；只认**最后一个**标记 (槽日志最后一个 `== slot start/end` 是 end；或 orchestrator.log 最后一个 `OUT=` 之后有 machine done)，防主包 APPEND_TO 续跑后旧 done 标记误放行 (审查 v3)
  2. MAIN_GONE: 主 run 目录在，且主包 flock 可拿 (= 主编排已退出，例如被 HALT 或崩)
  3. MAIN_IDLE: 本槽无主包容器，且主槽日志 ≥ WAIT_IDLE_S (默认 1200 s) 未更新 (防把闸门 python 空档当成完)
  4. GO: 调度手动放 `$OUT/slots/<机>_<槽>.GO`，要求 GO 文件已放 ≥ GO_QUIET_S (120 s) 且本槽连续 ≥ GO_QUIET_S 没观测到主包容器（按 WAIT_POLL_S 轮询，从开始等待起算；轮询间隙里一闪而过的容器看不到）
  5. WAIT_MAIN=none: 不看主包日志
- 硬条件 (不可绕过): 起跑时本槽没有主包容器 `^R4N1_<机>_<pid>_<机>_<槽>_`；判定后再隔 5 s 复查一次。
- START_AT 只是下限 (此前不起，到点后仍按上面判)。
- **审查 v3 建议今晚只用 MAIN_DONE (+ 主包崩时的 MAIN_GONE)**: 设 `WAIT_IDLE_S=86400` 关掉 MAIN_IDLE，不放 GO，不用 WAIT_MAIN=none。原因: 主包闸门容器不带名字 (gate_py_container.sh 用随机名)，主槽在“relax→闸门→prod”之间可能有几分钟没有带名容器，GO 的 120 s 静默与 MAIN_IDLE 都可能在这个空档放行，随后主包起 prod，同槽同 pin 双开；硬条件挡不住这个空档。
- 即使只用 MAIN_DONE，主包另一槽通常还在跑 (MPS)，本包这条不用 MPS，与之分时片共卡，直到主包整机结束 (估算 10–15 min)。
- 等待中剩余 < MINRUN_H → 放弃本槽 (rec WAIT_GAVE_UP)；`$OUT/HALT` → 放弃 (只认本包的 HALT，不认主包的)。
- 幂等: 已起过的槽记在账本 slotstart；APPEND_TO 续跑时本槽无主包容器即直接续，不再等。
- 每次起跑写 `$OUT/slots/<机>_<槽>_wait.txt` (reason, 等了多久)。

### 用法
```
# 正式 (两机各一条, 主包发车后任何时刻都可以先起, 过 launch_guard 后挂起等待):
cd <解包目录>/R4N1x && nohup bash run_R4N1x.sh k03 > ~/R4N1x/launch_k03.out 2>&1 &
# 只跑一部分 (分段闭环):
ONLY="Larm" bash run_R4N1x.sh k04
ONLY="DOPC_h050_T320_hiiL,C4hii" bash run_R4N1x.sh k04
ONLY_FILE=~/R4N1x/only_seg2.txt APPEND_TO=~/R4N1x/R4N1x_run_k04_<TS> bash run_R4N1x.sh k04   # 第 2 段, 续同一套账本
#   tok = build 名 | 格名 (体系_水合_温度_臂) | 组名 Larm / C4 / C4hii / C4lam / C4ruler (C4 的 DOPE+DOPC) / C4IS (C4 的 MC3H+MC3)
#   不在 ONLY 里的条目记 SKIP_NOT_ONLY, 不占账本, 以后换 ONLY 可再跑; 替补跟着本次跑过的 VOID 主种子走.
# 调度在某时间点手动接入:
START_AT="2026-10-31 01:00 +0800" bash run_R4N1x.sh k03
touch ~/R4N1x/R4N1x_run_k03_<TS>/slots/k03_A.GO     # 立刻接入 k03_A (仍要求 120 s 内该槽无主包容器)
# 主包 run 目录不唯一时:
WAIT_MAIN=~/R4N1/R4N1_run_k03_<TS> bash run_R4N1x.sh k03
CHECK=1 bash run_R4N1x.sh k03     # 只跑 launch_guard
DRY=1   bash run_R4N1x.sh k03     # 打印排程/等待/ONLY, 不跑
```

## 4 launch_guard 改动 (认出并排除，不是放宽)
主包在跑时机上必然有它的 gmx、容器、MPS 守护。主包 guard 把这些一律判 FAIL；本包改为:
- gmx 进程: 查 /proc/<pid>/cgroup，属于主包 `^R4N1_<本机>_<数字>_` 容器的排除；**剩下任何 gmx → FAIL**；60 s 后复查一次。
- 脚本进程: R2a/R2b/prerun/R3/R4/另一个 run_R4N1x → FAIL；主包 run_R4N1.sh 只作 info。
- 容器: R2a_/R2b_/R3*/R4_/R4N1x_/j009_ 容器、以及不是本机编号的 R4N1_ 容器 → FAIL。
- MPS: 查 /proc/<pid>/environ 的 CUDA_MPS_PIPE_DIRECTORY，在 `$HOME/mps_R4N1/` 下的认作主包的、排除；**其余 MPS 进程 → FAIL** (先认人再 quit: tools/mps_residue.sh；不 kill)。
- 新增 FAIL: ONLY 里有本机没有的 tok；START_AT 解析不了；WAIT_MAIN=auto 但主 run 目录不是恰好 1 个。
- 其余检查 (MANIFEST、$HOME、gmx 版本、闸门正负自检、trjconv、两槽 grompp、磁盘 ≥ 10 GiB) 与主包相同。
- VARIANT=append：主包的 19:30 full 分界 (FULL_CUTOFF) 只对 VARIANT=full，不适用于本包。

### 本包的 MPS (X_MPS=auto 默认 | off)
- 主编排仍在 (主 flock 被占) → 本包这条 build 不用 MPS (独立 CUDA 上下文，与主包 MPS 客户端按时间片共享 GPU)。
- 主编排已退出，且机上没有任何 MPS 进程 → 本包起一次自己的全新 `$HOME/mps_R4N1x/<机>_<TS>` (两槽共用，写 `$OUT/slots/x_mps.env`)。
- 机上还有 MPS 进程 (主包没收干净 / 别人的) → 不起、不 quit、不 kill，记认人文件 `$OUT/slots/x_mps_residue_*.txt`，本条不用 MPS。
- 收尾只对自己的 pipe 发 quit；quit 后仍有进程只报告。

## 5 风险 (须 K 知情)
1. **与主包共卡**: 正常情况下本包只在主包本槽结束后起；但 MAIN_IDLE/GO/START_AT 接入时，主包另一槽可能仍在跑 MPS，本包这条不用 MPS → 同卡两种上下文时间片，两边速率都可能低于估算 (估算未计)。若 GPU 被设成 EXCLUSIVE_PROCESS 计算模式，非 MPS 客户端会起不来 (主包未设，未在 Spark 实测)。
2. **DOPC 长盒 Lz0 21.93 nm < 22 nm** (0.3%)；比值 Lz0/(2π r_water0) = 1.90，长于一个 Rayleigh–Plateau 波长。DOPE 长盒 38 nm (6.4 个波长) 主要作长盒阳性对照，体系 2× 珠数，速率估算偏乐观的风险最大。
3. **C4 今晚多半判不出**: C4 lam (规则 3 要 DOPC_lam) 和内标全在 supp；×1.24 情景下一条也放不下 → C4 记 RULER_NOT_EVALUABLE，第 2 晚续。
4. **350 K / 长盒速率是估算** (D1v2 表 + 珠数线性缩放)。槽余量只有 0.55–1.27 h。
5. **主包替补会拉长主槽** (VOID 越多, 主槽越晚结束, 本包起得越晚; 最坏 L 臂第 2 条也可能 TRUNC)。
6. **flock 试探的小竞态**: 若主包在本包试探锁的同一瞬间重启，试探可能误判一次 MAIN_GONE；硬条件 (本槽无主包容器 + 5 s 复查) 仍挡住同槽双开。
7. **反向**: 本包在跑时，主包若在同机 APPEND_TO 重启，主包 guard 会因看到 R4N1x_ 容器/gmx 而 FAIL (这是保护，不是故障)。
8. 未在 Spark/gmx 2026.3/docker 上实测: cgroup 识别 (docker cgroup v2 路径含完整容器 ID)、/proc environ 可读、docker ps 名字格式。box 上只验了 MODE=local。

## 6 判读
```
# C4: 冻结 verdict 原样 (collect 按冻结 NAME 自动跳过 hiiL)
python3 verdict_R4_3day.py collect <R4N1x_run_k03_*> <R4N1x_run_k04_*> --inputs inputs --out OUTX
# 与主包合出 C1–C4 总判 (不改冻结 verdict):
python3 merge_status_x.py <主包 collect 输出 OUT> OUTX --out OUTALL
python3 verdict_R4_3day.py judge OUTALL --d1v2-lam inputs/D1v2_lam_runs.tsv --horizons 400,max
# L 臂 (AMENDMENT_02 §3):
python3 verdict_Larm.py collect <R4N1x_run_k03_*> <R4N1x_run_k04_*> --inputs inputs --out OUTL
python3 verdict_Larm.py judge OUTL --short-status <主包 collect 输出 OUT>/runs_status.tsv --short-inputs <主包>/inputs
```
- 预写读法: 长盒 DOPC LOST ≥ 2/3 而短盒没有 → SHORT_BOX_ARTIFACT → 短盒 (Lz0 < 2π r_water0) H_II 臂 RETAIN 降级；不改任何 RULER、不 FAIL→PASS。
- 21:00 前后中途回传: 包外 `D2/interim_pull.sh` (只读运行目录，只打包已 DONE 的 prod)。

## 7 文件
- run_R4N1x.sh / lib_R4N1x.sh: 由主包逐字复制，只改 [R4N1x] 标记处 (`diff lib_R4N1.sh lib_R4N1x.sh` 可看全部改动；主包两文件也放在 tools/ref_main/ 供对照)。
- verdict_Larm.py、merge_status_x.py、tests/test_verdict_Larm.py (11 项) + tests/test_verdict.py (原 19 项)。
- chains/ 由 tools/make_chains_x.py 生成 (含 PLAN_ESTIMATE.json)；inputs/ 由 tools/build_R4N1x.py + build_all_x.sh 生成，L1 40/40 PASS；proof/grompp_box.tsv 80/80 rc=0、0 warning。
- FROZEN_sha256.txt: verdict_R4_3day.py、PREREG_R4_3day.md、AMENDMENT_01、AMENDMENT_02、D1v2_lam_runs.tsv。
