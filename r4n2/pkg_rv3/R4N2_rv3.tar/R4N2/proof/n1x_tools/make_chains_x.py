#!/usr/bin/env python3
"""R4N1x 追加包链生成 (PRE_REG_AMENDMENT_R4N1_02; K 12:42). 规则在看任何 R4N1 数据之前定死:
 - 槽容量 (估算): 主包 R4N1 完整版 (commit 04e94e52) 14:30 发车, 各槽主链负载取 N1/chains_full/PLAN_ESTIMATE.json (f=1.0) 再乘
   SCALE = 12/9.68 (K: 最长槽约 12 h -> 约 02:30 结束); 主槽预计结束 = MAIN_START + load*SCALE; 追加容量 = DEADLINE - 主槽结束 - TAIL_H.
   追加包每条时长同一公式 (make_chains.py need(): 15/(0.65P)*24+0.05+400/P*24 h) 再乘 SCALE; P 按珠数缩放 (hiiL 珠数约 2 倍 -> P 约减半).
 - 优先级 (K 12:42): L 臂 > C4. L 臂两格 (DOPE_h050_T320_hiiL -> k03, DOPC_h050_T320_hiiL -> k04; 与各自短盒 C1 尺子格同机) 必须 3 主种子全进主链.
 - C4 格顺序 (裁剪序的反序): DOPC_hii, DOPE_hii (规则 1/2), DOPC_lam (规则 3 必需), DOPE_lam (描述), 内标 MC3H/MC3 hii, 内标 lam.
   裁剪: 某格第一次有 build 放不下 -> 该 build 与之后所有格 (含更低优先级的全部格) 进 supp 队列 (按同一顺序), 不让低优先级格插空 (严格遵守 "先砍内标, 再砍 lam 臂");
   被裁的整格按 (剩余容量 - 已排 supp 负载) 大者选机, 使两机都有可接的 supp (主包若比估算快, 哪台先空哪台接).
 - 整格同机: 一格 3 主种子 + s4 替补同一台机 (chains 或 supp 均在该机); 内标 4 格 (MC3H/MC3 x hii/lam) 同一台机, 成对 (同臂同种子) 相邻, 严格交替.
 - 输出 chains/<机>_<A|B>.txt, spares_<机>.txt, supp_<机>.txt, PLAN_ESTIMATE.json (各槽预计结束, 估算). 自检 assert 见文末."""
import json, os, re, sys, datetime as dt
D = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); INP = D + '/inputs'; OUT = D + '/chains'
TZ = dt.timezone(dt.timedelta(hours=8))
MAIN_START = dt.datetime(2026, 10, 30, 14, 30, tzinfo=TZ); DEADLINE = dt.datetime(2026, 10, 31, 7, 30, tzinfo=TZ); TAIL_H = 0.25; SUPP_MARGIN_H = 0.75
MAIN_LOAD = {'k03_A': 9.56, 'k03_B': 9.68, 'k04_A': 9.55, 'k04_B': 9.49}   # N1/chains_full/PLAN_ESTIMATE.json slot_h (f=1.0, 估算)
SCALE = 12 / 9.68
L1 = {l.split('\t')[0]: l.split('\t')[2] for l in open(INP + '/L1_summary.tsv').read().splitlines()[1:]}
def beads(b): return int(re.search(r'beads=(\d+)', open('%s/%s/SYSTEM.txt' % (INP, b)).read()).group(1))
R = {('DOPE','h050'):14428,('DOPC','h050'):14258,('MC3H','h050'):13398,('MC3','h050'):13398,
     ('DOPE','h100'):13998,('DOPC','h100'):12927,('MC3H','h100'):12282,('MC3','h100'):12282}
REFB = {('DOPE','h050'):13332,('DOPC','h050'):15420}   # 短盒 h050 hii 珠数 (R 表对应的珠数); h100 C4 与 C3 同组成同珠数, 不缩放
def perf(b):
    _, s, h, T, arm = b.split('_')[:5]; P = R[(s, h)]
    if arm == 'hiiL': P = P * REFB[(s, h)] / beads(b)
    return P
def need(b, scale=1.0):
    P = perf(b); return (15 / (0.65 * P) * 24 + 0.05 + 400 / P * 24) * scale
nm = lambda s, h, T, a, k: 'R4N1_%s_%s_%s_%s_s%d' % (s, h, T, a, k)
for b in L1: assert L1[b] == 'PASS', b
LCELLS = [('DOPE', 'h050', 'T320', 'hiiL', 'k03'), ('DOPC', 'h050', 'T320', 'hiiL', 'k04')]
C4 = [('DOPC', 'hii'), ('DOPE', 'hii'), ('DOPC', 'lam'), ('DOPE', 'lam')]
C4IS = [('hii'), ('lam')]
def plan(scale):
    end_main = {x: MAIN_START + dt.timedelta(hours=MAIN_LOAD[x] * scale) for x in MAIN_LOAD}
    cap = {x: (DEADLINE - end_main[x]).total_seconds() / 3600 - TAIL_H for x in MAIN_LOAD}
    chain = {x: [] for x in MAIN_LOAD}; spares = {'k03': [], 'k04': []}; supp = {'k03': [], 'k04': []}
    left = dict(cap)
    def put(b, m):
        x = max(('%s_A' % m, '%s_B' % m), key=lambda y: (left[y], y[-1] == 'A'))
        if need(b, scale) <= left[x] + 1e-9: chain[x].append(b); left[x] -= need(b, scale); return True
        return False
    # 1 L 臂: 必须全进
    for s, h, T, a, m in LCELLS:
        for k in (1, 2, 3):
            b = nm(s, h, T, a, k); assert put(b, m), 'L 臂放不下: %s (违反 K: L 臂 n=3 必须保全)' % b
        spares[m].append(nm(s, h, T, a, 4))
    # 2 C4 尺子格: 格整体选机 (剩余容量大的机), 一旦有放不下 -> 之后全进 supp
    trimmed = False; cellmach = {}; sload = {'k03': 0.0, 'k04': 0.0}
    def pick(cb):   # 未裁: 剩余容量大的机; 已裁 (整格进 supp): 剩余容量 - 已排 supp 负载 大的机 (两机都给 supp 机会, 见 scenario_f1.0)
        return max(('k03', 'k04'), key=lambda mm: (left[mm + '_A'] + left[mm + '_B'] - sload[mm], mm == 'k03'))
    for s, a in C4:
        m = pick(None); cellmach[(s, a)] = m
        for k in (1, 2, 3):
            b = nm(s, 'h100', 'T350', a, k)
            if trimmed or not put(b, m): trimmed = True; supp[m].append(b); sload[m] += need(b, scale)
        spares[m].append(nm(s, 'h100', 'T350', a, 4))
    # 3 C4 内标: 4 格同一机 (剩余大者), 成对交替 MC3H, MC3 (同臂同种子)
    mi = pick(None)
    for a in C4IS:
        for k in (1, 2, 3):
            for s in ('MC3H', 'MC3'):
                b = nm(s, 'h100', 'T350', a, k)
                if trimmed or not put(b, mi): trimmed = True; supp[mi].append(b); sload[mi] += need(b, scale)
        for s in ('MC3H', 'MC3'): spares[mi].append(nm(s, 'h100', 'T350', a, 4))
    return dict(end_main=end_main, cap=cap, chain=chain, spares=spares, supp=supp, left=left, cellmach=cellmach, is_mach=mi)
P = plan(SCALE)
# ---- 自检
allb = [b for v in P['chain'].values() for b in v] + [b for v in P['spares'].values() for b in v] + [b for v in P['supp'].values() for b in v]
assert len(allb) == len(set(allb)) == 40 == len(L1), (len(allb), len(set(allb)))
mach_of = {b: x[:3] for x, v in P['chain'].items() for b in v}; mach_of.update({b: m for m, v in P['spares'].items() for b in v}); mach_of.update({b: m for m, v in P['supp'].items() for b in v})
cell = lambda b: re.sub(r'^R4N1_|_s\d+$', '', b)
for c in {cell(b) for b in allb}: assert len({mach_of[b] for b in allb if cell(b) == c}) == 1, '格跨机: ' + c
assert len({mach_of[b] for b in allb if b.split('_')[1] in ('MC3H', 'MC3')}) == 1, '内标跨机'
for c in ('DOPE_h050_T320_hiiL', 'DOPC_h050_T320_hiiL'): assert sum(1 for x in P['chain'].values() for b in x if cell(b) == c) == 3, 'L 臂主链不满 3: ' + c
for m in ('k03', 'k04'):   # 内标交替 (chain 尾 + supp 合起来按顺序)
    seq = [b for b in P['chain'][m + '_A'] + P['chain'][m + '_B'] + P['supp'][m] if b.split('_')[1] in ('MC3H', 'MC3')]
    for i in range(0, len(seq) - 1, 2): assert {seq[i].split('_')[1], seq[i + 1].split('_')[1]} == {'MC3H', 'MC3'} and seq[i][-2:] == seq[i + 1][-2:], seq
# ---- 写文件
os.makedirs(OUT, exist_ok=True)
hdr = '# R4N1x (AMENDMENT_02) 由 tools/make_chains_x.py 生成; 不手改. %s\n'
for x, v in P['chain'].items(): open('%s/%s.txt' % (OUT, x), 'w').write(hdr % ('主链 ' + x) + ''.join(b + '\n' for b in v))
for m in ('k03', 'k04'):
    open('%s/spares_%s.txt' % (OUT, m), 'w').write(hdr % ('替补 (只顶本机同格 VOID 主种子)') + ''.join(b + '\n' for b in P['spares'][m]))
    open('%s/supp_%s.txt' % (OUT, m), 'w').write(hdr % ('补跑队列 = 按 K 12:42 裁剪序被裁的条目, 顺序=优先级; 运行时 supp_fits 放得下才跑, 否则记 SUPP_SKIP_NO_TIME -> 第 2 晚') + ''.join(b + '\n' for b in P['supp'][m]))
fmt = lambda t: t.strftime('%m-%d %H:%M')
est = dict(note='全部为估算: 主包各槽负载 (N1 PLAN_ESTIMATE f=1.0) x SCALE=12/9.68 (K: 最长槽约 12 h); 追加包每条同式 x SCALE; 350 K 与长盒速率未实测 (按 D1v2 表 + 珠数缩放)',
           main_start=MAIN_START.isoformat(), deadline=DEADLINE.isoformat(), scale=round(SCALE, 4), slots={}, supp={m: P['supp'][m] for m in P['supp']}, spares=P['spares'], cell_machine={'%s_h100_T350_%s' % k: v for k, v in P['cellmach'].items()}, is_machine=P['is_mach'])
for x in MAIN_LOAD:
    t = P['end_main'][x]; items = []
    for b in P['chain'][x]:
        n = need(b, SCALE); items.append(dict(build=b, need_h=round(n, 3), start=fmt(t), end=fmt(t + dt.timedelta(hours=n)))); t += dt.timedelta(hours=n)
    est['slots'][x] = dict(main_end_est=fmt(P['end_main'][x]), append_cap_h=round(P['cap'][x], 3), items=items, append_end_est=fmt(t), slack_to_deadline_h=round((DEADLINE - t).total_seconds() / 3600, 3))
# 情景: 若速率是 f=1.0 (不乘 SCALE), 同一份链在各槽何时结束, supp 队列可接走哪些 (按 supp_fits: 剩余 >= need + 0.75 h; 两槽按时间先后领)
def scen(scale):
    t = {x: MAIN_START + dt.timedelta(hours=MAIN_LOAD[x] * scale) for x in MAIN_LOAD}
    for x in MAIN_LOAD:
        for b in P['chain'][x]: t[x] += dt.timedelta(hours=need(b, scale))
    got = []
    for m in ('k03', 'k04'):
        q = list(P['supp'][m])
        while q:
            x = min((m + '_A', m + '_B'), key=lambda y: t[y]); rem = (DEADLINE - t[x]).total_seconds() / 3600
            fit = [b for b in q if rem >= need(b, scale) + SUPP_MARGIN_H]
            if not fit: break
            b = fit[0]; q.remove(b); got.append(dict(build=b, slot=x, start=fmt(t[x]))); t[x] += dt.timedelta(hours=need(b, scale))
    return dict(slot_end={x: fmt(v) for x, v in t.items()}, supp_taken=got)
est['scenario_scale_1.24'] = scen(SCALE); est['scenario_f1.0'] = scen(1.0)
json.dump(est, open(OUT + '/PLAN_ESTIMATE.json', 'w'), indent=1, ensure_ascii=False)
for x, v in est['slots'].items(): print(x, 'main_end', v['main_end_est'], 'cap', v['append_cap_h'], 'h ->', [i['build'][5:] for i in v['items']], 'end', v['append_end_est'], 'slack', v['slack_to_deadline_h'])
print('supp', {m: [b[5:] for b in v] for m, v in P['supp'].items()}); print('spares', {m: [b[5:] for b in v] for m, v in P['spares'].items()})
print('scenario f1.0', est['scenario_f1.0']); print('scenario 1.24', est['scenario_scale_1.24'])
