#!/bin/bash
# make_package_x.sh <out_pkg_dir>  -- 组装 R4N1x 追加包 (只读 N1x/ N1/ D2/*.md, 只写 <out_pkg_dir>; 目标已存在则拒绝, 不覆盖). 仿 N1/tools/make_package.sh.
set -eu
P=${1:?out_pkg_dir}
X=$(cd "$(dirname "$0")/.." && pwd); D2=$(dirname $X); N1=$D2/N1; D1V2_RUNS=/workspace/lnp-md/scan/R4_recipe/D1v2_results_pull/results_xtc_prereg/runs.tsv
[ -e "$P" ] && { echo "REFUSE: $P 已存在 (不覆盖)"; exit 1; }
mkdir -p "$P"; cd "$P"
cp $X/run_R4N1x.sh $X/lib_R4N1x.sh $X/verdict_R4_3day.py $X/verdict_Larm.py $X/merge_status_x.py $X/README_R4N1x.md .
cp $D2/PREREG_R4_3day.md $D2/PRE_REG_AMENDMENT_R4N1_01.md $D2/PRE_REG_AMENDMENT_R4N1_02.md .
echo append > VARIANT
mkdir gate gatewrap mdp tools tools/ref_main tests proof chains inputs inputs/ff
cp $X/gate/*.py gate/; cp $X/gatewrap/*.sh gatewrap/; cp $X/mdp/*.mdp mdp/; cp $X/tests/*.py tests/
for t in $X/tools/*; do [ -f $t ] && cp $t tools/; done
cp $N1/run_R4N1.sh $N1/lib_R4N1.sh tools/ref_main/     # 主包两文件 (只供 diff 对照, 不被调用)
cp -r $X/proof/grompp_box proof/; cp $X/proof/*.tsv proof/
cp -r $N1/proof/readout_validation $N1/proof/verdict_realdata proof/; cp $N1/proof/neg_selftest_bridged.gro proof/
cp $X/chains/*.txt $X/chains/PLAN_ESTIMATE.json chains/
cp $X/inputs/L1_summary.tsv inputs/; cp $D1V2_RUNS inputs/D1v2_lam_runs.tsv; cp $X/inputs/ff/*.itp inputs/ff/
for b in $(cat chains/*.txt | grep -vE '^\s*(#|$)' | awk '{print $1}' | sort -u); do
  s=$X/inputs/$b; [ -s $s/start.gro ] || { echo "ERR: 缺 $s/start.gro"; exit 1; }; mkdir inputs/$b
  for x in start.gro sys.top index.ndx expect.env counts.txt SYSTEM.txt t0_builder.json preasm.json build.log relax_crescale_dev.mdp prod_hii.mdp prod_lam.mdp genconf.log; do [ -e $s/$x ] && cp $s/$x inputs/$b/; done
  for x in $s/*.itp; do n=$(basename $x); cmp -s $x inputs/ff/$n || { echo "ERR: $b/$n 与 ff 不同"; exit 1; }; ln inputs/ff/$n inputs/$b/$n; done
done
# 冻结 sha (冻结判读脚本 + PREREG + 两个修订 + 复用的 D1v2 片层臂表); verdict_Larm.py 的 sha 记在 MANIFEST 与 RUN_META
sha256sum verdict_R4_3day.py PREREG_R4_3day.md PRE_REG_AMENDMENT_R4N1_01.md PRE_REG_AMENDMENT_R4N1_02.md inputs/D1v2_lam_runs.tsv > FROZEN_sha256.txt
find . -type f ! -name MANIFEST_sha256.txt | sed 's#^\./##' | LC_ALL=C sort | xargs sha256sum > MANIFEST_sha256.txt
echo "OK $P files=$(wc -l < MANIFEST_sha256.txt) builds=$(ls -d inputs/R4N1_* | wc -l)"
