#!/usr/bin/env python3
"""verdict_Larm.py -- R4N1x L 臂 (长盒 H_II, K1 检验) 判读; 判据 = PRE_REG_AMENDMENT_R4N1_02.md §3 (看数据前写定).
只 import 冻结的 verdict_R4_3day.py (sha 见 FROZEN_sha256.txt) 的函数, 不改它: 单 run 判定 judge_hii_run / 格 hii_cell / 替补选择 select_cell / 读序列 read_series,
常量 (判定窗末 100 ns, RETAIN>=0.80, LOST<=0.20, >=400 ns, >=99 帧, n=3) 全部来自冻结文件. 唯一的运行时改动: collect 时把冻结模块的 NAME 正则
换成多认一个臂 hiiL 的版本 (只影响本进程内的名字解析; hiiL 按 hii 判). 本脚本不判 C4 (C4 用冻结 verdict 原样判).
C4 (350 K h100) 用冻结 verdict 原样判: collect 冻结脚本按其 NAME 自动跳过 hiiL; 要与主包一起出 C1-C4 总判, 先用 merge_status_x.py 合并两边 runs_status.tsv.
用法:
  python3 verdict_Larm.py collect <R4N1x_run_k03_...> <R4N1x_run_k04_...> --inputs <追加包>/inputs --out <OUTL>
  python3 verdict_Larm.py judge <OUTL> --short-status <主包 verdict collect 输出>/runs_status.tsv --short-inputs <主包>/inputs [--horizons 400,max]
输出 <OUTL>/VERDICT_Larm.json / .md. 读法 (预写, §3): 比较时长 H_cmp = 两个 DOPC 格 (长盒 hiiL 与短盒 C1 hii) 所用 run 的观测时长最小值 (须 >= 400 ns), 两边都截到 H_cmp 判.
  长盒 DOPC LOST>=2/3 且 短盒 DOPC LOST<2/3 -> SHORT_BOX_ARTIFACT: 短盒 (Lz0 < 2π r_water0) H_II 臂的 RETAIN 读数降级 (见 §3.3), 不改任何 RULER 判定、不放宽."""
import argparse, csv, hashlib, json, math, os, re, sys
from concurrent.futures import ThreadPoolExecutor
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import verdict_R4_3day as V   # 冻结
NAME_L = re.compile(r'^R4N1_(DOPE|DOPC|MC3H|MC3)_(h\d{3})_(T\d{3})_(hii|hiiL|lam)_s(\d+)$')
LCELLS = {'DOPE': 'DOPE_h050_T320', 'DOPC': 'DOPC_h050_T320'}
def sha(p): return V.sha256(p)

def collect(a):
    V.NAME = NAME_L
    l1 = {}
    for ln in open(os.path.join(a.inputs, 'L1_summary.tsv')).read().splitlines()[1:]:
        p = ln.split('\t'); l1[p[0]] = p[2]
    builds = sorted(b for b in l1 if NAME_L.match(b) and NAME_L.match(b).group(4) == 'hiiL'); os.makedirs(a.out, exist_ok=True)
    roots = [os.path.abspath(r) for r in a.runs]
    with ThreadPoolExecutor(a.jobs) as ex: recs = list(ex.map(lambda b: V.collect_one(b, roots, a.inputs, a.out, l1), builds))
    p = os.path.join(a.out, 'runs_status_Larm.tsv')
    with open(p + '.tmp', 'w') as f:
        f.write('\t'.join(V.STATUS_COLS) + '\n')
        for r in recs: f.write('\t'.join(str(r.get(c, '-')) if r.get(c, '') != '' else '-' for c in V.STATUS_COLS) + '\n')
    os.replace(p + '.tmp', p); print('wrote', p, len(recs), 'builds')

def geom(inputs, b):
    t = open(os.path.join(inputs, b, 'SYSTEM.txt')).read(); g = json.loads(re.search(r'geom=(\{.*?\})', t).group(1)); return g

def as_hii(st):
    st = dict(st); st['arm'] = 'hii' if st['arm'] in ('hii', 'hiiL') else st['arm']; return st

def cell_runs(rows, prim, w, T, arm, horizon):
    sel = [r for r in rows if r['prim'] == prim and r['w'] == w and r['T'] == T and r['arm'] == arm]
    return [V.judge_run(as_hii(r), horizon) for r in sorted(sel, key=lambda r: int(r['seed']))]

def t_obs(runs):
    used, _ = V.select_cell(runs); ev = [r for r in used if r['status'] in V.EVAL_HII]
    return min(r['T_obs_ns'] for r in ev) if len(ev) >= V.N_PER else None

def reading(L, S):
    """预写读法 (AMENDMENT_02 §3.2). L/S = hii_cell(...) 结果 (同一 H_cmp)."""
    if L['state'] != 'EVALUABLE' or S['state'] != 'EVALUABLE': return 'NOT_EVALUABLE', '长盒或短盒 DOPC 格不可评估 (n<3 或未跑), 不下读法'
    lL = L['n_LOST'] >= 2; lS = S['n_LOST'] >= 2
    if lL and not lS: return 'SHORT_BOX_ARTIFACT', '长盒 DOPC LOST>=2/3 而短盒没有 -> 短盒有盒长伪影 (K1 成立): 短盒 (Lz0<2π r_water0) H_II 臂 RETAIN 降级'
    if lL and lS: return 'CONSISTENT_LOST', '长短盒 DOPC 都 LOST>=2/3: 未见盒长伪影'
    if lS and not lL: return 'LONG_BOX_RETAINS_MORE', '短盒 LOST>=2/3 而长盒没有: 与 K1 方向相反, 只报告, 预注册未写对此的降级/升级'
    if L['n_RETAIN'] >= 2 and S['n_RETAIN'] >= 2: return 'CONSISTENT_RETAIN', '长短盒 DOPC 都 RETAIN>=2/3: 在 h050、Lz0 约 22 nm、H_cmp 内未见盒长效应 (K1 在此范围未得到支持; 不排除更长波长/更慢过程, 不覆盖 h100)'
    return 'MIXED', '长短盒都不满足 LOST>=2/3, 且不同时 RETAIN>=2/3: 不下读法'

def judge(a):
    L = list(csv.DictReader(open(os.path.join(a.out, 'runs_status_Larm.tsv')), delimiter='\t'))
    S = list(csv.DictReader(open(a.short_status), delimiter='\t'))
    res = dict(script='verdict_Larm.py', script_sha256=sha(os.path.abspath(__file__)), frozen_verdict_sha256=sha(V.__file__), prereg='PRE_REG_AMENDMENT_R4N1_02.md §3',
               constants=dict(N_PER=V.N_PER, WIN_NS=V.WIN_NS, WIN_MIN_FRAMES=V.WIN_MIN_FRAMES, T_EVAL_MIN_NS=V.T_EVAL_MIN_NS, RETAIN_MIN=V.RETAIN_MIN, LOST_MAX=V.LOST_MAX), by_horizon={})
    # 比较时长 H_cmp (两 DOPC 格所用 run 最短观测时长)
    hl = t_obs(cell_runs(L, 'DOPC', 'h050', 'T320', 'hiiL', None)); hs = t_obs(cell_runs(S, 'DOPC', 'h050', 'T320', 'hii', None))
    H = None if hl is None or hs is None else math.floor(min(hl, hs) + 1e-6)
    res['H_cmp_ns'] = H
    hz = [None if x.strip() == 'max' else float(x) for x in a.horizons.split(',')]
    if H is not None and H >= V.T_EVAL_MIN_NS and H not in hz: hz.append(float(H))
    for h in hz:
        k = 'max' if h is None else '%g' % h; out = {}
        for p in ('DOPE', 'DOPC'):
            cl = V.hii_cell(cell_runs(L, p, 'h050', 'T320', 'hiiL', h)); cs = V.hii_cell(cell_runs(S, p, 'h050', 'T320', 'hii', h))
            out[p] = dict(long=cl, short=cs)
        r, why = reading(out['DOPC']['long'], out['DOPC']['short'])
        dl = out['DOPE']['long']
        pos = 'NOT_EVALUABLE' if dl['state'] != 'EVALUABLE' else ('POS_OK' if dl['n_RETAIN'] >= 2 else 'POS_FAIL')
        lr = 'NOT_EVALUABLE' if 'NOT_EVALUABLE' in (pos,) or out['DOPC']['long']['state'] != 'EVALUABLE' else (
            'PASS' if pos == 'POS_OK' and out['DOPC']['long']['n_RETAIN'] == 0 and out['DOPC']['long']['n_LOST'] >= 2 else 'FAIL')
        res['by_horizon'][k] = dict(cells=out, DOPC_reading=r, DOPC_reading_why=why, DOPE_long_positive=pos, long_ruler_rule12=lr)
    dec = res['by_horizon'].get('%g' % H) if H is not None and H >= V.T_EVAL_MIN_NS else None
    res['decisive'] = dict(horizon=None if dec is None else H, DOPC_reading=dec['DOPC_reading'] if dec else 'NOT_EVALUABLE',
                           note='决定性读法只看 H_cmp; 其它时长只描述' if dec else 'H_cmp 不存在或 < 400 ns -> NOT_EVALUABLE')
    # 降级范围 (§3.3): 短盒 = Lz0 < 2π r_water0 的 hii 构型 (从 SYSTEM.txt 读)
    if a.short_inputs:
        sc = {}
        for r in S:
            if r['arm'] != 'hii': continue
            c = '%s_%s_%s' % (r['prim'], r['w'], r['T'])
            if c in sc: continue
            try: g = geom(a.short_inputs, r['build']); sc[c] = dict(Lz0=g['Lz'], r_water0=g['r_water'], ratio=round(g['Lz'] / (2 * math.pi * g['r_water']), 3))
            except Exception as e: sc[c] = dict(error=str(e)[:80])
        res['short_box_scope'] = {c: dict(v, short=v.get('ratio', 9) < 1) for c, v in sorted(sc.items())}
        res['downgraded_if_artifact'] = sorted(c for c, v in res['short_box_scope'].items() if v.get('short'))
        res['not_covered_by_Larm'] = sorted(c for c, v in res['short_box_scope'].items() if v.get('short') and c.split('_')[1] != 'h050')   # [REVIEW v3] L 臂只在 h050 做; 其它水合的短盒 H_II RETAIN 不因 CONSISTENT_* 而"放行" (AMENDMENT_02 §3.3)
    json.dump(res, open(os.path.join(a.out, 'VERDICT_Larm.json'), 'w'), indent=1, ensure_ascii=False)
    M = ['# VERDICT L 臂 (verdict_Larm.py %s; 冻结 verdict %s)' % (res['script_sha256'][:16], res['frozen_verdict_sha256'][:16]), '',
         '比较时长 H_cmp = %s ns (两 DOPC 格所用 run 最短观测时长; 须 >= 400)' % H, '']
    for k, v in res['by_horizon'].items():
        M.append('## 时长 %s%s' % (k, ' (决定性)' if dec is v else ' (描述)'))
        for p in ('DOPE', 'DOPC'):
            for side in ('long', 'short'):
                c = v['cells'][p][side]; M.append('- %s %s: %s n=%d RETAIN %d / LOST %d / PARTIAL %d  %s' % (p, '长盒 hiiL' if side == 'long' else '短盒 C1 hii', c['state'], c['n_eval'], c['n_RETAIN'], c['n_LOST'], c['n_PARTIAL'], ','.join(c['runs'])))
        M += ['- DOPC 读法: %s — %s' % (v['DOPC_reading'], v['DOPC_reading_why']), '- DOPE 长盒阳性对照: %s' % v['DOPE_long_positive'], '- 长盒尺子 (规则 1+2, 仅描述, 不替代 C1 RULER): %s' % v['long_ruler_rule12'], '']
    M.append('## 决定性读法: %s' % res['decisive']['DOPC_reading'])
    if res['decisive']['DOPC_reading'] == 'SHORT_BOX_ARTIFACT':
        if res['by_horizon']['%g' % H]['DOPE_long_positive'] == 'POS_FAIL': M.append('- 注意: 长盒下阳性对照 DOPE 也不保持 (POS_FAIL), 长盒读出本身可疑 (AMENDMENT_02 §3.2)')
        M.append('- 按 AMENDMENT_02 §3.3: 下列短盒 (Lz0<2π r_water0) H_II 臂 RETAIN 降级为 "可能受盒长伪影抑制", 不作 H_II 偏好证据; 各条件 RULER 判定原样保留, 不放宽、不 FAIL->PASS: ' + ', '.join(res.get('downgraded_if_artifact', ['(未给 --short-inputs)'])))
    if res.get('not_covered_by_Larm'): M.append('- 覆盖范围 (AMENDMENT_02 §3.3): L 臂只检验 h050; 下列短盒 H_II 格未被 L 臂检验, 其 RETAIN 读数无论 L 臂读法如何都标注 "盒长未检验": ' + ', '.join(res['not_covered_by_Larm']))
    open(os.path.join(a.out, 'VERDICT_Larm.md'), 'w').write('\n'.join(M) + '\n'); print('\n'.join(M))

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest='cmd', required=True)
    c = sp.add_parser('collect'); c.add_argument('runs', nargs='+'); c.add_argument('--inputs', required=True); c.add_argument('--out', required=True); c.add_argument('--jobs', type=int, default=4)
    j = sp.add_parser('judge'); j.add_argument('out'); j.add_argument('--short-status', required=True); j.add_argument('--short-inputs'); j.add_argument('--horizons', default='400,max')
    a = ap.parse_args(); collect(a) if a.cmd == 'collect' else judge(a)
