#!/usr/bin/env python3
"""verdict_R4_3day.py -- R4 三晚 (R4N1/N2/N3) 判读脚本. 判据全部来自 PREREG_R4_3day.md (§3-§5, §7), 阈值写死在下方常量;
本文件与 PREREG 的 sha256 写在 MANIFEST/FROZEN_sha256.txt, 改了审查会看见. 零算力 (只读 xtc/STATUS, 只写 --out 目录).

用法:
  python3 verdict_R4_3day.py collect <R4N1_run_目录>... --inputs <N1/inputs> --out <结果目录> [--jobs 4]
      逐 build 汇总起点/prod 状态 (STATUS 文件), 核对 prod 回传文件的 SHA256_out.txt, 对 prod xtc (多 attempt 按序拼接) 跑 gate/series_R4N1.py.
      幂等: series 已存在且源 xtc (路径+大小+mtime) 未变则跳过. 写 <out>/runs_status.tsv, <out>/series/<b>.csv, <out>/series/<b>.src.json
  python3 verdict_R4_3day.py judge <结果目录> --d1v2-lam <D1v2 results_xtc_prereg/runs.tsv> [--compare <旧 VERDICT.json>] [--horizons 400,max]
      -> <out>/runs.tsv cells.tsv VERDICT.json VERDICT.md

冻结规则摘要 (逐条对应 PREREG):
  §3 H_II 臂逐帧: HII = wpol==1 且 n_tube>=1; LAM = wpol==2; NET = wpol==3; DISC = wpol==0; 其余 (wpol==1 且 n_tube==0) = OTHER (非 HII).
  §3 H_II 臂逐条: 判定窗 = 该 run 最后 100 ns (1 ns/帧, 101 帧); RETAIN f_HII>=0.80; LOST f_HII<=0.20 (子类 = 窗内非 HII 帧多数类;
      多数类为 LAM 时还要求窗内 LAM 帧 C_max 中位数 >=0.6 才记 LAM_RETURN, 否则 LAM_LOWC, 仍算 LOST); 其余 PARTIAL.
      t_loss = 5 ns 步长扫描, 第一个 [t0, t0+20 ns] 全为非 HII 帧的 t0 (描述量). n_tube 终值 (描述量).
  §3 片层臂: 主事件 = wpol==1 且 Cz<=0.5 持续 >=20 ns (R3/D1v2 sustained 函数逐字); 次级 = ncl==1 持续 >=5 ns (描述/确认, 不进门).
  §4 起点: VOID_BUILD (L1) / VOID_L2 / RELAX_FAIL 记起点级 VOID -> 同格替补 (s4) 按序顶上; 替补只顶 VOID, 不顶其它失败.
      可评估 n<3 -> 该体系x起点 NOT_EVALUABLE (写明 n); 尺子体系 NOT_EVALUABLE -> 条件 RULER_NOT_EVALUABLE.
  prod NUMERIC_FAIL / GROMPP_FAIL = 不可评估 (不顶); prod VOID_SEL_MISMATCH (起点与闸门判过的帧不一致) = 起点级 VOID (lib 同样记 ledger void).
  评估资格 (建包时、看数据前定): H_II 臂 run 须 prod 观测 >= 400 ns 且判定窗帧数 >= 99, 否则 TRUNC/WINDOW_INCOMPLETE = 不可评估, 不用替补顶;
      片层臂同 D1v2: 有事件即 EVENT (截断前发生也算), 无事件须观测 >= 400 ns 否则 TRUNC (不可评估). xtc sha 与 SHA256_out.txt 不符 = SHA_MISMATCH 不可评估.
  §5 RULER(c): 1 DOPE_hii RETAIN>=2/3; 2 DOPC_hii RETAIN==0/3 且 LOST>=2/3 (命门); 3 DOPC_lam 主事件 0/3 (否则 F3 驱动过强, 条件无效).
      320 K 片层臂复用 D1v2 (--d1v2-lam): 同体系同水合档, D1v2 runs.tsv 里状态为 EVENT/NO_EVENT 的 run 计入; 该体系无此类 run = 起点级 VOID (D1v2: MC3 10/10 VOID_L2).
  §5 相类 (每体系, 每条件; 只在 RULER=PASS 的条件下用于结论): LAM_PREF / HII_PREF / HYST / NEITHER / MIXED (定义见 phase_class); 任一臂 NOT_EVALUABLE -> NOT_EVALUABLE.
  §5 Δ = n_RETAIN(MC3_hii) - n_RETAIN(MC3H_hii): >=+2 SEP_EXPECTED, <=-2 SEP_REVERSE, 其余 NO_SEP; 只在 RULER=PASS 且两格都可评估时判.
  §5 主条件: 优先级 C1 > C3 > C2 > C4 中第一个 PASS.
  §5/§7 F4 时间稳健性: 每个 horizon (默认 400 ns 与各 run 最长时长) 都判一遍; 较短 horizon PASS 而最长 horizon 不 PASS -> 明文 "撤回";
      --compare 给旧 VERDICT.json 时, 旧的 PASS 现在不再 PASS 也明文 "撤回". 最终结论只用最长时长.
  §7 F1 命门失败: 所有已跑 (可评估) 条件规则 2 都 FAIL -> F1; 按 K 10-30 11:30 决定走 B1 (350 K 续到 2 µs). F2: 所有已跑条件 DOPE_hii LOST>=2/3.
"""
import argparse, csv, glob, hashlib, json, os, re, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
HERE = os.path.dirname(os.path.abspath(__file__))
# ---------------- 预注册常量 (PREREG_R4_3day.md) ----------------
N_PER = 3
WIN_NS = 100.0                 # 判定窗: 最后 100 ns
WIN_MIN_FRAMES = 99            # 窗内帧数下限 (101 帧, 允许续跑接缝丢 2 帧) [建包时定]
T_EVAL_MIN_NS = 400.0          # 可评估的最短 prod 观测时长
RETAIN_MIN, LOST_MAX = 0.80, 0.20
LAM_RETURN_CMAX = 0.6
TLOSS_RUN_NS, TLOSS_STEP_NS = 20.0, 5.0
CZ_MAX, EVENT_PERSIST_NS = 0.5, 20.0     # 片层主事件 (D1v2 同)
MERGE_PERSIST_NS = 5.0                   # 片层次级 ncl==1
DOPE_RETAIN_MIN = 2            # 规则 1
DOPC_RETAIN_MAX, DOPC_LOST_MIN = 0, 2    # 规则 2
DOPC_LAM_EVENTS_MAX = 0        # 规则 3
DELTA_SEP = 2
PRIMS = ['DOPE', 'DOPC', 'MC3H', 'MC3']
CONDS = {'C1': ('T320', 'h050'), 'C3': ('T320', 'h100'), 'C2': ('T350', 'h050'), 'C4': ('T350', 'h100')}
PRIORITY = ['C1', 'C3', 'C2', 'C4']
PRIMARY_SEEDS, SPARE_SEEDS = (1, 2, 3), (4,)
START_VOID = ('VOID_BUILD', 'VOID_L2', 'RELAX_FAIL', 'VOID_SEL_MISMATCH')   # lib 记 ledger void 的起点级失败 -> 替补
NAME = re.compile(r'^R4N1_(DOPE|DOPC|MC3H|MC3)_(h\d{3})_(T\d{3})_(hii|lam)_s(\d+)$')

def sustained(t, m, persist):   # R3/D1v2 冻结函数, 逐字
    n = len(t); k = 0
    while k < n:
        if not m[k]: k += 1; continue
        j = k
        while j + 1 < n and m[j + 1]: j += 1
        if t[j] - t[k] >= persist - 1e-9 and (j > k or persist <= 0): return float(t[k])
        k = j + 1
    return None

def frame_cls(wpol, n_tube):
    if wpol == 1 and n_tube >= 1: return 'HII'
    return {2: 'LAM', 3: 'NET', 0: 'DISC'}.get(wpol, 'OTHER')

def read_series(path, horizon=None):
    R = list(csv.DictReader(open(path)))
    rows = []
    for x in R:
        rows.append(dict(t=float(x['t_ns']), ncl=int(float(x['ncl'])), wind=int(float(x['wind'])), wpol=int(float(x['wpol'])),
                         n_tube=int(float(x['n_tube'])), Cz=float(x['Cz']), C_max=float(x['C_max'])))
    rows.sort(key=lambda r: r['t'])
    if rows:
        t0 = rows[0]['t']
        for r in rows: r['t'] -= t0
    if horizon is not None: rows = [r for r in rows if r['t'] <= horizon + 1e-6]
    return rows

def judge_hii_run(rows):
    """-> dict(status, f_HII, sub, t_loss, n_tube_final, ...). status in RETAIN/LOST/PARTIAL/TRUNC/WINDOW_INCOMPLETE/NO_FRAMES"""
    if not rows: return dict(status='NO_FRAMES', T_obs_ns=0.0)
    T = rows[-1]['t']; out = dict(T_obs_ns=round(T, 3), n_frames=len(rows))
    cls = [frame_cls(r['wpol'], r['n_tube']) for r in rows]; t = [r['t'] for r in rows]
    # t_loss (描述; 不依赖判定窗)
    tl = None; t0 = 0.0
    while t0 + TLOSS_RUN_NS <= T + 1e-6:
        idx = [i for i in range(len(t)) if t0 - 1e-6 <= t[i] <= t0 + TLOSS_RUN_NS + 1e-6]
        if idx and t[idx[-1]] - t[idx[0]] >= TLOSS_RUN_NS - 1e-6 and all(cls[i] != 'HII' for i in idx): tl = t0; break
        t0 += TLOSS_STEP_NS
    out.update(t_loss_ns=tl, n_tube_final=rows[-1]['n_tube'], cls_final=cls[-1], n_tube_t0=rows[0]['n_tube'])
    if T < T_EVAL_MIN_NS - 1e-6: out['status'] = 'TRUNC'; return out
    w = [i for i in range(len(t)) if t[i] >= T - WIN_NS - 1e-6]; out['n_window'] = len(w)
    if len(w) < WIN_MIN_FRAMES: out['status'] = 'WINDOW_INCOMPLETE'; return out
    wc = [cls[i] for i in w]; f = sum(c == 'HII' for c in wc) / len(wc); out['f_HII'] = round(f, 4)
    cnt = {k: wc.count(k) for k in ('HII', 'LAM', 'NET', 'DISC', 'OTHER')}; out['window_counts'] = cnt
    if f >= RETAIN_MIN - 1e-12: out['status'] = 'RETAIN'
    elif f <= LOST_MAX + 1e-12:
        out['status'] = 'LOST'; non = {k: v for k, v in cnt.items() if k != 'HII'}
        maj = sorted(non, key=lambda k: (-non[k], ['LAM', 'NET', 'DISC', 'OTHER'].index(k)))[0]
        if maj == 'LAM':
            cm = sorted(rows[i]['C_max'] for i in w if cls[i] == 'LAM'); med = cm[len(cm) // 2] if len(cm) % 2 else 0.5 * (cm[len(cm) // 2 - 1] + cm[len(cm) // 2])
            out['C_max_med_LAM'] = round(med, 4); out['sub'] = 'LAM_RETURN' if med >= LAM_RETURN_CMAX else 'LAM_LOWC'
        else: out['sub'] = maj
    else: out['status'] = 'PARTIAL'
    return out

def judge_lam_run(rows):
    if not rows: return dict(status='NO_FRAMES', T_obs_ns=0.0)
    t = [r['t'] for r in rows]; T = t[-1]; Cz = [r['Cz'] for r in rows]
    deg = all(c < 1e-3 for c in Cz)
    ev = sustained(t, [(r['wpol'] == 1) and (r['Cz'] <= CZ_MAX) and not deg for r in rows], EVENT_PERSIST_NS)
    mg = sustained(t, [r['ncl'] == 1 for r in rows], MERGE_PERSIST_NS)
    out = dict(T_obs_ns=round(T, 3), n_frames=len(rows), t_event_ns=ev, t_merge_ns=mg, cz_degenerate=deg, wpol_final=rows[-1]['wpol'])
    if deg: out['status'] = 'CZ_DEGENERATE'
    elif ev is not None: out['status'] = 'EVENT'
    elif T >= T_EVAL_MIN_NS - 1e-6: out['status'] = 'NO_EVENT'
    else: out['status'] = 'TRUNC'
    return out

EVAL_HII = ('RETAIN', 'LOST', 'PARTIAL'); EVAL_LAM = ('EVENT', 'NO_EVENT')

# ---------------------------------------------------------------- collect
def last_state(d):
    a = sorted(glob.glob(os.path.join(d, 'attempt_[0-9][0-9][0-9]')))
    if not a: return 'NONE', []
    sts = []
    for x in a:
        s = os.path.join(x, 'STATUS'); sts.append((x, open(s).read().split()[0] if os.path.exists(s) and open(s).read().split() else 'NOSTATUS'))
    return sts[-1][1], sts

def sha256(p, bs=1 << 20):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(bs), b''): h.update(b)
    return h.hexdigest()

def collect_one(b, roots, inputs, out, l1):
    m = NAME.match(b); rec = dict(build=b, prim=m.group(1), w=m.group(2), T=m.group(3), arm=m.group(4), seed=int(m.group(5)), roots='', note='')
    if l1.get(b, 'VOID_BUILD') != 'PASS': rec.update(start='VOID_BUILD', prod='NONE', series='-'); return rec
    bds = [os.path.join(r, 'builds', b) for r in roots if os.path.isdir(os.path.join(r, 'builds', b))]
    if not bds: rec.update(start='NOT_RUN', prod='NONE', series='-'); return rec
    rec['roots'] = ';'.join(bds)
    gate = 'NONE'; relax = 'NONE'; prods = []
    for bd in bds:
        g, _ = last_state(os.path.join(bd, 'gate')); r, _ = last_state(os.path.join(bd, 'relax')); _, ps = last_state(os.path.join(bd, 'prod'))
        if g != 'NONE': gate = g
        if r != 'NONE': relax = r
        prods += ps
    if gate == 'PASS': start = 'PASS'
    elif gate == 'VOID_L2': start = 'VOID_L2'
    elif gate in ('GATE_TIMEOUT', 'GATE_ERROR'): start = gate
    elif relax == 'RELAX_FAIL': start = 'RELAX_FAIL'
    elif relax in ('DONE',): start = 'GATE_NONE'
    else: start = 'RELAX_' + relax
    rec['start'] = start
    states = [s for _, s in prods]; rec['prod'] = 'DONE' if 'DONE' in states else (states[-1] if states else 'NONE'); rec['prod_attempts'] = ','.join(states)
    xtcs = []; shabad = []
    for d, _ in prods:
        xs = sorted(glob.glob(os.path.join(d, 'prod*.xtc'))); xtcs += xs
        sf = os.path.join(d, 'SHA256_out.txt'); ref = {}
        if os.path.exists(sf):
            for ln in open(sf):
                p = ln.split()
                if len(p) == 2: ref[p[1].lstrip('*')] = p[0]
        for x in xs:
            r = ref.get(os.path.basename(x))
            if r is None: shabad.append(os.path.basename(x) + ':NO_REF')
            elif sha256(x) != r: shabad.append(os.path.basename(x) + ':MISMATCH')
    if 'VOID_SEL_MISMATCH' in states and 'DONE' not in states: rec['start'] = start = 'VOID_SEL_MISMATCH'
    rec['xtc'] = ';'.join(xtcs); rec['sha_check'] = 'OK' if xtcs and not shabad else ('NO_XTC' if not xtcs else ','.join(shabad))
    if start != 'PASS' or not xtcs: rec['series'] = '-'; return rec
    sd = os.path.join(out, 'series'); os.makedirs(sd, exist_ok=True); cs = os.path.join(sd, b + '.csv'); sj = cs[:-4] + '.src.json'
    src = [[x, os.path.getsize(x), int(os.path.getmtime(x))] for x in xtcs]
    if not (os.path.exists(cs) and os.path.exists(sj) and json.load(open(sj)).get('src') == src):
        top = os.path.join(inputs, b, 'start.gro')
        p = subprocess.run([sys.executable, os.path.join(HERE, 'gate', 'series_R4N1.py'), top] + xtcs + ['--out', cs, '--no-v1'], capture_output=True, text=True)
        if p.returncode != 0: rec['series'] = '-'; rec['note'] = 'SERIES_ERROR: ' + p.stderr.strip().splitlines()[-1][:200] if p.stderr.strip() else 'SERIES_ERROR'; return rec
        json.dump(dict(src=src, top=top), open(sj + '.tmp', 'w')); os.replace(sj + '.tmp', sj)
    rec['series'] = cs; return rec

STATUS_COLS = ['build', 'prim', 'w', 'T', 'arm', 'seed', 'start', 'prod', 'prod_attempts', 'sha_check', 'series', 'xtc', 'roots', 'note']
def collect(a):
    l1 = {}
    for ln in open(os.path.join(a.inputs, 'L1_summary.tsv')).read().splitlines()[1:]:
        p = ln.split('\t'); l1[p[0]] = p[2]
    builds = sorted(b for b in l1 if NAME.match(b)); os.makedirs(a.out, exist_ok=True)
    roots = [os.path.abspath(r) for r in a.runs]
    with ThreadPoolExecutor(a.jobs) as ex: recs = list(ex.map(lambda b: collect_one(b, roots, a.inputs, a.out, l1), builds))
    p = os.path.join(a.out, 'runs_status.tsv')
    with open(p + '.tmp', 'w') as f:
        f.write('\t'.join(STATUS_COLS) + '\n')
        for r in recs: f.write('\t'.join(str(r.get(c, '-')) if r.get(c, '') != '' else '-' for c in STATUS_COLS) + '\n')
    os.replace(p + '.tmp', p); print('wrote', p, len(recs), 'builds')

# ---------------------------------------------------------------- judge
def judge_run(st, horizon):
    """st: runs_status 行 -> 判定 dict (含 eval 标志)"""
    r = dict(build=st['build'], prim=st['prim'], w=st['w'], T=st['T'], arm=st['arm'], seed=int(st['seed']), start=st['start'], prod=st['prod'])
    if st['start'] in START_VOID: r['status'] = st['start']; r['void'] = True; return r
    r['void'] = False
    if st['start'] == 'NOT_RUN': r['status'] = 'NOT_RUN'; return r
    if st['start'] != 'PASS': r['status'] = 'START_' + st['start']; return r
    if st['prod'] in ('NUMERIC_FAIL', 'GROMPP_FAIL'): r['status'] = 'PROD_' + st['prod']; return r
    if st.get('sha_check', 'OK') != 'OK': r['status'] = 'SHA_MISMATCH' if st.get('sha_check') != 'NO_XTC' else 'NO_PROD'; r['sha_check'] = st.get('sha_check'); return r
    if st['series'] in ('-', '') or not os.path.exists(st['series']): r['status'] = 'NO_PROD'; return r
    rows = read_series(st['series'], horizon)
    r.update(judge_hii_run(rows) if st['arm'] == 'hii' else judge_lam_run(rows)); return r

def select_cell(runs):
    """runs: 同格全部 run (按 seed). 主种子 s1-s3, VOID 由替补按序顶上. -> (used, notes)"""
    by = {r['seed']: r for r in runs}; used = []; notes = []
    spares = [by[s] for s in SPARE_SEEDS if s in by]
    for s in PRIMARY_SEEDS:
        r = by.get(s)
        if r is None: notes.append('s%d 缺' % s); continue
        if r.get('void'):
            rep = None
            while spares:
                c = spares.pop(0)
                if c.get('void'): notes.append('替补 s%d 也 %s' % (c['seed'], c['status'])); continue
                rep = c; break
            if rep is None: notes.append('s%d %s 无可用替补' % (s, r['status'])); continue
            notes.append('s%d %s -> 替补 s%d' % (s, r['status'], rep['seed'])); used.append(rep)
        else: used.append(r)
    for c in spares:
        if not c.get('void') and c['status'] not in ('NOT_RUN',): notes.append('替补 s%d 已跑但未被需要, 不计入' % c['seed'])
    return used, notes

def hii_cell(runs):
    used, notes = select_cell(runs); ev = [r for r in used if r['status'] in EVAL_HII]
    c = dict(n_eval=len(ev), n_RETAIN=sum(r['status'] == 'RETAIN' for r in ev), n_LOST=sum(r['status'] == 'LOST' for r in ev),
             n_PARTIAL=sum(r['status'] == 'PARTIAL' for r in ev), LOST_sub=[r.get('sub') for r in ev if r['status'] == 'LOST'],
             runs=['%s:%s' % (r['build'], r['status']) for r in used], notes=notes,
             n_void=sum(1 for r in runs if r.get('void')), n_total=len(runs))
    if not runs or all(r['status'] == 'NOT_RUN' for r in runs): c['state'] = 'NOT_RUN'
    elif all(r.get('void') for r in runs if r['status'] != 'NOT_RUN') and not ev: c['state'] = 'VOID'
    elif len(ev) >= N_PER: c['state'] = 'EVALUABLE'
    else: c['state'] = 'NOT_EVALUABLE'
    return c

def lam_cell_from_runs(runs):
    used, notes = select_cell(runs); ev = [r for r in used if r['status'] in EVAL_LAM]
    c = dict(n_eval=len(ev), n_event=sum(r['status'] == 'EVENT' for r in ev), n_merge=sum(r.get('t_merge_ns') is not None for r in ev),
             runs=['%s:%s' % (r['build'], r['status']) for r in used], notes=notes, source='R4N1', n_void=sum(1 for r in runs if r.get('void')), n_total=len(runs))
    if not runs or all(r['status'] == 'NOT_RUN' for r in runs): c['state'] = 'NOT_RUN'
    elif all(r.get('void') for r in runs if r['status'] != 'NOT_RUN') and not ev: c['state'] = 'VOID'
    elif len(ev) >= N_PER: c['state'] = 'EVALUABLE'
    else: c['state'] = 'NOT_EVALUABLE'
    return c

def lam_cell_d1v2(rows, prim, w):
    sel = sorted([r for r in rows if r['prim'] == prim and r['w'] == w], key=lambda r: int(r['seed'])); ev = [r for r in sel if r['status'] in EVAL_LAM][:N_PER]
    c = dict(n_eval=len(ev), n_event=sum(r['status'] == 'EVENT' for r in ev), n_merge=sum(r.get('t_merge', 'None') not in ('None', '', '-') for r in ev),
             runs=['%s:%s' % (r['build'], r['status']) for r in sel], notes=['320 K 片层臂复用 D1v2 (results_xtc_prereg/runs.tsv)'], source='D1v2')
    c['state'] = 'VOID' if not sel else ('EVALUABLE' if len(ev) >= N_PER else 'NOT_EVALUABLE')
    if not sel: c['notes'].append('D1v2 该体系无可评估 run (D1v2: 中性 MC3 10/10 VOID_L2) -> 起点级 VOID')
    return c

def rule(cell, fn):
    if cell is None or cell['state'] != 'EVALUABLE': return 'NOT_EVALUABLE'
    return 'PASS' if fn(cell) else 'FAIL'

def phase_class(h, l):
    if h is None or l is None or h['state'] in ('NOT_EVALUABLE', 'NOT_RUN') or l['state'] in ('NOT_EVALUABLE', 'NOT_RUN'): return 'NOT_EVALUABLE'
    hv, lv = h['state'] == 'VOID', l['state'] == 'VOID'
    if hv and lv: return 'NOT_EVALUABLE'   # PRE_REG_AMENDMENT_R4N1_01 (M1): 两臂都 VOID -> NOT_EVALUABLE (PREREG §5 L99 / §9.7 取更严读法); 说明见 MC3_note
    Hk = (not hv) and h['n_RETAIN'] >= 2; Hl = (not hv) and h['n_LOST'] >= 2
    Lk = (not lv) and (l['n_eval'] - l['n_event']) >= 2; Le = (not lv) and l['n_event'] >= 2
    if Lk and Hl: return 'LAM_PREF'
    if Hk and Le: return 'HII_PREF'
    if Hk and Lk: return 'HYST'
    if (Hl or hv) and (Le or lv): return 'NEITHER'   # 单臂 VOID + 另一臂 LOST 仍记 NEITHER (§5)
    return 'MIXED'

def judge_condition(cid, runs, d1v2):
    T, w = CONDS[cid]; res = dict(T=T, w=w, systems={})
    any_run = False
    for p in PRIMS:
        hr = [r for r in runs if r['prim'] == p and r['w'] == w and r['T'] == T and r['arm'] == 'hii']
        h = hii_cell(hr) if hr else None
        if T == 'T320': l = lam_cell_d1v2(d1v2, p, w)
        else:
            lr = [r for r in runs if r['prim'] == p and r['w'] == w and r['T'] == T and r['arm'] == 'lam']; l = lam_cell_from_runs(lr) if lr else None
        if h and h['state'] != 'NOT_RUN': any_run = True
        res['systems'][p] = dict(hii=h, lam=l, phase_class=phase_class(h, l))
    if not any_run: res['ruler'] = 'NOT_RUN'; return res
    S = res['systems']
    r1 = rule(S['DOPE']['hii'], lambda c: c['n_RETAIN'] >= DOPE_RETAIN_MIN)
    r2 = rule(S['DOPC']['hii'], lambda c: c['n_RETAIN'] <= DOPC_RETAIN_MAX and c['n_LOST'] >= DOPC_LOST_MIN)
    r3 = rule(S['DOPC']['lam'], lambda c: c['n_event'] <= DOPC_LAM_EVENTS_MAX)
    res['rules'] = {'1_DOPE_pos': r1, '2_DOPC_neg_crux': r2, '3_DOPC_lam_conserve': r3}
    # n<3 时已可确定的失败 (只作说明, 不改标签)
    det = []
    c = S['DOPC']['hii']
    if r2 == 'NOT_EVALUABLE' and c and c['n_RETAIN'] >= 1: det.append('规则2: 可评估的 DOPC_hii 中已有 RETAIN, n 补足也不会过')
    c = S['DOPC']['lam']
    if r3 == 'NOT_EVALUABLE' and c and c.get('n_event', 0) >= 1: det.append('规则3: DOPC_lam 已出现事件 (F3)')
    res['determined_fail_notes'] = det
    rs = [r1, r2, r3]
    res['ruler'] = 'RULER_NOT_EVALUABLE' if 'NOT_EVALUABLE' in rs else ('PASS' if all(x == 'PASS' for x in rs) else 'FAIL')
    res['F3_overdriven'] = (r3 == 'FAIL') or any('F3' in d for d in det)
    for p in ('MC3H', 'MC3'):
        pc = S[p]['phase_class']; S[p]['like'] = [q for q in ('DOPE', 'DOPC') if pc != 'NOT_EVALUABLE' and S[q]['phase_class'] == pc]
    if S['MC3']['hii'] and S['MC3']['hii']['state'] == 'VOID' and S['MC3']['lam'] and S['MC3']['lam']['state'] == 'VOID':
        res['MC3_note'] = '中性 MC3 在本协议下片层与 H_II 起点都无法维持 (起点级), 描述性结果, 不进门; 内标对比 NOT_EVALUABLE'
    a, b = S['MC3']['hii'], S['MC3H']['hii']
    if res['ruler'] != 'PASS': res['delta'] = dict(verdict='NOT_JUDGED', reason='RULER=%s' % res['ruler'])
    elif not (a and b and a['state'] == 'EVALUABLE' and b['state'] == 'EVALUABLE'): res['delta'] = dict(verdict='NOT_EVALUABLE', n_MC3=a and a['n_eval'], n_MC3H=b and b['n_eval'])
    else:
        d = a['n_RETAIN'] - b['n_RETAIN']; res['delta'] = dict(value=d, verdict='SEP_EXPECTED' if d >= DELTA_SEP else ('SEP_REVERSE' if d <= -DELTA_SEP else 'NO_SEP'))
    res['crux_DOPC_hii'] = dict(rule2=r2, n_RETAIN=S['DOPC']['hii']['n_RETAIN'] if S['DOPC']['hii'] else None)
    return res

def judge_all(status_rows, d1v2, horizon):
    runs = [judge_run(st, horizon) for st in status_rows]
    conds = {cid: judge_condition(cid, runs, d1v2) for cid in PRIORITY}
    main = next((c for c in PRIORITY if conds[c]['ruler'] == 'PASS'), None)
    ran = [c for c in PRIORITY if conds[c]['ruler'] != 'NOT_RUN']
    r2s = {c: conds[c]['rules']['2_DOPC_neg_crux'] for c in ran}
    F1 = bool(ran) and all(v == 'FAIL' for v in r2s.values())
    F2 = bool(ran) and all(conds[c]['systems']['DOPE']['hii'] and conds[c]['systems']['DOPE']['hii']['state'] == 'EVALUABLE'
                           and conds[c]['systems']['DOPE']['hii']['n_LOST'] >= 2 for c in ran)
    return runs, dict(conditions=conds, main_condition=main, conditions_run=ran, crux_rule2=r2s, F1_crux_fail=F1, F2_pos_ruler_fail=F2,
                      F3_overdriven=[c for c in ran if conds[c].get('F3_overdriven')],
                      branch=('B1: 350 K H_II/片层续跑到 2 µs (K 10-30 11:30 定; 共存起点补丁另立预注册)' if F1 else
                              ('主条件 %s 进第 2-3 晚续跑 (1.2 -> 2 µs) 做时间稳健性' % main if main else '无 PASS 条件且非 F1: 按 PLAN §6 由 K 定 (不自动执行)')))

RUN_COLS = ['build', 'prim', 'w', 'T', 'arm', 'seed', 'start', 'prod', 'status', 'sub', 'f_HII', 'T_obs_ns', 'n_frames', 'n_window', 't_loss_ns',
            'n_tube_t0', 'n_tube_final', 'C_max_med_LAM', 't_event_ns', 't_merge_ns', 'window_counts']
def fmt(v): return '-' if v is None or v == '' else (json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else str(v))

def judge(a):
    st = list(csv.DictReader(open(os.path.join(a.out, 'runs_status.tsv')), delimiter='\t'))
    d1 = list(csv.DictReader(open(a.d1v2_lam), delimiter='\t'))
    hz = []
    for x in a.horizons.split(','):
        hz.append(None if x.strip() == 'max' else float(x))
    per = {}
    for h in hz: per['max' if h is None else '%g' % h] = judge_all(st, d1, h)
    runs, final = per['max'] if 'max' in per else per[list(per)[-1]]
    retract = []
    for k, (_, v) in per.items():
        if k == 'max': continue
        for c in PRIORITY:
            if v['conditions'][c]['ruler'] == 'PASS' and final['conditions'][c]['ruler'] != 'PASS':
                retract.append('撤回: 条件 %s 在 %s ns 判定窗 PASS, 在最长时长判定窗为 %s' % (c, k, final['conditions'][c]['ruler']))
    if a.compare:
        old = json.load(open(a.compare))
        for c in PRIORITY:
            o = old.get('final', {}).get('conditions', {}).get(c, {}).get('ruler')
            if o == 'PASS' and final['conditions'][c]['ruler'] != 'PASS':
                retract.append('撤回: 条件 %s 在旧 VERDICT (%s) 为 PASS, 现为 %s' % (c, a.compare, final['conditions'][c]['ruler']))
    self_sha = hashlib.sha256(open(os.path.abspath(__file__), 'rb').read()).hexdigest()
    V = dict(script='verdict_R4_3day.py', script_sha256=self_sha, prereg='PREREG_R4_3day.md', d1v2_lam=os.path.abspath(a.d1v2_lam), d1v2_lam_sha256=sha256(a.d1v2_lam),
             constants=dict(N_PER=N_PER, WIN_NS=WIN_NS, WIN_MIN_FRAMES=WIN_MIN_FRAMES, T_EVAL_MIN_NS=T_EVAL_MIN_NS, RETAIN_MIN=RETAIN_MIN, LOST_MAX=LOST_MAX,
                            LAM_RETURN_CMAX=LAM_RETURN_CMAX, CZ_MAX=CZ_MAX, EVENT_PERSIST_NS=EVENT_PERSIST_NS, MERGE_PERSIST_NS=MERGE_PERSIST_NS, DELTA_SEP=DELTA_SEP),
             horizons=list(per), retractions=retract, final=final, by_horizon={k: v[1] for k, v in per.items() if k != 'max'})
    json.dump(V, open(os.path.join(a.out, 'VERDICT.json'), 'w'), indent=1, ensure_ascii=False)
    with open(os.path.join(a.out, 'runs.tsv'), 'w') as f:
        f.write('\t'.join(RUN_COLS) + '\n')
        for r in runs: f.write('\t'.join(fmt(r.get(c)) for c in RUN_COLS) + '\n')
    with open(os.path.join(a.out, 'cells.tsv'), 'w') as f:
        f.write('cond\tprim\tarm\tstate\tn_eval\tn_RETAIN\tn_LOST\tn_PARTIAL\tn_event\tn_merge\tphase_class\truns\tnotes\n')
        for c in PRIORITY:
            for p in PRIMS:
                s = final['conditions'][c]['systems'][p]
                for arm in ('hii', 'lam'):
                    x = s[arm]
                    if x is None: continue
                    f.write('\t'.join([c, p, arm, x['state'], str(x['n_eval']), fmt(x.get('n_RETAIN')), fmt(x.get('n_LOST')), fmt(x.get('n_PARTIAL')),
                                       fmt(x.get('n_event')), fmt(x.get('n_merge')), s['phase_class'], ','.join(x['runs']), '; '.join(x['notes'])]) + '\n')
    L = ['# VERDICT R4-3day (verdict_R4_3day.py sha256 %s)' % self_sha[:16], '', '判定窗 = 各 run 最长时长的最后 100 ns; horizons = %s' % ', '.join(per), '']
    for c in PRIORITY:
        x = final['conditions'][c]; L.append('## %s (%s %s): RULER = %s' % (c, x['T'], x['w'], x['ruler']))
        if x['ruler'] == 'NOT_RUN': L.append(''); continue
        L.append('- 规则: ' + ', '.join('%s=%s' % kv for kv in x['rules'].items()))
        for d in x['determined_fail_notes']: L.append('- 说明: ' + d)
        for p in PRIMS:
            s = x['systems'][p]; h = s['hii']; l = s['lam']
            hs = ('%s n=%d RETAIN %d / LOST %d / PARTIAL %d' % (h['state'], h['n_eval'], h['n_RETAIN'], h['n_LOST'], h['n_PARTIAL'])) if h else '-'
            ls = ('%s(%s) n=%d 事件 %d, ncl==1 %d' % (l['state'], l['source'], l['n_eval'], l['n_event'], l['n_merge'])) if l else '-'
            L.append('- %s: H_II %s | 片层 %s | 相类 %s%s' % (p, hs, ls, s['phase_class'], (' 像 ' + '/'.join(s['like'])) if s.get('like') else ''))
        L.append('- Δ(MC3−MC3H RETAIN): %s' % json.dumps(x['delta'], ensure_ascii=False))
        if x.get('MC3_note'): L.append('- ' + x['MC3_note'])
        L.append('')
    L += ['## 汇总', '- 主条件: %s' % final['main_condition'], '- 命门 (规则 2) 各条件: %s' % json.dumps(final['crux_rule2'], ensure_ascii=False),
          '- F1 命门失败: %s; F2 阳性尺失败: %s; F3 驱动过强: %s' % (final['F1_crux_fail'], final['F2_pos_ruler_fail'], final['F3_overdriven']),
          '- 分支: ' + final['branch']] + ['- ' + r for r in retract] + ([] if retract else ['- 撤回: 无'])
    open(os.path.join(a.out, 'VERDICT.md'), 'w').write('\n'.join(L) + '\n'); print('\n'.join(L))

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); sp = ap.add_subparsers(dest='cmd', required=True)
    c = sp.add_parser('collect'); c.add_argument('runs', nargs='+'); c.add_argument('--inputs', required=True); c.add_argument('--out', required=True); c.add_argument('--jobs', type=int, default=4)
    j = sp.add_parser('judge'); j.add_argument('out'); j.add_argument('--d1v2-lam', required=True); j.add_argument('--compare'); j.add_argument('--horizons', default='400,max')
    a = ap.parse_args(); collect(a) if a.cmd == 'collect' else judge(a)
