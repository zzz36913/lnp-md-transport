#!/bin/bash
# gate_py_container.sh  --  R4N1 的 GATE_PY 包装 (沿用 R3/D1v2 同一脚本; 只改注释, 命令行不变; 本包未在 Spark 上跑过, 发车前按 SPARK_CHECKLIST 核)
# 作用: 宿主 python3 没有 numpy, 所以把 "python3 <args>" 转到镜像 ghcr.io/novomcp/gromacs-md:spark 里跑
#       (镜像内 Python 3.10.12 + numpy 1.24.3 / scipy 1.15.3 / MDAnalysis 2.7.0, 来自调度实读; R4N1 发车前须再核, 见 SPARK_CHECKLIST).
# 调用方式 (在 Spark 上, 包放在 $HOME 下):
#       GATE_PY=$HOME/R4N1_full/gatewrap/gate_py_container.sh bash run_R4N1.sh k03      # 路径不要含空格 (lib_R4N1.sh 里 $GATE_PY 不带引号)
# lib_R4N1.sh / run_R4N1.sh 里的调用: gate/t0_gate_hii.py (hii 臂) 与 gate/t0_gate_launch.py (lam 臂) 逐帧判 json, 以及 $GATE_PY -c 'import numpy, scipy, MDAnalysis'.
# $HERE=包目录, attempt 目录在 $J=$HOME/R4N1/R4N1_run_* 之下, CHECK 的 OUT=/tmp/R4N1_check_$$, 自检用 mktemp -d (/tmp) —— 全部落在下面的 -v 挂载范围内 (launch_guard 查 $HERE/$J 在 $HOME 下).
# 可选环境变量: GATE_IMG (默认 ghcr.io/novomcp/gromacs-md:spark; lib 的 IMG 没有 export, 所以这里不读 IMG, 想换镜像设 GATE_IMG)
set -u
IMG_G=${GATE_IMG:-ghcr.io/novomcp/gromacs-md:spark}
# 挂载: $HOME 读写 (闸门要把 gate.json 写进 $OUT 下的 attempt 目录, 并读 $HERE/gate、$HERE/inputs 与 relax.gro); /tmp 读写 (CHECK 的 OUT 和 mktemp -d).
# 工作目录用调用者的 $PWD (lib 是先 cd 再调用, gate.json 用相对路径写在 cwd). 若 $PWD 不在 $HOME 或 /tmp 之下 (例如 CHECK 里的 -c 导入测试从 / 或 /var 起),
# 容器内看不到该目录, 退到 -w /tmp 并在 stderr 警告 (纯 -c 导入测试不受影响; step_gate 总是 cd 进 $HOME 下的 attempt 目录, 不会走到这条).
W=$PWD
case "$PWD" in "$HOME"|"$HOME"/*|/tmp|/tmp/*) ;; *) echo "gate_py_container.sh: 警告 PWD=$PWD 不在 \$HOME 或 /tmp 下, 容器内改用 -w /tmp" >&2; W=/tmp;; esac
# 不加 --gpus (闸门纯 CPU, 不碰 GPU/MPS, 不占卡); 不起名字 (随机名, 不会匹配 R2a_/R2b_/R3*/R4N1_/j009_ 前缀, 也不会被 run_R4N1.sh 的 cleanup 误停或被 CHECK 当成占卡容器).
# --network none: 闸门不联网. HOME=/tmp: -u 非 root 时容器里没有可写 HOME (MDAnalysis/matplotlib 缓存). PYTHONDONTWRITEBYTECODE=1: 不往 $HERE/gate 写 __pycache__ (保持包文件字节不变).
# 线程限 2: 闸门与另一槽的 mdrun 同机并行时, 别抢 Grace CPU.
exec docker run --rm --network none \
  -u "$(id -u):$(id -g)" \
  -e HOME=/tmp -e MPLCONFIGDIR=/tmp -e PYTHONDONTWRITEBYTECODE=1 \
  -e OMP_NUM_THREADS=2 -e OPENBLAS_NUM_THREADS=2 -e MKL_NUM_THREADS=2 \
  -v "$HOME:$HOME" -v /tmp:/tmp -w "$W" \
  --entrypoint python3 "$IMG_G" "$@"
