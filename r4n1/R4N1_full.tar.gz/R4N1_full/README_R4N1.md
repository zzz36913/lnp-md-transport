# R4N1 — R4 第 1 晚发车包 (T × 水合 2×2 中的 C1/C3/C2)

状态: 独立审查 (pkg/REVIEW_R4N1.md) 结论 PASS-WITH-FIXES；K 10-30 12:14 批的修复已按 **PRE_REG_AMENDMENT_R4N1_01.md** 合入 (发车前、零数据)，包已重建、box 预检重跑通过。**改过的包按规矩须再审后才发车。**
方案 11:30 拍板 (K 授权 3 天自主扫参)。判据 = PREREG_R4_3day.md (冻结); 判读 = verdict_R4_3day.py (冻结)。两者的 sha256 见 FROZEN_sha256.txt; 整包文件 sha 见 MANIFEST_sha256.txt (launch_guard 第 1 项会自动核对)。

## 1 两个版本 (19:30 分界)
| 包 | VARIANT | 格 | 主批 | 替补 (s4) | 最长槽 (估算, f=1.0 / f=0.9) |
|---|---|---|---|---|---|
| R4N1_full | full | C1 T320 h050 + C3 T320 h100 + C2 T350 h050 | 48 | 15 | 9.68 h / 约 10.8 h |
| R4N1_reduced | reduced | C1 + C2 | 36 | 11 | 7.11 h / 约 7.9 h |

- 19:30 (+0800) 前 CHECK=1 的 launch_guard 全 OK 才用 full，否则用 reduced。full 在 19:30 发车、f=0.9 时，离 07:30 只剩约 1.0 h 余量 (估算；K 12:24 重排后最长槽 +0.07 h)。
- **硬门槛 (AMENDMENT_01, S2)**: VARIANT=full 在 2026-10-30 19:30 +0800 之后**新启动**，launch_guard 直接 FAIL 并提示改用 R4N1_reduced (FULL_CUTOFF 写死在 lib，不可用 env 覆盖)。APPEND_TO 续跑 (崩溃后接着跑同一套) 不受此限——否则第 1 晚 full 崩溃后无法续跑。
- **链排布 (AMENDMENT_01, M2/S1)**: 每格的 3 个主 build 和它的 s4 替补整格放在同一台机器上 (替补账本按机，跨机替补不可能)，make_chains.py 里有 assert 自检。**内标按条件同机 (K 12:24)**: 同一条件的 MC3H 和 MC3 全在同一台机——C1→k03，C2 (hii+lam)→k04，C3 (仅 full) 按负载→k03；替补跟格走。同条件同臂同轮次的 MC3H/MC3 成一对，整对进同一槽、在链尾相邻，链尾严格交替 (A 槽对内 MC3H 先、B 槽 MC3 先)，所以无论哪台机变慢、链尾被截掉几条，同一条件下 MC3H 与 MC3 丢的条数之差 ≤1，Δ 不与机器绑定。尺子格规则不变 (整格同机、每槽最多 2 条、槽内在前)，分机在内标负载之上按格时长贪心，以均衡负载 (缩减版因此 k03 4 个尺子格、k04 2 个)。make_chains.py 的 assert 自检: 整格同机、替补同机、同条件内标同机、链尾成对交替且两边条数相等。
- 两个包只在 chains/ 与 VARIANT 上不同，其余文件逐字相同。
- 每格都跑 4 个体系 DOPE/DOPC/MC3H/MC3，n=3 (s1–s3)，s4 只作替补。不加新种子。
- 320 K 片层臂复用 D1v2 (inputs/D1v2_lam_runs.tsv，已冻结)，不重跑。350 K 片层臂 (C2) 是新跑的。
- 压力耦合不扫。命门 (规则 2) 失败 → 走 B1 (350 K 续 2 µs)，B1 另立包，不在本包内。共存起点补丁也另立。

## 2 流水线 (每个 build)
relax 15 ns (crescale_dev，写 trr) → 对末 5 ns 逐帧过起点闸，取最后一个合格帧 (hii 用 t0_gate_hii --level relax L2，lam 用 t0_gate_launch prod0) → prod 400 ns (两臂相同，D1v2 协议原样: dt 20 fs，c-rescale semiiso τp=4 nstpcouple=5，v-rescale，xtc 每 1 ns)。第 2–3 晚在主条件上再续到 1.2 → 2 µs，不在本包内。
- H_II 臂可评估: prod 观测 ≥400 ns 且最后 100 ns 判定窗帧数 ≥99；不满足记 TRUNC / WINDOW_INCOMPLETE (不可评估，不用替补顶)。片层臂同 D1v2: 截断前出现主事件也算 EVENT，无事件须观测 ≥400 ns (PREREG §9)。
- 闸不合格 = VOID_L2，不算事件也不算删失，不进 prod，记入替补账本，由同格 s4 替补。RELAX_FAIL 同样处理。替补只看起点读数，不看 prod 结果。
- DOPC_h050_T350_hii_s2 在 L1 是 VOID_BUILD (min_intermol 0.296)，已写入 HIST_BAN，它的 s4 已顶进主链。**该格 (DOPC C2 hii) 没有剩余替补**：再有 1 个 VOID_L2 / RELAX_FAIL 该格就 n<3，按 PREREG 记 NOT_EVALUABLE (run_R4N1.sh 会记 NO_SPARE)。
- 与 R2a 的偏差: Lz 规则改为按管内每脂面积 a_w≈0.60 nm² (0.50–0.70) 取 Lz，不沿用 R2a 的 Lz=12 (PREREG §44 行，列入审查清单)；h100 的 Lz 仅 6.16 nm。prod/relax mdp 里的过时注释已在 AMENDMENT_01 (S6) 中改正，只改注释，非注释内容逐字未变 (已比对；改后 grompp 重跑见 proof/grompp_box_amend01.tsv)。

## 3 运行
```
# Spark 上 (包放在 $HOME 下，gate_py_container 只挂 $HOME 和 /tmp):
cd ~/R4N1_full                        # 或 ~/R4N1_reduced
CHECK=1 bash run_R4N1.sh k03          # 只跑发车判据 (含 60 s 复查)，不建目录/不起 MPS
DRY=1   bash run_R4N1.sh k03          # 只打印计划和时间判断
GATE_PY=$PWD/gatewrap/gate_py_container.sh bash run_R4N1.sh k03   # 正式; k04 同理
APPEND_TO=$HOME/R4N1/R4N1_run_k03_<TS> bash run_R4N1.sh k03     # 中断后续跑 (DONE 跳过，TRUNC 用 -noappend 续)
```
- 幂等: 同一台机已有 $J/R4N1_run_<机>_* 时，默认 ABORT；要续跑设 APPEND_TO，确要另起一套设 NEW_RUN=1。attempt 目录 mkdir 原子创建，STATUS 只写一次，ALL_RECORDS.tsv 只追加，不覆写，不 rm。
- MD_DEADLINE = 2026-10-31 07:30 +0800 (DEADLINE 默认值)。prod 的 -maxh 按剩余时间截断，截断记 TRUNC (按 PREREG §9 处理)。

## 4 MPS 规则: 残留先认人再 quit
- launch_guard 发现 MPS 残留会直接 FAIL，并列出 owner/pid/ppid/etime/args/pipe。
- 先 `bash tools/mps_residue.sh` 只读报告。确认是自己的残留后，再 `QUIT=1 bash tools/mps_residue.sh`；只有 owner=$USER、pipe 在 $HOME/mps_R4*、且没有 gmx 在跑时才会 quit。
- **不 kill，不删目录。** 别人的 MPS 或独占显存需求一律报 K，独占显存/重启须 K 批。
- 每次运行用新的 MPSROOT=$HOME/mps_R4N1/<机>_<TS>，目录已存在就 ABORT。退出时只 quit 自己的 pipe，并把之后的状态写入 mps_after_quit.txt。

## 5 回传与判读
- 回传: 每个 build 的 prod.xtc + prod.tpr + gate/select 记录，以及 ALL_RECORDS.tsv、RUN_META，附 SHA256_out.txt (在 Spark 上生成)。不回传 trr。
- 判读 (需要带 MDAnalysis 的 python):
```
python3 verdict_R4_3day.py collect --inputs inputs --out V <R4N1_run_k03_*> <R4N1_run_k04_*>
python3 verdict_R4_3day.py judge --d1v2-lam inputs/D1v2_lam_runs.tsv V
```
- 测试: `python3 tests/test_verdict.py` (19 项; AMENDMENT_01 加了 2 项: 两起点都 VOID → NOT_EVALUABLE；一 VOID 一 LOST → NEITHER)。片层判读已在 D1v2 真实数据上复现 18/18 (proof/verdict_realdata/)。

- **双 VOID (AMENDMENT_01, M1)**: 某格某体系两个起点臂都 VOID 时，phase_class 记 NOT_EVALUABLE (原 §5 写 NEITHER，与 §9.7 矛盾，取更严读法)。
- **F1 的读法 (S7)**: verdict 的 F1 只在“所有已跑条件、到最长时长，DOPC_hii 的规则 2 都是 FAIL”时触发；只要有一个条件的规则 2 是 NOT_EVALUABLE，F1 就不触发，该条件单独报“不可评估”。这是 PREREG §F1 “都不满足规则 2”的两种读法中的一种，冻结的 verdict 一直这样实现，本次只是写明，不改判据。

## 6 主要 env (默认值见 lib_R4N1.sh)
| env | 默认 | 说明 |
|---|---|---|
| MODE | docker | local 只用于 box 冒烟 |
| EXPECT_GMX | 2026.3 | box 冒烟用 any |
| IMG | ghcr.io/novomcp/gromacs-md:spark | |
| GATE_PY | python3 | Spark 上用 gatewrap/gate_py_container.sh |
| J | $HOME/R4N1 | 输出根目录 |
| DEADLINE | 2026-10-31 07:30 +0800 | |
| NT / PINA / PINB | 5 / 15 / 5 | 两槽线程数与 pin |
| PERF_NOM @ PERF_REF_BEADS | 14258 @ 15420 | 估时用 (估计，非实测) |
| SEL_WIN_PS / SEL_NSTOUT | 5000 / 5000 | 起点选帧窗口与 trr 输出间隔 |
| SEL_KEEP_FRAMES | 1 | AMENDMENT_01 (S5): 不删任何帧；逐帧闸门的每次重试单独写 f<i>_try<n>.json/.out，不再 rm。每台机多占约 3 GB (估算)，磁盘门槛 5→10 GiB |
| HIST_BAN | R4N1_DOPC_h050_T350_hii_s2 | |
| NEW_RUN / APPEND_TO | 空 | 幂等开关 |
| NSTEPS_OVERRIDE_RELAX/PROD | 空 | 只允许 MODE=local |

## 7 已知局限 (K1, 须 K 知情，不改包)
- H_II 管长 Lz 短于水通道的 Rayleigh–Plateau 不稳定波长下限 2πr (估算): h100 Lz 6.16 nm vs 2πr≈21.8 nm (r_water 3.47)；h050 Lz 10.97 nm vs 2πr≈11.6 nm (r_water 1.84)。周期边界下水管“无限长”，但波长大于 Lz 的起伏和珠串被禁掉，结果偏向 H_II RETAIN。
- 后果: 规则 2 (DOPC 须 LOST ≥2/3) 更难过，尤其 C3 (h100)；方向偏向尺子 FAIL，是保守的，不会造成假 PASS。MC3 与 MC3H 同受影响，但 Δ 的灵敏度下降。full 比 reduced 多出的正是 C3。
- Lz 是 PREREG §2 冻结规则，本包照做；判读报告里须写明这一局限。
- (撤回上一版此条: 原“MC3 全在 k03、MC3H 全在 k04”的排布已按 K 12:24 改掉。) 现在同一条件的 MC3H/MC3 同机、链尾成对交替；剩下的局限是不同条件分在不同机上，机器差异会让 C1 与 C2 被截断的程度不同 (跨条件比较本来不做 Δ 合并，判读时仍看 TRUNC 分布)。

## 8 未在 Spark/2026.3 上实测
H_II 臂的 trr + 逐帧 L2 闸、350 K mdp、新的 MPS 规则、convert-tpr (留到第 2 晚)。box 上 (gmx 2025.4) 已通过 grompp 126/126 和本地短冒烟 (见 proof/)。
