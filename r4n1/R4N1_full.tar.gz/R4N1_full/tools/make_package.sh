#!/bin/bash
# make_package.sh <full|reduced> <chains_dir> <out_pkg_dir>  -- 组装 R4N1 发车包 (只读 N1/, 只写 <out_pkg_dir>; 目标已存在则拒绝, 不覆盖).
# 输入只带链/替补/补跑里出现的 build; 每个 build 只带运行需要的文件 + 构建审计文件; 力场 itp 在 inputs/ff/ 存一份, 各 build 目录内为硬链接 (tar 保留硬链接, 解包后 sys.top 相对 #include 照常可用).
set -eu
V=${1:?full|reduced}; CH=${2:?chains_dir}; P=${3:?out_pkg_dir}
N1=$(cd "$(dirname "$0")/.." && pwd); D2=$(dirname $N1); D1V2_RUNS=/workspace/lnp-md/scan/R4_recipe/D1v2_results_pull/results_xtc_prereg/runs.tsv
[ -e "$P" ] && { echo "REFUSE: $P 已存在 (不覆盖)"; exit 1; }
mkdir -p "$P"; cd "$P"
cp $N1/run_R4N1.sh $N1/lib_R4N1.sh $N1/verdict_R4_3day.py $N1/README_R4N1.md .; cp $D2/PREREG_R4_3day.md $D2/PRE_REG_AMENDMENT_R4N1_01.md $D2/PLAN_R4_3day.md .
echo $V > VARIANT
mkdir gate gatewrap mdp tools tests proof chains inputs inputs/ff
cp $N1/gate/*.py gate/; cp $N1/gatewrap/*.sh gatewrap/; cp $N1/mdp/*.mdp mdp/; cp $N1/tools/* tools/; cp $N1/tests/*.py tests/
cp -r $N1/proof/grompp_box $N1/proof/readout_validation $N1/proof/verdict_realdata proof/; cp $N1/proof/*.tsv $N1/proof/*.txt $N1/proof/neg_selftest_bridged.gro proof/
cp $CH/*.txt $CH/PLAN_ESTIMATE.json chains/
cp $N1/inputs/L1_summary.tsv inputs/; cp $D1V2_RUNS inputs/D1v2_lam_runs.tsv; cp $N1/inputs/ff/*.itp inputs/ff/
for b in $(cat chains/*.txt | grep -vE '^\s*(#|$)' | awk '{print $1}' | sort -u); do
  s=$N1/inputs/$b; [ -s $s/start.gro ] || { echo "ERR: 缺 $s/start.gro"; exit 1; }; mkdir inputs/$b
  for x in start.gro sys.top index.ndx expect.env counts.txt SYSTEM.txt t0_builder.json preasm.json build.log relax_crescale_dev.mdp prod_hii.mdp prod_lam.mdp genconf.log; do [ -e $s/$x ] && cp $s/$x inputs/$b/; done
  for x in $s/*.itp; do n=$(basename $x); cmp -s $x inputs/ff/$n || { echo "ERR: $b/$n 与 ff 不同"; exit 1; }; ln inputs/ff/$n inputs/$b/$n; done
done
# 冻结 sha (判读脚本 + PREREG + 复用的 D1v2 片层臂表)
sha256sum verdict_R4_3day.py PREREG_R4_3day.md PRE_REG_AMENDMENT_R4N1_01.md inputs/D1v2_lam_runs.tsv > FROZEN_sha256.txt
# MANIFEST: 包内全部文件 (不含 MANIFEST 自身)
find . -type f ! -name MANIFEST_sha256.txt | sed 's#^\./##' | LC_ALL=C sort | xargs sha256sum > MANIFEST_sha256.txt
echo "OK $P files=$(wc -l < MANIFEST_sha256.txt) builds=$(ls -d inputs/R4N1_* | wc -l)"
