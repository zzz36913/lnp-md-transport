#!/bin/bash
# 幂等: 已有 start.gro + SYSTEM.txt 的 build 跳过. 用法: bash tools/build_all.sh [并行数]
D=$(cd "$(dirname "$0")/.." && pwd); P=${1:-8}
{ for s in DOPE DOPC MC3H MC3; do for k in 1 2 3 4; do
   echo "$s 50 320 hii $k"; echo "$s 100 320 hii $k"; echo "$s 50 350 hii $k"; echo "$s 50 350 lam $k"; done; done; } |
xargs -P $P -L 1 bash -c 'n=$(printf "R4N1_%s_h%03d_T%d_%s_s%d" $0 $1 $2 $3 $4); o='"$D"'/inputs/$n; [ -s $o/start.gro ] && [ -s $o/SYSTEM.txt ] && { echo "SKIP $n"; exit 0; };
  python3 '"$D"'/tools/build_R4N1.py --prim $0 --tier $1 --temp $2 --arm $3 --seed-id $4 -o $o --ntomp 2 > /dev/null 2>$o.err; rc=$?; echo "rc=$rc $n"; [ $rc = 0 ] && rm -f $o.err'
