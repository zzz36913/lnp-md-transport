#!/usr/bin/env python3
"""生成 chains_full/ 与 chains_reduced/ (k03_A k03_B k04_A k04_B + spares_<机> + supp_<机>(空)). 规则 (看数据前定死):
 - 主种子 s1-s3; L1 VOID_BUILD 的主种子由同格 s4 直接顶上进主链 (PREREG §2: 替补只在主种子 VOID 时顶上), 该格无剩余替补.
 - 分机/分槽/槽内顺序见 plan() 注释 (AMENDMENT_01: 整格同机; 尺子在前、内标在链尾; 01b: 同条件 MC3H/MC3 同机、链尾成对交替; 轮内 C1 > C3 > C2).
 - 替补 s4: 与该格 3 个主种子同机 (整格分机, 见 plan() 注释; AMENDMENT_01 M2). 旧规则 "放在主种子较多的那台机" 作废 (REVIEW_R4N1 M2: s3 够不着替补).
 - 时长估算 (估算): P = D1v2 实测各体系×水合 prod 速率最小值 (同 D2/capacity_R4_3day.py 表 R; 同组成同珠数, H_II 盒形不同, 350 K 未实测);
   need = 15/(0.65P)*24 + 0.05 + 400/P*24 h (0.05 h = select/闸门/grompp 开销; D1v2 k03 ALL_RECORDS 实测单条 400 ns DOPE h050 约 43 min 与此式相符). MC3 lam@350K 预期 VOID_L2 (D1v2 10/10), 按满时长计 (保守), 另报 VOID 时的时长."""
import glob, json, os, re
D = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); INP = D + '/inputs'
L1 = {l.split('\t')[0]: l.split('\t')[2] for l in open(INP + '/L1_summary.tsv').read().splitlines()[1:]}
def beads(b): return int(re.search(r'beads=(\d+)', open('%s/%s/SYSTEM.txt' % (INP, b)).read()).group(1))
R = {('DOPE','h050'):14428,('DOPC','h050'):14258,('MC3H','h050'):13398,('MC3','h050'):13398,
     ('DOPE','h100'):13998,('DOPC','h100'):12927,('MC3H','h100'):12282,('MC3','h100'):12282}
def need(b, void=False):
    _, s, h = b.split('_')[:3]; P = R[(s, h)]; r = 15 / (0.65 * P) * 24 + 0.05
    return r if void else r + 400 / P * 24
CONDS = {'C1': [('h050', 'T320', 'hii')], 'C2': [('h050', 'T350', 'hii'), ('h050', 'T350', 'lam')], 'C3': [('h100', 'T320', 'hii')]}
SYS = ['DOPC', 'DOPE', 'MC3H', 'MC3']; SLOTS = ['k03_A', 'k03_B', 'k04_A', 'k04_B']; RULER = ('DOPC', 'DOPE'); PRIO = {'C1': 0, 'C3': 1, 'C2': 2}
# AMENDMENT_01 / REVIEW_R4N1 M2+S1 (K 12:14) + AMENDMENT_01b (K 12:24: 内标不与机器绑定):
#  - 以"格" (体系 x 水合 x 温度 x 臂) 为单位整格分机: 一格的 3 个主种子 + s4 替补都在同一台机 (替补账本按机, 跨机够不着);
#  - 内标 (MC3H/MC3) 按"条件"整体分机: 同一条件 (含 C2 的 hii+lam 两臂) 的 MC3H 与 MC3 全在同一台机 -> Δ 的两边不跨机;
#    IS_MACH 固定 C1->k03, C2->k04; C3 (仅 full) 放内标负载较小的机 (= k03, C1 6 条 < C2 12 条). 替补跟格走.
#  - 内标按"对"排: 同条件同臂同轮次 r 的 (MC3H, MC3) 为一对, 一对整对进同一槽且在链尾相邻; 对按负载贪心分 A/B (同一单元每槽最多 2 对).
#    槽内内标严格交替; A 槽对内 MC3H 在前, B 槽对内 MC3 在前 (链尾截断时两边丢的条数之差 <=1, 且两槽方向相反).
#  - 尺子格 (DOPC/DOPE): 规则不变 (整格同机, 每槽最多 2 条); 分机改为在内标负载之上按格时长降序贪心 (负载均衡), 不再强求两机格数相等.
#  - 槽内顺序: 尺子全部在前 (轮次 s1->s3, 轮内 C1 > C3 > C2, 再体系、臂 hii 先), 内标对在链尾 (同样按轮次 -> 条件 -> 臂).
IS = ('MC3H', 'MC3'); IS_MACH = {'C1': 'k03', 'C2': 'k04'}
def plan(conds):
    cells = [(c, s, h, t, a) for c in conds for (h, t, a) in CONDS[c] for s in SYS]
    prim = {}; spare = {}
    for c, s, h, t, a in cells:
        key = (c, s, h, t, a); nm = lambda k: 'R4N1_%s_%s_%s_%s_s%d' % (s, h, t, a, k)
        ok = [k for k in (1, 2, 3) if L1.get(nm(k)) == 'PASS']; sp = [k for k in (4,) if L1.get(nm(k)) == 'PASS']
        while len(ok) < 3 and sp: ok.append(sp.pop(0))
        prim[key] = [nm(k) for k in ok]; spare[key] = [nm(k) for k in sp]
    cl = lambda key: sum(need(b) for b in prim[key])
    # 1 内标按条件分机
    cmach = {}; ml = {'k03': 0.0, 'k04': 0.0}
    for c in [c for c in ('C1', 'C2', 'C3') if c in conds]:
        m = IS_MACH.get(c) or min(('k03', 'k04'), key=lambda mm: (ml[mm], mm)); cmach[c] = m
        ml[m] += sum(cl(k) for k in cells if k[0] == c and k[1] in IS)
    mach = {k: cmach[k[0]] for k in cells if k[1] in IS}
    # 2 尺子格分机: 在内标负载之上按格时长降序贪心
    for key in sorted([k for k in cells if k[1] in RULER], key=lambda k: (-cl(k), cells.index(k))):
        m = min(('k03', 'k04'), key=lambda mm: (ml[mm], mm)); mach[key] = m; ml[m] += cl(key)
    load = {x: 0.0 for x in SLOTS}; where = {}; meta = {}
    # 3 内标对分槽 (整对), 单元 = (条件, 水合, 温度, 臂)
    units = sorted({(k[0], k[2], k[3], k[4]) for k in cells if k[1] in IS}, key=lambda u: (PRIO[u[0]], u[3] != 'hii'))
    for u in units:
        m = cmach[u[0]]; n_in = {'A': 0, 'B': 0}; kh = (u[0], 'MC3H') + u[1:]; km = (u[0], 'MC3') + u[1:]
        assert len(prim[kh]) == len(prim[km]) == 3
        for r in range(3):
            pr = (prim[kh][r], prim[km][r]); pl = sum(need(b) for b in pr)
            cand = [x for x in ('A', 'B') if n_in[x] < 2]; x = min(cand, key=lambda y: (load['%s_%s' % (m, y)], y)); n_in[x] += 1; sl = '%s_%s' % (m, x)
            for q, b in enumerate(pr):
                where[b] = sl; load[sl] += need(b)
                first = 0 if (q == 0) == (x == 'A') else 1   # A: MC3H 先; B: MC3 先
                meta[b] = (1, r, PRIO[u[0]], u[3] != 'hii', first)
    # 4 尺子格分槽 (规则不变: 每槽最多 2 条, 按负载贪心)
    for key in sorted([k for k in cells if k[1] in RULER], key=lambda k: (-cl(k), cells.index(k))):
        m = mach[key]; n_in = {'A': 0, 'B': 0}
        for r, b in enumerate(prim[key]):
            cand = [x for x in ('A', 'B') if n_in[x] < 2]; x = min(cand, key=lambda y: (load['%s_%s' % (m, y)], y))
            n_in[x] += 1; sl = '%s_%s' % (m, x); where[b] = sl; load[sl] += need(b)
            meta[b] = (0, r, PRIO[key[0]], SYS.index(key[1]), key[4] != 'hii')
    chain = {x: sorted([b for b in where if where[b] == x], key=lambda b: meta[b]) for x in SLOTS}
    spares = {'k03': [], 'k04': []}
    for key in sorted(cells, key=lambda k: (k[1] not in RULER, PRIO[k[0]], k[4] != 'hii', SYS.index(k[1]))):
        for b in spare[key]: spares[mach[key]].append(b)
    # ---- 自检 (AMENDMENT_01 M2 + AMENDMENT_01b) ----
    sysof = lambda b: b.split('_')[1]; cellof = lambda b: b.rsplit('_', 1)[0]
    for key in cells: assert all(where[p].startswith(mach[key]) for p in prim[key])   # M2: 整格同机 (主种子)
    for m in ('k03', 'k04'):
        for b in spares[m]: assert any(b in spare[k] and mach[k] == m for k in cells)   # M2: 替补与其格同机
    for c in conds:   # 01b-1: 同一条件的 MC3H 与 MC3 (主 + 替补) 全在同一台机
        ms = {where[b][:3] for k in cells if k[0] == c and k[1] in IS for b in prim[k]} | {m for m in spares for b in spares[m] if b.split('_')[1] in IS and any(b in spare[k] and k[0] == c for k in cells)}
        assert len(ms) == 1, (c, ms)
    for x in SLOTS:   # 01b-2: 链尾 = 全部内标, 严格交替, 相邻两条为同条件同臂同轮次的 MC3H/MC3 一对, 两边条数相等
        ch = chain[x]; isx = [i for i, b in enumerate(ch) if sysof(b) in IS]
        assert isx == list(range(len(ch) - len(isx), len(ch))), (x, '内标不在链尾')
        tail = [ch[i] for i in isx]; assert len(tail) % 2 == 0
        assert all(sysof(tail[i]) != sysof(tail[i + 1]) for i in range(len(tail) - 1)), (x, '内标未严格交替')
        for i in range(0, len(tail), 2):
            a, b = tail[i], tail[i + 1]; assert a.split('_')[2:5] == b.split('_')[2:5], (x, a, b)
            ka = [k for k in cells if a in prim[k]][0]; kb = [k for k in cells if b in prim[k]][0]
            assert ka[0] == kb[0] and ka[2:] == kb[2:] and prim[ka].index(a) == prim[kb].index(b), (x, a, b)
        assert sum(sysof(b) == 'MC3H' for b in tail) == sum(sysof(b) == 'MC3' for b in tail)
    return chain, load, spares, prim
for tag, conds in (('full', ['C1', 'C2', 'C3']), ('reduced', ['C1', 'C2'])):
    chain, load, spares, prim = plan(conds); od = '%s/chains_%s' % (D, tag); os.makedirs(od, exist_ok=True)
    hdr = '# R4N1 %s (%s) 主链, 文件顺序=本槽执行顺序; 由 tools/make_chains.py 生成 (规则见该文件 docstring). 估算槽时 %.2f h (估算, 非实测)\n'
    for x in SLOTS: open('%s/%s.txt' % (od, x), 'w').write(hdr % (tag, '+'.join(conds), load[x]) + ''.join(b + '\n' for b in chain[x]))
    for m in ('k03', 'k04'):
        open('%s/spares_%s.txt' % (od, m), 'w').write('# R4N1 %s L2 替补 (按格; 只在同格主种子 VOID_L2/relax 失败时领取; 只看起点读数)\n' % tag + ''.join(b + '\n' for b in spares[m]))
        open('%s/supp_%s.txt' % (od, m), 'w').write('# R4N1 %s 补跑队列: 空 (严格 n=3, 不加新种子)\n' % tag)
    nvoid = sum(1 for x in SLOTS for b in chain[x] if '_MC3_' in b and '_lam_' in b)
    tot = sum(load.values()); tv = tot - sum(need(b) - need(b, True) for x in SLOTS for b in chain[x] if '_MC3_' in b and '_lam_' in b)
    summ = dict(tag=tag, conds=conds, n_primary=sum(len(chain[x]) for x in SLOTS), n_spare=sum(len(v) for v in spares.values()),
                slot_h={x: round(load[x], 2) for x in SLOTS}, total_slot_h=round(tot, 2), longest_slot_h=round(max(load.values()), 2),
                total_slot_h_if_MC3lam_void=round(tv, 2), n_MC3_lam=nvoid, note='估算: D1v2 实测 prod 速率 (各体系最小值), f=1.0; f=0.9 时约 x1/0.9; 350 K 与 H_II 盒形未实测')
    json.dump(summ, open('%s/PLAN_ESTIMATE.json' % od, 'w'), indent=1, ensure_ascii=False); print(json.dumps(summ, ensure_ascii=False))
