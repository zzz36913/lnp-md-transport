# R2a 包 (方案 C, n=2, 5 臂 × 2 种子 = 10 条, 16 µs) — 零 GPU 已验, 未在 Spark 上试跑
来源: /workspace/lnp-md/scan/R2a (box 生成)。不上传、不连 Spark 由调度/K 决定。预注册见 dd/56_R2a_prereg.md。

## 布局 (解压到 $HOME/R2a)
- starts/<名>/ : sys.gro sys.top index.ndx(Solvent=W+CL+NA, Rest=脂) em/eq1/eq2/prod.mdp itps SYSTEM.txt counts.txt preasm.json
- scripts/run_R2a.sh (单 run: EM→eq1→eq2→prod, 由 j009 run_j009.sh sed 派生), R2a_slot.sh (一个槽按 chain 顺序跑), R2a_machine.sh (起 MPS + 两槽并行)
- chains/{k03,k04}_{A,B}.txt ; JOBLIST_R2a_T0_1900.tsv / _2000.tsv (est_start/est_end, 估算)
- verdict_R2a.py (读数; 依赖 box 上 /workspace/lnp-md/scan/verdict_j009.py 与 scan/ana, 在 box/本机跑, 不在 Spark 跑)
- MANIFEST_sha256.txt ; prod_mdout_DOPE_lam_s1.mdp (box gmx 2025.2 grompp 回写的实际 mdp, 内含 rlist=1.35)

## 发车 (每机一条命令; MPS 目录 $HOME/mps_R2a 必须为空/不存在)
  cd $HOME/R2a && sha256sum -c MANIFEST_sha256.txt
  DRY=1 bash scripts/R2a_machine.sh k03     # 先干跑看 chain/时间
  nohup bash scripts/R2a_machine.sh k03 > R2a_k03.log 2>&1 &      # k04 机同理, 把 k03→k04 (k03=seed1, k04=seed2)
槽 A(pin 15)=DOPE_lam→MC3H_lam; 槽 B(pin 5)=DOPC_lam→DOPE_hii→DOPC_hii。每 run 带 -maxh=min(99, 余时−0.35h), 截止 2026-10-28 07:30 (SGT); 余时<0.6 h 的 run 跳过(SKIP_NO_TIME); 状态写 $HOME/R2a/slots/<tag>.tsv (DONE|TRUNC|TRUNC_TIMEOUT|FAIL|SKIP_NO_TIME)。
最晚发车 T0≈19:00 (估算; 8100 ns/天/条 估算, eq+EM 0.22 h/条 估算)。MC3H_lam 现为 7 w/l(1701 W, 14337 珠; K 18:30 改, DOPE/DOPC 仍 3 w/l; 纯 MC3H 非 Kjølbye 的 MC3/KC2+DSPC/CHOL 组成, 见 dd/56), 速率按珠数线性缩放≈7002 ns/天 (估算, 未实测): T0=19:00 被 -maxh 截到≈1779 ns(89%), T0=20:00 ≈74%, DOPC_hii≈66% (估算)。DEADLINE 默认带 +0800; 4 个审查补丁(S1-S4)已应用, 见 scan/R2a/CHANGELOG_mc3h_7wl.md。

## 已知风险 / 未核
1. R2a_slot.sh / R2a_machine.sh 只在 box 上 DRY 与本地 CPU 烟测过, 未在 Spark+MPS 上试跑 (未核)。
2. grompp/EM 在 box 的 gmx 2025.2-Debian 上验; Spark 镜像是 gmx 2026.3, 版本差异未核。
3. 速率 8100 ns/天/条 来自 RUNBOOK §86 (PERF-05), 非本体系实测。
4. 调度前须 GLM 已停且 8888/18888 已释放 (K 决定; 我没碰)。
