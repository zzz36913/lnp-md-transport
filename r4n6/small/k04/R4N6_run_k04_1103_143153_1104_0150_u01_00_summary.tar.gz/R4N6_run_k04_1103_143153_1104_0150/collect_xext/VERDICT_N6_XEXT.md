# R4N6 XEXT 判读 (R4N5 360K 续到 3000 ns; 单独判读)

- 总判 **NOT_EVALUABLE** (冻结规则, 视界 3000 ns, 满窗 T_obs>=2999)
  - DOPE: 规则 P = NOT_EVALUABLE; state=NOT_RUN n_eval=0 n_event=0 n_merge=0; runs=[]; notes=['s1 缺', 's2 缺', 's3 缺']
  - DOPC: 规则 N = NOT_EVALUABLE; state=NOT_EVALUABLE n_eval=2 n_event=0 n_merge=0; runs=['R4N1_DOPC_h100_T360_lam_s502:NO_EVENT', 'R4N1_DOPC_h100_T360_lam_s503:NO_EVENT']; notes=['替补 s4 也 VOID_L2', 's1 VOID_L2 无可用替补']

描述列 (不进门): build | ncl_t0 | ncl_min | ncl_min_1200_3000 | frac_ncl1_1200_3000 | Cz_0_50 | Cz_1150_1200 | Cz_last50 | dCz_ext | Cz_min_20ns | t_Cz_min_20ns
- R4N1_DOPC_h100_T360_lam_s502 | 2 | 2 | 2 | 0.0 | 1.2587 | 1.2518 | 1.2782 | 0.0264 | 1.1857 | 240.0
- R4N1_DOPC_h100_T360_lam_s503 | 2 | 2 | 2 | 0.0 | 1.2824 | 1.2571 | 1.2849 | 0.0278 | 1.1813 | 743.0
