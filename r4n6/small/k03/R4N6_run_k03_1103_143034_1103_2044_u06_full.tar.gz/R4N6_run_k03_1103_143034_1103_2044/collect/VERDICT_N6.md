# R4N6 判读 (1200 ns 视界)

- ANISO (Q1; T350 h100 档 6): 总判 **NOT_EVALUABLE**
  - DOPE: 规则 P = FAIL; state=EVALUABLE n_eval=3 n_event=0 n_merge=1; runs=['R4N1_DOPE_h100_T350_lam_s604:NO_EVENT', 'R4N1_DOPE_h100_T350_lam_s602:NO_EVENT', 'R4N1_DOPE_h100_T350_lam_s605:NO_EVENT']; notes=['s1 VOID_L2 -> 替补 s4', 's3 VOID_L2 -> 替补 s5']
  - DOPC: 规则 N = NOT_EVALUABLE; state=NOT_RUN n_eval=0 n_event=0 n_merge=0; runs=['R4N1_DOPC_h100_T350_lam_s601:NOT_RUN', 'R4N1_DOPC_h100_T350_lam_s602:NOT_RUN', 'R4N1_DOPC_h100_T350_lam_s603:NOT_RUN']; notes=[]
  - 400 ns 描述 (不进门): DOPE n_event=0, DOPC n_event=0
- H050 (Q2a; T350 h050 档 5): 总判 **NOT_EVALUABLE**
  - DOPE: 规则 P = NOT_EVALUABLE; state=NOT_EVALUABLE n_eval=1 n_event=0 n_merge=1; runs=['R4N1_DOPE_h050_T350_lam_s501:NO_EVENT', 'R4N1_DOPE_h050_T350_lam_s503:SHA_MISMATCH']; notes=['替补 s4 也 VOID_L2', '替补 s5 也 VOID_L2', 's2 VOID_L2 无可用替补']
  - DOPC: 规则 N = NOT_EVALUABLE; state=NOT_RUN n_eval=0 n_event=0 n_merge=0; runs=['R4N1_DOPC_h050_T350_lam_s501:NOT_RUN', 'R4N1_DOPC_h050_T350_lam_s502:NOT_RUN', 'R4N1_DOPC_h050_T350_lam_s503:NOT_RUN']; notes=[]
  - 400 ns 描述 (不进门): DOPE n_event=0, DOPC n_event=0
- NEXT (Q2a+ 补位 (单独判读); T360 h050 档 5): 总判 **NOT_EVALUABLE**
  - DOPE: 规则 P = NOT_EVALUABLE; state=NOT_RUN n_eval=0 n_event=0 n_merge=0; runs=['R4N1_DOPE_h050_T360_lam_s501:NOT_RUN', 'R4N1_DOPE_h050_T360_lam_s502:NOT_RUN', 'R4N1_DOPE_h050_T360_lam_s503:NOT_RUN']; notes=[]
  - DOPC: 规则 N = NOT_EVALUABLE; state=NOT_RUN n_eval=0 n_event=0 n_merge=0; runs=['R4N1_DOPC_h050_T360_lam_s501:NOT_RUN', 'R4N1_DOPC_h050_T360_lam_s502:NOT_RUN', 'R4N1_DOPC_h050_T360_lam_s503:NOT_RUN']; notes=[]
  - 400 ns 描述 (不进门): DOPE n_event=0, DOPC n_event=0
