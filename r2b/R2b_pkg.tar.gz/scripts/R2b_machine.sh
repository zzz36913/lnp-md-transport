#!/bin/bash
# R2b_machine.sh -- 一台 Spark: 起一个用户态 MPS 守护 (同 j009_pair2.sh: nvidia-cuda-mps-control -d, MPSROOT 须不存在/空), 并行跑两个槽 (A: pin offset 15, B: pin offset 5, 各 -ntomp 5), 全部结束后 quit MPS.
# 用法: DRY=1 bash R2b_machine.sh <k03|k04>   (chain 文件 $J/chains/<机>_A.txt, <机>_B.txt)
# R2b 相对 R2a 的改动: 仅 R2a→R2b 改名 + 两处守卫 (MPSROOT 不得含 mps_R2a; 有 gmx 进程则 ABORT, ALLOW_BUSY=1 可覆盖)。
# env: J=$HOME/R2b MPSROOT=$HOME/mps_R2b DEADLINE="2026-10-28 07:30" NT=5  PINA=15 PINB=5  NOMPS=1(不起 MPS, 仅排障)
M=${1:?k03|k04}; J=${J:-$HOME/R2b}; MPSROOT=${MPSROOT:-$HOME/mps_R2b}; PINA=${PINA:-15}; PINB=${PINB:-5}
DEADLINE=${DEADLINE:-"2026-10-28 07:30 +0800"}   # 评审: 显式 +0800, 不依赖 Spark 的 TZ (Spark TZ 未核)
HERE=$(cd "$(dirname "$0")" && pwd); export J DEADLINE; mkdir -p $J/slots
CA=$J/chains/${M}_A.txt; CB=$J/chains/${M}_B.txt; [ -f $CA ] && [ -f $CB ] || { echo "ABORT: 缺 $CA 或 $CB"; exit 1; }
case $MPSROOT in *mps_R2a*) echo "ABORT: MPSROOT=$MPSROOT 含 mps_R2a (那是 R2a 的目录; R2b 须用新目录 \$HOME/mps_R2b)"; exit 1;; esac   # R2b 新增
if [ -n "$DRY" ]; then echo "== DRY machine=$M MPSROOT=$MPSROOT (不起 MPS/容器)"; DRY=1 bash $HERE/R2b_slot.sh $CA $PINA ${M}_A; DRY=1 bash $HERE/R2b_slot.sh $CB $PINB ${M}_B; exit 0; fi
if [ -z "$ALLOW_BUSY" ] && [ "$(pgrep -c gmx)" != 0 ]; then echo "ABORT: 已有 gmx 进程 $(pgrep -c gmx) 个 (R2a 还没跑完? pgrep -a gmx 查看; 确认无误可 ALLOW_BUSY=1)"; exit 1; fi   # R2b 新增: 接在 R2a 之后, 不抢占
if [ -z "$NOMPS" ]; then
  [ -z "$(ls -A $MPSROOT 2>/dev/null)" ] || { echo "ABORT: $MPSROOT 非空 (有 MPS 残留? 换新空目录)"; exit 1; }
  export MPSPIPE=$MPSROOT/pipe MPSLOG=$MPSROOT/log; mkdir -p $MPSPIPE $MPSLOG
  PRE_MPS=" $(pgrep nvidia-cuda-mps | tr '\n' ' ') "   # 评审: 记下起 MPS 前已有的 MPS 进程, 收尾只杀自己新起的
  CUDA_MPS_PIPE_DIRECTORY=$MPSPIPE CUDA_MPS_LOG_DIRECTORY=$MPSLOG nvidia-cuda-mps-control -d || { echo "ABORT: MPS 起不来"; exit 1; }
  sleep 3; pgrep -a nvidia-cuda-mps > $J/slots/${M}_mps_start.txt; echo "MPS started: $(cat $J/slots/${M}_mps_start.txt | tr '\n' ';')"
fi
bash $HERE/R2b_slot.sh $CA $PINA ${M}_A & PA=$!
bash $HERE/R2b_slot.sh $CB $PINB ${M}_B & PB=$!
wait $PA $PB
if [ -z "$NOMPS" ]; then echo quit | CUDA_MPS_PIPE_DIRECTORY=$MPSPIPE CUDA_MPS_LOG_DIRECTORY=$MPSLOG timeout 20 nvidia-cuda-mps-control > $J/slots/${M}_mps_quit.txt 2>&1
  sleep 2; for p in $(pgrep nvidia-cuda-mps); do case "$PRE_MPS" in *" $p "*) ;; *) kill $p 2>/dev/null;; esac; done; echo "MPS 已 quit; 剩余进程: $(pgrep -a nvidia-cuda-mps | tr '\n' ';')"; fi
echo "== machine $M done $(date '+%F %T')"; cat $J/slots/${M}_A.tsv $J/slots/${M}_B.tsv 2>/dev/null
