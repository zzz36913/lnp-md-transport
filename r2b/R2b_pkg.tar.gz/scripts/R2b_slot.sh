#!/bin/bash
# R2b_slot.sh (= R2a_slot.sh 仅改名 R2a→R2b) -- 一个 "槽" = 一条按顺序执行的链 (同一台机器, 与另一槽并行, 共用 R2b_machine.sh 起的一个 MPS 守护). 新文件 (j009 没有此形态: j009_pair2.sh 两条同起同止, 排不出 lam+lam / lam+HII+HII).
# 用法: DRY=1 bash R2b_slot.sh <chain文件> <pinoffset> [slot标签]
#   chain 文件每行: <体系名> <prod_nsteps(dt=20fs)>   (# 开头为注释), 例: R2b_DOPE_lam_s1 100000000
# env: J=$HOME/R2b  NT=5  DEADLINE="2026-10-28 07:30"(绝对, 到点前必须已 checkpoint 退出)  EQBUF_H=0.35(em+eq1+eq2 预留)  MINRUN_H=0.6(剩余不足则不开新条)  MAXH_CAP=99
#      MPSPIPE/MPSLOG (有则 run_R2b.sh 带 --ipc=host 与 MPS 挂载; 由 R2b_machine.sh 设)  MODE=local (box 冒烟)
# 每条: MAXH = min(MAXH_CAP, 剩余h - EQBUF_H) → run_R2b.sh 的 prod -maxh; 外层 timeout = 剩余秒 + 600 (TERM 触发 run_R2b.sh 的 trap docker stop -t 120).
# 状态写 $J/slots/<标签>.tsv: 体系 start end rc state(DONE|TRUNC|FAIL|SKIP_NO_TIME) laststep.  失败不重试, 继续下一条.
CH=${1:?chain file}; PINOFF=${2:?pinoffset}; TAG=${3:-$(basename $CH .txt)}
J=${J:-$HOME/R2b}; NT=${NT:-5}; EQBUF_H=${EQBUF_H:-0.35}; MINRUN_H=${MINRUN_H:-0.6}; MAXH_CAP=${MAXH_CAP:-99}
DEADLINE=${DEADLINE:-"2026-10-28 07:30 +0800"}; DL=$(date -d "$DEADLINE" +%s) || exit 1
HERE=$(cd "$(dirname "$0")" && pwd); mkdir -p $J/slots; ST=$J/slots/$TAG.tsv
if [ -n "$MPSPIPE" ]; then export MPSARGS="--ipc=host -v $MPSPIPE:$MPSPIPE -v $MPSLOG:$MPSLOG -e CUDA_MPS_PIPE_DIRECTORY=$MPSPIPE -e CUDA_MPS_LOG_DIRECTORY=$MPSLOG"; fi
say(){ echo "[$(date '+%F %T')] slot $TAG: $*" | tee -a $J/slots/$TAG.log; }
say "== start chain=$CH pinoffset=$PINOFF NT=$NT deadline=$DEADLINE EQBUF_H=$EQBUF_H DRY=${DRY:-0} MPSARGS=${MPSARGS:-none}"
grep -vE '^\s*(#|$)' $CH | while read -r SYS NST; do
  case $SYS in *[!A-Za-z0-9_]*|'') say "ABORT 非法名 $SYS"; continue;; esac
  now=$(date +%s); rem=$((DL-now)); remh=$(awk -v r=$rem 'BEGIN{printf "%.2f", r/3600}')
  ok=$(awk -v h=$remh -v m=$MINRUN_H 'BEGIN{print (h>=m)?1:0}')
  MH=$(awk -v h=$remh -v b=$EQBUF_H -v c=$MAXH_CAP 'BEGIN{x=h-b; if(x>c)x=c; printf "%.2f", x}')
  if [ "$ok" != 1 ]; then say "SKIP $SYS: 距 DEADLINE 只剩 ${remh}h < MINRUN_H=$MINRUN_H"; printf '%s\t-\t-\t-\tSKIP_NO_TIME\t-\n' $SYS >> $ST; continue; fi
  say "RUN $SYS prod_nsteps=$NST ($(awk -v n=$NST 'BEGIN{printf "%.0f",n*0.02/1000}') ns) remaining=${remh}h -> MAXH=$MH"
  if [ -n "$DRY" ]; then J=$J NT=$NT PINOFF=$PINOFF NSTEPS=$NST MAXH=$MH DRY=1 bash $HERE/run_R2b.sh $SYS < /dev/null 2>&1 | sed 's/^/    /'; continue; fi
  t0=$(date '+%F_%T'); to=$((rem+600))
  J=$J NT=$NT PINOFF=$PINOFF NSTEPS=$NST MAXH=$MH timeout -s TERM -k 180 $to bash $HERE/run_R2b.sh $SYS < /dev/null; rc=$?
  D=$J/starts/$SYS/out; ls=$(awk '/^ +Step +Time/{getline; s=$1} END{print s+0}' $D/prod.log 2>/dev/null)
  if [ $rc = 0 ] && [ "${ls:-0}" -ge "$NST" ]; then state=DONE; elif [ $rc = 0 ]; then state=TRUNC; elif [ $rc = 124 ] || [ $rc = 137 ]; then state=TRUNC_TIMEOUT; else state=FAIL; fi
  printf '%s\t%s\t%s\trc=%s\t%s\tlaststep=%s\n' $SYS $t0 "$(date '+%F_%T')" $rc $state $ls >> $ST; say "END $SYS rc=$rc state=$state laststep=$ls"
done
say "== chain end"
