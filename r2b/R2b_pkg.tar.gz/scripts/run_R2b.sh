#!/bin/bash
# run_R2b.sh -- R2b (dd/56) 单条体系 em -> eq1 -> eq2 -> prod. 由 j009 的 run_j009.sh (pkg 内, sha256 见 MANIFEST) 机械改出, 改动仅:
#   (1) 路径 J=$HOME/R2b, D=$J/starts/<名> (j009: $J/<名>); 容器名/日志名 j009->R2b;
#   (2) 4 处 grompp 加 -n ../index.ndx (tc-grps/comm-grps 用 Solvent/Rest 组);
#   (3) docker run 加 $MPSARGS (由 R2b_slot.sh/R2b_machine.sh 在 MPS 守护已起时设, = j009_pair2.sh dkcmd 的同款 --ipc=host + CUDA_MPS_* 挂载); 单机多槽并行 → 默认 SKIPPRE=1 (solo 预检不适用);
#   (4) NSTEPS/MAXH/PINOFF/NT 由调用方 (R2b_slot.sh) 按每条设置. 其余 (EM 闸 Fmax<1000, .done_/.failed_ 幂等, nan/LINCS 检查, 续跑 -cpi) 逐字沿用.
# R2b 相对 R2a 的改动: R2a→R2b 改名 + 新增 tau_p>=25*nstpcouple*dt 检查 (taup_check) ; 其余逐字同 run_R2a.sh。
# !! 未在 Spark 上实测 (只在 box 上 DRY/MODE=local 冒烟); 见 dd/56 R0 与 README_R2b.md 的风险项.
# run_j009.sh -- J009 阶段 A: 单个体系 em -> eq1 -> eq2 -> prod 400 ns (solo 一次一条). 蓝本: G2 的 g2_run.sh(prod 段原样) + J006 run_phase.sh(em/eq1/eq2 的 grompp/mdrun 顺序与 .done 标记).
# 用法:  DRY=1 bash run_j009.sh <system>     # 只打印, 不建 out/ 不起容器
#        bash run_j009.sh <system>            # 起跑; 被 -maxh 截断/中断后同命令再跑 = 从最后完成的步骤/prod.cpt 续跑; 已跑满只汇总退出
# <system> = ~/j009/<system>/ (fetch_j009.sh 装配好的目录, 含 sys.gro sys.top *.mdp 与全部 itp).  输出: ~/j009/<system>/out/
# env: J=$HOME/j009  NT=5 PINOFF=15 MAXH=1.8 NSTEPS=20000000(=400 ns@dt20fs) EM_FMAX_MAX=1000 IMG=ghcr.io/novomcp/gromacs-md:spark G=/usr/local/gromacs/bin/gmx
#      MINMEM=20(GiB) SKIPGPU=1(跳过 GPU 利用率检查) SKIPPRE=1(跳过整个 solo 预检) SI=30(gpu 采样秒)
#      冒烟测试专用(正式跑不要设): MODE=local(用本机 gmx, 不用 docker) GMX_LOCAL=gmx PINFLAGS=<覆盖钉核> GPUFLAGS=<覆盖> EQ_NSTEPS=<eq1/eq2 的 -nsteps 覆盖>
# 幂等: 每步 out/.done_<step>; 失败 -> out/.failed_<step> 并退出, 不重试(确认后删该文件再跑). 不碰 GLM/8888/18888, 只 stop 本脚本起的容器 j009_<system>_<pid>.
SYS=${1:?usage: bash run_R2b.sh <system>}
SKIPPRE=${SKIPPRE-1}
MPSARGS=${MPSARGS-}
case $SYS in *[!A-Za-z0-9_]*|'') echo "ABORT: system 名非法"; exit 1;; esac
J=${J:-$HOME/R2b}; D=$J/starts/$SYS; O=$D/out
IMG=${IMG:-ghcr.io/novomcp/gromacs-md:spark}; G=${G:-/usr/local/gromacs/bin/gmx}; MODE=${MODE:-docker}
NT=${NT:-5}; PINOFF=${PINOFF:-15}; PINSTR=1; MAXH=${MAXH:-1.8}; NSTEPS=${NSTEPS:-20000000}; SI=${SI:-30}; EM_FMAX_MAX=${EM_FMAX_MAX:-1000}
PIN=${PINFLAGS-"-pin on -pinoffset $PINOFF -pinstride $PINSTR"}     # G2 的钉核, 与 G2 逐字相同
GPUF=${GPUFLAGS-"-nb gpu -update cpu"}                              # G2/J006 的 GPUFLAGS
NS_NS=$(awk -v n=$NSTEPS 'BEGIN{printf "%.1f",n*0.02/1000}')
CN=R2b_${SYS}_$$
[ -d "$D" ] && [ -f "$D/sys.top" ] || { echo "ABORT: 没有 $D/sys.top (包未解到 $J)"; exit 1; }
log(){ echo "[$(date '+%F %T')] $SYS: $*" | tee -a "$O/R2b.log"; }
# gx: 在 $PWD 里跑 gmx. docker 模式 = G2 同款 (--entrypoint /bin/sh -u uid:gid -e HOME=/tmp -v J:J -w PWD IMG -c 'exec 2>&1; CMD')
gx(){ if [ "$MODE" = local ]; then ${GMX_LOCAL:-gmx} "$@" 2>&1; else
  docker run --rm --name $CN --gpus all $MPSARGS --entrypoint /bin/sh -u $(id -u):$(id -g) -e HOME=/tmp -v $J:$J -w "$PWD" $IMG -c "exec 2>&1; $G $*"; fi; }
nanchk(){ grep -ciE '(^|[^a-z])nan([^a-z]|$)|fatal error|LINCS WARNING' "$1" 2>/dev/null; }
crmax(){ awk '/Constr\. rmsd/{h=1;next} h{v=$NF+0; if(v>m)m=v; h=0} END{printf "%.3g",m+0}' "$1" 2>/dev/null; }
laststep(){ awk '/^ +Step +Time/{getline; s=$1} END{print s+0}' $O/prod.log 2>/dev/null; }
finished(){ [ -f $O/prod.log ] && grep -q '^Finished mdrun' $O/prod.log && [ "$(laststep)" -ge "$NSTEPS" ] 2>/dev/null; }
cpstep(){ grep 'Writing checkpoint, step' $O/prod.log 2>/dev/null | tail -1 | sed 's/.*step \([0-9]*\) at.*/\1/'; }
precheck(){ local mc gu mem; PCOK=1; [ -n "$SKIPPRE" ] && { echo "precheck 跳过(SKIPPRE)"; return; }
 mc=$(pgrep -fc '[m]drun'); gu=$(nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits 2>/dev/null | tr -d ' ' | sort -n | tail -1)
 mem=$(awk '/MemAvailable/{printf "%d",$2/1048576}' /proc/meminfo)
 [ "$mc" = 0 ] || { echo "REFUSE: mdrun 进程数=$mc (本作业须 solo)"; PCOK=0; }
 if [ -z "$SKIPGPU" ]; then case $gu in ''|*[!0-9]*) echo "REFUSE: GPU 利用率读不到(可设 SKIPGPU=1)"; PCOK=0;; *) [ "$gu" -lt 10 ] || { echo "REFUSE: GPU util=$gu%"; PCOK=0; };; esac; fi
 [ "${mem:-0}" -ge ${MINMEM:-20} ] || { echo "REFUSE: MemAvailable=${mem}GiB"; PCOK=0; }
 echo "precheck mdrun=$mc gpu_util=${gu:-NA}% memavail=${mem}GiB ok=$PCOK"; }
# 输入完整性: sys.gro/sys.top/mdp/itp 全在, 且与包内 MANIFEST (若有) 一致
need="sys.gro sys.top em.mdp eq1.mdp eq2.mdp prod.mdp"; for f in $need $(grep -E '^#include' $D/sys.top | sed 's/.*"\(.*\)".*/\1/'); do [ -s "$D/$f" ] || { echo "ABORT: 缺 $D/$f (包未解到 $J)"; exit 1; }; done
if [ -f $J/MANIFEST_sha256.txt ]; then bad=$(grep " starts/$SYS/" $J/MANIFEST_sha256.txt | while read -r s p; do f=$D/${p#starts/$SYS/}; [ "$(sha256sum "$f" 2>/dev/null | cut -d' ' -f1)" = "$s" ] || echo "$p"; done)
  [ -z "$bad" ] || { echo "ABORT: 与 MANIFEST 不符: $bad"; exit 1; }; fi
# R2b 新增: gmx>=2026 c-rescale 规则 tau_p >= 25*nstpcouple*dt, eq1/eq2/prod 分别检查, 不满足即 ABORT (R2a 因此被 grompp 拦过)
for st in eq1 eq2 prod; do awk -v s=$st '$1=="dt"{dt=$3} $1=="nstpcouple"{n=$3} $1=="tau_p"{tp=$3} END{need=25*n*dt; ok=(tp+1e-9>=need); printf "taup_check %s: tau_p=%s nstpcouple=%s dt=%s need>=%.4g %s\n", s, tp, n, dt, need, ok?"OK":"FAIL"; exit !ok}' $D/$st.mdp || { echo "ABORT: $SYS $st.mdp 违反 tau_p>=25*nstpcouple*dt"; exit 1; }; done
RS=0; [ -f $O/prod.cpt ] && RS=$(cpstep); RS=${RS:-0}; NREM=$((NSTEPS-RS))
EQN=""; [ -n "$EQ_NSTEPS" ] && EQN="-nsteps $EQ_NSTEPS"
CMDP="$G mdrun -deffnm prod -ntmpi 1 -ntomp $NT $GPUF $PIN -nsteps $NREM -maxh $MAXH -cpi prod.cpt"   # = G2 的 CMD (nsteps 为 NSTEPS-检查点步)
if [ -n "$DRY" ]; then echo "== DRY (未创建 out/) host=$(hostname) SYS=$SYS D=$D"; echo "   目标 NSTEPS=$NSTEPS (= $NS_NS ns @ dt=20 fs) 检查点步=$RS 本次 prod -nsteps=$NREM pin='$PIN' gpu='$GPUF' maxh=$MAXH"
 for s in em eq1 eq2 prod; do echo "   $s.mdp: $(grep -E '^(nsteps|dt) ' $D/$s.mdp | tr -s ' ' | tr '\n' ';')"; done; precheck
 echo "   步骤: grompp em(-c sys.gro) -> mdrun em[-ntomp $NT $PIN, 无 gpu 标志, 同 J006 EM] -> EM 门 Fmax<$EM_FMAX_MAX -> grompp eq1(-c em.gro) -> mdrun eq1[$GPUF $PIN -cpi] -> grompp eq2(-c eq1.gro -t eq1.cpt) -> mdrun eq2 -> grompp prod(-c eq2.gro -t eq2.cpt) -> mdrun: $CMDP"; echo "== DRY 结束"; exit 0; fi
mkdir -p $O || exit 1; cd $O || exit 1
ls .failed_* >/dev/null 2>&1 && { echo "ABORT: 之前失败 $(ls .failed_* | tr '\n' ' ')(确认原因后删除该文件再跑)"; exit 1; }
docker ps -a --format '{{.Names}}' 2>/dev/null | grep -q "^R2b_${SYS}_" && [ "$MODE" != local ] && { echo "ABORT: 已有 R2b_${SYS}_* 容器(可能还在跑)"; exit 1; }
if finished; then log "已完成: laststep=$(laststep) >= $NSTEPS, 不再起容器"; grep -E '^Performance:' prod.log | tail -1; exit 0; fi
[ -f prod.log ] && [ ! -f prod.cpt ] && [ -z "$FORCE_FRESH" ] && { echo "ABORT: 有 prod.log 但无 prod.cpt, 不自动重开(确认后设 FORCE_FRESH=1)"; exit 1; }
[ -f prod.cpt ] && [ -z "$(cpstep)" ] && { echo "ABORT: 有 prod.cpt 但 prod.log 无 'Writing checkpoint, step' 行"; exit 1; }
precheck; [ $PCOK = 1 ] || { echo "拒绝启动"; exit 2; }
trap 'log "INTERRUPT: docker stop -t 120 $CN"; docker stop -t 120 $CN >/dev/null 2>&1' INT TERM
log "== start host=$(hostname) MODE=$MODE pin='$PIN' gpu='$GPUF' nsteps_target=$NSTEPS resume_cpt_step=$RS gmx=$G img=$IMG"
{ echo "system=$SYS"; echo "host=$(hostname)"; echo "pin=$PIN"; echo "gpuflags=$GPUF"; echo "ntomp=$NT"; echo "maxh=$MAXH"; echo "nsteps_target=$NSTEPS"; echo "resume_cpt_step=$RS"
  echo "prod_cmd=$CMDP"; echo "image_id=$(docker image inspect -f '{{.Id}}' $IMG 2>&1 | head -1)"; echo "start=$(date +%F_%T)"; echo "--"; } >> g2_meta.txt
fail(){ touch .failed_$1; log "FAIL $1 $2 (见 $O/$1.out)"; exit 3; }
gstep(){ local n=$1; shift; [ -f .done_$n ] && { log "$n 已完成, 跳过"; return 0; }; log "$n 开始"; local t0=$(date +%s)
  gx grompp "$@" -maxwarn 0 > $n.out 2>&1 || fail $n "grompp rc!=0"
  log "$n 完成 ($(( $(date +%s)-t0 ))s) warnings=$(grep -c '^WARNING' $n.out) notes=$(grep -c '^NOTE' $n.out)"; touch .done_$n; }
mstep(){ local n=$1; shift; [ -f .done_$n ] && { log "$n 已完成, 跳过"; return 0; }; log "$n 开始"; local t0=$(date +%s)
  gx mdrun -deffnm $n -ntmpi 1 -ntomp $NT "$@" > $n.out 2>&1 || fail $n "mdrun rc!=0"
  local nn=$(nanchk $n.log); [ "${nn:-0}" = 0 ] || fail $n "nan/fatal/LINCS 行数=$nn"
  log "$n 完成 ($(( $(date +%s)-t0 ))s) nan=0 constr_rmsd_max=$(crmax $n.log)"; touch .done_$n; }
gstep grompp_em -f ../em.mdp -c ../sys.gro -p ../sys.top -o em.tpr -n ../index.ndx
mstep em $PIN
fmax=$(awk '/^Maximum force/{print $4}' em.log | tail -1); log "EM Fmax=${fmax:-?} (门槛 $EM_FMAX_MAX)"
if ! awk -v f="${fmax:-inf}" -v m="$EM_FMAX_MAX" 'BEGIN{exit !(f+0==f && f<m)}'; then echo "EM_FAIL $(date '+%F %T') Fmax=${fmax:-?} >= $EM_FMAX_MAX(或非数); 不进 EQ" | tee EM_FAIL.txt >> R2b.log; touch .failed_em_gate; exit 3; fi
gstep grompp_eq1 -f ../eq1.mdp -c em.gro -p ../sys.top -o eq1.tpr -n ../index.ndx
mstep eq1 $GPUF $PIN $EQN -cpi eq1.cpt
gstep grompp_eq2 -f ../eq2.mdp -c eq1.gro -t eq1.cpt -p ../sys.top -o eq2.tpr -n ../index.ndx
mstep eq2 $GPUF $PIN $EQN -cpi eq2.cpt
gstep grompp_prod -f ../prod.mdp -c eq2.gro -t eq2.cpt -p ../sys.top -o prod.tpr -n ../index.ndx
# ---- prod: 以下原样沿用 g2_run.sh 的 meta/GPU 采样/亲和性/汇总逻辑 ----
RS=0; [ -f prod.cpt ] && RS=$(cpstep); RS=${RS:-0}; NREM=$((NSTEPS-RS)); [ "$NREM" -gt 0 ] || { echo "ABORT: 检查点步 $RS >= NSTEPS 但无 Finished mdrun, 人工查看"; exit 1; }
CMDP="$G mdrun -deffnm prod -ntmpi 1 -ntomp $NT $GPUF $PIN -nsteps $NREM -maxh $MAXH -cpi prod.cpt"
TS=$(date +%m%d_%H%M%S); R=$O/run_$TS; mkdir -p $R; cp -p ../sys.top ../prod.mdp $R/ 2>/dev/null
{ lscpu -e; nvidia-smi -L; } > $R/recon.txt 2>&1
LC_ALL=C nvidia-smi --query-gpu=timestamp,utilization.gpu,power.draw,temperature.gpu,clocks.sm,clocks.mem --format=csv -l $SI > $R/gpu.csv 2>/dev/null & GP=$!
( sleep 90; ps -eLo pid,tid,psr,pcpu,comm | awk '$5 ~ /gmx|mdrun/' > $R/affinity.txt; for p in $(pgrep -f '[g]mx mdrun'); do taskset -cp $p; done >> $R/affinity.txt 2>&1 ) & AFP=$!
log "prod 开始: $CMDP"; t0=$(date +%s)
if [ "$MODE" = local ]; then ${GMX_LOCAL:-gmx} mdrun -deffnm prod -ntmpi 1 -ntomp $NT $GPUF $PIN -nsteps $NREM -maxh $MAXH -cpi prod.cpt > $R/stdout.txt 2>&1; rc=$?
else docker run --rm --name $CN --gpus all $MPSARGS --entrypoint /bin/sh -u $(id -u):$(id -g) -e HOME=/tmp -v $J:$J -w $O $IMG -c "exec 2>&1; $CMDP" > $R/stdout.txt 2>&1 & DP=$!; wait $DP; rc=$?; fi   # 评审: 后台+wait, 使 INT/TERM trap 立即执行 (前台命令会让 bash 延迟 trap)
pkill -P $AFP 2>/dev/null; pkill -P $GP 2>/dev/null; kill $GP $AFP 2>/dev/null; wait $GP $AFP 2>/dev/null; t1=$(date +%s)
ls=$(laststep); perf=$(grep -E '^Performance:' prod.log 2>/dev/null | tail -1 | awk '{print $2}'); nanl=$(nanchk prod.log); crm=$(crmax prod.log)
chk=OK; [ "${nanl:-0}" = 0 ] || chk=NAN; awk -v c="$crm" 'BEGIN{exit !(c+0>0.001)}' && chk="${chk}+CRMSD>1e-3"
printf 'rc=%s\nsecs=%s\nend=%s\nlaststep=%s\nlast_t_ns=%s\nperformance_ns_day_last_segment=%s\nnan_fatal_lines=%s\nconstr_rmsd_max=%s\nfinished=%s\n' $rc $((t1-t0)) "$(date +%F_%T)" $ls "$(awk -v s=$ls 'BEGIN{printf "%.2f",s*0.02/1000}')" "$perf" "$nanl" "$crm" "$(finished && echo yes || echo no)" | tee -a $R/meta.txt >> g2_meta.txt
# g2_runs.tsv 风格: 前 9 列与 G2 相同 (TAG host TS rc secs step perf nan PIN), 后加 crmax / check
printf '%s\t%s\t%s\trc=%s\tsecs=%s\tstep=%s\tperf=%s\tnan=%s\t%s\tcrmax=%s\tcheck=%s\n' "$SYS" "$(hostname)" "$TS" $rc $((t1-t0)) $ls "$perf" "$nanl" "$PIN" "$crm" "$chk" >> $D/g2_runs.tsv
sed -n '/R E A L   C Y C L E   A N D   T I M E   A C C O U N T I N G/,$p' prod.log > $R/cycle_full.txt 2>/dev/null
grep -E '^Performance:|^ +\(ns/day\)|Command line|^  gmx mdrun|Reading checkpoint|Started mdrun|Run time exceeded|Finished mdrun' prod.log > $R/perf_lines.txt 2>/dev/null
if [ $rc != 0 ]; then { echo "== rc=$rc cmd: $CMDP"; tail -60 prod.log; echo "== stdout tail"; tail -60 $R/stdout.txt; } > $R/ERROR_tail.txt 2>&1; log "FAIL prod rc=$rc 原文: $R/ERROR_tail.txt"; exit 3; fi
if finished; then sha256sum prod.tpr prod.xtc prod.edr prod.log prod.cpt prod.gro prod.trr 2>/dev/null > SHA256_out.txt; log "== DONE laststep=$ls ($NS_NS ns) check=$chk"; [ "$chk" = OK ] || exit 4
else log "== 未跑满 (laststep=$ls < $NSTEPS): 同命令再跑一次即用 -cpi 续跑"; fi
