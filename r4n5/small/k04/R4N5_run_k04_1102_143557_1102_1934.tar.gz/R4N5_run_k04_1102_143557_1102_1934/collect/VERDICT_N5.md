# R4N5 v2 判读 (1200 ns 视界)

- 总判 (T350 尺子): **NOT_EVALUABLE**
- T350 (main): 总判 NOT_EVALUABLE
  - DOPE: 规则 P = NOT_EVALUABLE; state=NOT_RUN n_eval=0 n_event=0 n_merge=0; runs=['R4N1_DOPE_h100_T350_lam_s501:NOT_RUN', 'R4N1_DOPE_h100_T350_lam_s502:NOT_RUN', 'R4N1_DOPE_h100_T350_lam_s503:NOT_RUN']; notes=[]
  - DOPC: 规则 N = PASS; state=EVALUABLE n_eval=3 n_event=0 n_merge=0; runs=['R4N1_DOPC_h100_T350_lam_s504:NO_EVENT', 'R4N1_DOPC_h100_T350_lam_s502:NO_EVENT', 'R4N1_DOPC_h100_T350_lam_s503:NO_EVENT']; notes=['s1 VOID_L2 -> 替补 s4']
- T360 (branch_b): 未跑
- T330 (branch_c): 未跑
- MC3H 片层 T350: state=NOT_RUN n_eval=0 n_event=0; runs=['R4N1_MC3H_h100_T350_lam_s501:NOT_RUN', 'R4N1_MC3H_h100_T350_lam_s502:NOT_RUN', 'R4N1_MC3H_h100_T350_lam_s503:NOT_RUN']; 加种子(描述)={'n_run': 0, 'n_eval': 0, 'n_event': 0, 'runs': []}; notes=[]
- MC3 片层 T350: state=VOID n_eval=0 n_event=0; runs=[]; 加种子(描述)={'n_run': 0, 'n_eval': 0, 'n_event': 0, 'runs': []}; notes=['替补 s4 也 VOID_L2', 's1 VOID_L2 无可用替补', 's2 VOID_L2 无可用替补', 's3 VOID_L2 无可用替补']
- Δ_lam(MC3−MC3H 事件数): {"verdict": "NOT_JUDGED", "reason": "T350 尺子=NOT_EVALUABLE (MC3 只描述)", "extra_seeds_desc": "MC3 0/0 vs MC3H 0/0 (s501-507 全部可评估跑的事件比例, 描述, 不进门)"}
- 400 ns 描述 (不进门): DOPE n_event=0, DOPC n_event=0
