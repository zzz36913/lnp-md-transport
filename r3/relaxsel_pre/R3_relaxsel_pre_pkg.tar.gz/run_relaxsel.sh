#!/bin/bash
# run_relaxsel.sh -- R3 "取起点规则" 小预跑 (只 relax + 选帧 + 闸门读数; 没有 prod). 不碰 GLM/ZCode/端口/key; 只停本脚本起的容器.
# 目的: 在正式 R3 发车前, 用 6 个起点 (DOPE s2,s3,s5 / DOPC s1,s2,s3) 各跑 15 ns relax (RELAX_ARM=crescale_dev, 加 nstxout=nstvout=5000),
#       然后对末 5 ns 的 ~67 个 trr 帧逐帧用同一个 t0_gate (prod0 lam 960/720, 阈值 0.65/0.75/0.95, 极性 0.8, 2/2/2/2, v1==v2) 判定, 选最后合格帧.
#       读数: 合格帧比例 / 选中 t_ps / selected.gro / 选中帧闸门读数 / relax Performance.  判据与阈值一个未改 (见 PRE_REG_AMENDMENT_R3_trr.md 的主包).
# 逻辑与主包 R3_launch 完全同一份: lib_R3.sh 与主包逐字相同 (MANIFEST 里 sha 可对), 这里只是把 run_build 里的 relax->select->gate 拆出来, 不接 prod.
# 用法 (在 Spark 上, 单机 k03):
#   cd R3_relaxsel_pre && sha256sum -c MANIFEST_sha256.txt           # 全 OK
#   mkdir -p $HOME/R3_gatewrap && cp gatewrap/gate_py_container.sh $HOME/R3_gatewrap/ && chmod +x $HOME/R3_gatewrap/gate_py_container.sh
#   DRY=1  GATE_PY=$HOME/R3_gatewrap/gate_py_container.sh bash run_relaxsel.sh        # 只打印计划
#   CHECK=1 GATE_PY=$HOME/R3_gatewrap/gate_py_container.sh bash run_relaxsel.sh       # 只做自检 (gmx 版本/容器 trjconv stdin/闸门 python/冲突)
#   GATE_PY=$HOME/R3_gatewrap/gate_py_container.sh bash run_relaxsel.sh 2>&1 | tee relaxsel_stdout.txt
#   SEQ=1 ...   单槽顺序跑 6 个 (不设=两槽并行: 槽 A = DOPE s2,s3,s5 pin $PINA ; 槽 B = DOPC s1,s2,s3 pin $PINB, 共用一个用户态 MPS)
# 回传: bash pack_return.sh <输出目录>  -> <输出目录>_return.tar.gz (不含 relax.trr/.cpt), 再 python3 summarize_relaxsel.py <输出目录> 出汇总表.
# 估时 (估算): relax ~2-3 min/个 + 逐帧闸门 ~67 帧 x ~4-8 s (容器启动+闸门) = 5-9 min/个; 每槽 3 个顺序 -> 墙钟约 25-40 min. 磁盘: 每个 relax.trr ~200 MB, 6 个 ~1.2 GB.
# 未在 Spark/2026.3 上实测 (box 无 docker): 容器内 trjconv 经 stdin (-i) 取组号是本次的新依赖, CHECK 会先测.
HERE=$(cd "$(dirname "$0")" && pwd); MACHINE=${MACHINE:-k03}; ORCH_PID=$$
export PYTHONDONTWRITEBYTECODE=1
J=${J:-$HOME/R3_relaxsel}; export J HERE MACHINE ORCH_PID
[ -n "${DEADLINE:-}" ] || DEADLINE=$(date -d '+6 hours' '+%F %T %z')    # 预跑不受 R3 正式 DEADLINE 约束: 默认 6 h 后 (只用于 relax 的 -maxh)
export DEADLINE
CN_PREFIX=${CN_PREFIX:-R3_}; export CN_PREFIX
. "$HERE/lib_R3.sh"; DL=$(date -d "$DEADLINE" +%s)
CN_PREFIX=R3RS_; export CN_PREFIX                                          # 容器名 R3RS_<机>_<pid>_*  (不会匹配 R2a_/R2b_/R3_/j009_ 前缀)
BUILDS_A="R3_DOPE_lam_s2 R3_DOPE_lam_s3 R3_DOPE_lam_s5"; BUILDS_B="R3_DOPC_lam_s1 R3_DOPC_lam_s2 R3_DOPC_lam_s3"
[ -n "${SEQ:-}" ] && { BUILDS_A="$BUILDS_A $BUILDS_B"; BUILDS_B=""; }
f(){ echo "  [FAIL] $*"; bad=1; }; p(){ echo "  [ok]   $*"; }
guard(){ local b x; bad=0; echo "== guard machine=$MACHINE MODE=$MODE $(date '+%F %T %z')"
  ( cd $HERE && sha256sum -c MANIFEST_sha256.txt --quiet ) >/dev/null 2>&1 && p "MANIFEST sha256 全 OK" || f "包与 MANIFEST 不符"
  [ "$RELAX_ARM" = crescale_dev ] && [ "$MAXWARN_RELAX" = 0 ] && [ "$SEL_RULE" = 1 ] && [ "$GATE_MODE" = host ] && p "RELAX_ARM=crescale_dev maxwarn 0 SEL_RULE=1 GATE_MODE=host SEL_NSTOUT=$SEL_NSTOUT SEL_WIN_PS=$SEL_WIN_PS" || f "参数: RELAX_ARM=$RELAX_ARM MAXWARN_RELAX=$MAXWARN_RELAX SEL_RULE=$SEL_RULE GATE_MODE=$GATE_MODE (须 crescale_dev/0/1/host)"
  [ -z "${NSTEPS_OVERRIDE_RELAX:-}" ] || [ "$MODE" = local ] || f "NSTEPS_OVERRIDE_RELAX 只允许 MODE=local"
  need_cmd || bad=1
  for b in $BUILDS_A $BUILDS_B; do valid_name $b || { f "非法 build $b"; continue; }; for x in start.gro sys.top index.ndx relax_crescale_dev.mdp prod_lam.mdp; do [ -s $INP/$b/$x ] || f "缺 $INP/$b/$x"; done; done
  for x in $(grep -E '^#include' $INP/R3_DOPE_lam_s2/sys.top | sed 's/.*"\(.*\)".*/\1/'); do [ -s $FF/$x ] || f "缺力场 $FF/$x"; done
  if [ "$GATE_MODE" = host ]; then $GATE_PY -c 'import numpy, scipy, MDAnalysis' >/dev/null 2>&1 && p "GATE_PY=$GATE_PY 可 import numpy/scipy/MDAnalysis" || f "GATE_PY=$GATE_PY 缺依赖 (Spark 上用 gatewrap/gate_py_container.sh)"; fi
  if [ "$MODE" = docker ]; then
    [ "$(pgrep -c gmx)" = 0 ] && p "pgrep gmx 为空" || f "已有 gmx 进程"
    x=$(procs_other $$ 'R2a_machine|R2b_machine|run_prerun|run_R3\.sh|run_relaxsel'); [ -z "$x" ] && p "无其它 R3/prerun 脚本进程" || f "有相关脚本进程: $(echo "$x" | head -3 | tr '\n' ';')"
    [ -z "$(docker ps --format '{{.Names}}' 2>/dev/null | grep -E '^(R2a_|R2b_|R3|j009_)')" ] && p "docker ps 无占卡容器" || f "有占卡容器"
    [ -z "$(pgrep -a nvidia-cuda-mps)" ] && p "无 MPS 进程" || f "已有 MPS 进程"
    [ -z "$(ls -A ${MPSROOT:-$HOME/mps_R3} 2>/dev/null)" ] && p "MPSROOT 为空/不存在" || f "MPSROOT 非空"
    x=$(df -Pk "$(dirname $J)" 2>/dev/null | awk 'NR==2{printf "%d",$4/1048576}'); [ "${x:-0}" -ge 5 ] && p "磁盘可用 ${x} GiB" || f "磁盘可用 ${x:-?} GiB < 5"
  else echo "  [info] MODE=local: 跳过占卡/MPS 检查 (box 冒烟)"; fi
  # gmx 版本 + 容器内 trjconv 经 stdin 取组号 (取起点规则的新依赖)
  local W=$(mktemp -d /tmp/R3RS_chk_XXXX); OUT_PARENT=$W GMXV=$( ( cd /tmp; OUT_PARENT=$W CN=$(cn_name ver_$BASHPID) gx --version 2>&1 | grep -m1 'GROMACS version' | awk '{print $NF}' ) ); check_gmxv && p "gmx $GMXV" || f "gmx 版本 '$GMXV'"
  ( cd $W && echo 0 | OUT_PARENT=$W GXI=1 CN=$(cn_name seltest_$$) gx trjconv -f $INP/R3_DOPE_lam_s2/start.gro -s $INP/R3_DOPE_lam_s2/start.gro -sep -o t.gro >trj.log 2>&1 ); ls $W/t*.gro >/dev/null 2>&1 && p "容器内 trjconv 经 stdin (-i) 取组号 OK (与 step_select 同款参数)" || f "trjconv stdin 自检失败 ($W/trj.log)"
  return $bad; }
if [ -n "${DRY:-}" ] || [ -n "${CHECK:-}" ]; then
  if [ -n "${DRY:-}" ]; then echo "== DRY J=$J MODE=$MODE 不建输出/不起 MPS/容器"; echo "槽 A (pin $PINA): $BUILDS_A"; echo "槽 B (pin $PINB): ${BUILDS_B:-(SEQ=1 无 B)}"
    echo "每个 build: grompp relax_crescale_dev (+nstxout=nstvout=$SEL_NSTOUT, maxwarn 0) -> mdrun 15 ns -> 末 ${SEL_WIN_PS} ps trr 帧逐帧闸门 -> 选最后合格帧 -> 对选中帧(或末帧)再出一次闸门读数; 无 prod"; exit 0; fi
  OUT=/tmp/R3RS_check_$$; mkdir -p $OUT/slots; export OUT OUT_PARENT=/tmp; guard; rc=$?; echo "== CHECK $([ $rc = 0 ] && echo 'ALL OK' || echo FAIL)"; exit $rc; fi
need_cmd || exit 1
take_lock || { echo "ABORT: 同机已有一个在跑 (flock $J/.R3_${MACHINE}.flock)"; exit 1; }; HAVE_LOCK=1
mkdir -p $J; TS=$(date +%m%d_%H%M%S); OUT=$J/R3_relaxsel_${MACHINE}_$TS; mkdir "$OUT" 2>/dev/null || { echo "ABORT: $OUT 已存在"; exit 1; }
OUT_PARENT=$J; mkdir -p $OUT/slots $OUT/ledger; export OUT OUT_PARENT; exec > >(tee -a $OUT/orchestrator.log) 2>&1; echo "OUT=$OUT"
guard || { echo "ABORT: 自检不过, 未起 MPS/容器"; exit 1; }
{ echo "machine=$MACHINE host=$(hostname) start=$(date '+%F %T %z') gmx=$GMXV mode=$MODE"; env | grep -E '^(RELAX_ARM|MAXWARN_|GATE_|SEL_|NT=|PINA|PINB|IMG=|J=|EXPECT_GMX|SEQ)' | sort; (cd $HERE && sha256sum lib_R3.sh MANIFEST_sha256.txt run_relaxsel.sh); } > $OUT/RUN_META.txt
mps_start || exit 1
cleanup(){ echo "[$(date '+%F %T')] INTERRUPT/EXIT: 只停 ${CN_PREFIX}${MACHINE}_${ORCH_PID}_* 容器"; [ "$MODE" = local ] || { for c in $(docker ps --format '{{.Names}}' | grep "^${CN_PREFIX}${MACHINE}_${ORCH_PID}_"); do docker stop -t 120 $c >/dev/null 2>&1; done; }; }
trap 'cleanup; kill $PA $PB 2>/dev/null; wait $PA $PB 2>/dev/null; mps_stop; exit 143' INT TERM
one(){ local b=$1 po=$2 rd; ROLE=pre; mkdir -p $OUT/builds/$b; NEEDH=0
  if ! rd=$(done_dir $OUT/builds/$b/relax DONE); then step_relax $b $po || { say "$b relax 失败: $(last_state $OUT/builds/$b/relax)"; return 4; }; rd=$(done_dir $OUT/builds/$b/relax DONE); fi
  step_select $b $rd; step_gate $b $rd $SEL_GRO; say "$b 选帧=$(last_state $OUT/builds/$b/select) 起点闸门=$GATE_ST"; }   # 与 run_build 同序; 之后不接 prod
slot(){ local tag=$1 po=$2; shift 2; SLOT_TAG=$tag; for b in "$@"; do halted && break; one $b $po; done; say "slot $tag 完成"; }
( slot ${MACHINE}_A $PINA $BUILDS_A ) & PA=$!
if [ -n "$BUILDS_B" ]; then ( slot ${MACHINE}_B $PINB $BUILDS_B ) & PB=$!; else PB=; fi
wait $PA $PB; mps_stop
python3 $HERE/summarize_relaxsel.py $OUT 2>&1 | tee $OUT/SUMMARY_stdout.txt
echo "== done $(date '+%F %T %z') OUT=$OUT  (回传: bash $HERE/pack_return.sh $OUT)"
