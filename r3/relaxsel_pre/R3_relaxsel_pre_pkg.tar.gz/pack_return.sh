#!/bin/bash
# pack_return.sh <输出目录> -> <输出目录>_return.tar.gz (排除 relax.trr / relax.cpt / frames/ 下的 gro 之外的大文件; 保留 selected.gro, relax.gro, 全部 STATUS/日志/json/tsv). 只读.
O=${1:?usage: pack_return.sh <R3_relaxsel_..目录>}; O=${O%/}; T=${O}_return.tar.gz
tar -C "$(dirname $O)" --exclude='relax.trr' --exclude='relax.cpt' --exclude='relax.tpr' --exclude='*.edr' -czf $T "$(basename $O)" && { ls -l $T; sha256sum $T; du -sh $T; }
