#!/usr/bin/env python3
"""summarize_relaxsel.py <输出目录> -> SUMMARY.tsv / SUMMARY.md (每个 build: 合格帧比例 / 选中 t_ps / 选中帧闸门读数 / relax Performance). 只读, 纯 stdlib."""
import sys, os, glob, json, re
out = sys.argv[1]; rows = []
def last(d):
    a = sorted(glob.glob(os.path.join(d, 'attempt_[0-9][0-9][0-9]'))); return a[-1] if a else None
def rd(p):
    try: return open(p).read().strip()
    except Exception: return ''
for bd in sorted(glob.glob(os.path.join(out, 'builds', '*'))):
    b = os.path.basename(bd); r = last(bd + '/relax'); s = last(bd + '/select'); g = last(bd + '/gate')
    rs = rd(r + '/STATUS').split()[0] if r and rd(r + '/STATUS') else '-'
    perf = '-'
    if r:
        m = re.findall(r'^Performance:\s+([0-9.]+)', rd(r + '/relax.log'), re.M); perf = m[-1] if m else '-'
    nq = nf = '-'; frac = '-'; tsel = '-'; ss = '-'; fin = '-'
    if s:
        ss = rd(s + '/STATUS').split()[0] if rd(s + '/STATUS') else '-'
        kv = {}
        for fn in ('SELECTED_FRAME.txt', 'SELECTED_FRAME_NONE.txt'):
            for ln in rd(s + '/' + fn).splitlines():
                if '=' in ln: k, v = ln.split('=', 1); kv[k] = v
        nq = kv.get('n_qualified', '-'); nf = kv.get('n_frames_window', '-'); frac = kv.get('qualified_fraction', '-'); tsel = kv.get('selected_t_ps', '-')
        try:
            ft = [l.split('\t') for l in rd(s + '/frames.tsv').splitlines()[1:]]
            fin = 't=%s rc=%s %s' % (ft[-1][1], ft[-1][2], ft[-1][4]) if ft else '-'   # 末帧 (=relax 终帧) 的闸门读数, 与旧 0/6 读数同口径
            qs = ''.join('1' if x[2] == '0' else '0' for x in ft)
        except Exception: qs = ''
    gst = rd(g + '/STATUS').split()[0] if g and rd(g + '/STATUS') else '-'
    gr = '-'
    if g and os.path.exists(g + '/gate.json'):
        try: j = json.load(open(g + '/gate.json')); gr = json.dumps(j.get('readings', j.get('verdict', '')))[:200] if isinstance(j, dict) else '-'
        except Exception: pass
    rows.append((b, rs, perf, ss, nq, nf, frac, tsel, gst, fin, qs if s else '-'))
H = ['build', 'relax', 'relax_ns_day', 'select', 'n_qual', 'n_win', 'qual_frac', 'selected_t_ps', 'start_gate', 'last_frame(final)_reading_0.65_v1', 'qualified_frames(1/0 by time)']
open(out + '/SUMMARY.tsv', 'w').write('\t'.join(H) + '\n' + '\n'.join('\t'.join(map(str, r)) for r in rows) + '\n')
md = '| ' + ' | '.join(H[:-1]) + ' |\n|' + '---|' * (len(H) - 1) + '\n' + '\n'.join('| ' + ' | '.join(map(str, r[:-1])) + ' |' for r in rows) + '\n\n逐帧合格串(时间升序, 1=合格):\n' + '\n'.join('- %s: %s' % (r[0], r[-1]) for r in rows) + '\n'
open(out + '/SUMMARY.md', 'w').write(md); print(md)
