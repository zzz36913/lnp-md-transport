#!/bin/bash
# [复审 M1-M3] 单测 (box, MODE=local, fake trr, 同 test_SEL_unit.sh 的夹具): ERR 帧重试/SEL_SKIP, 无速度回退, 起点 sha 校验 (VOID_SEL_MISMATCH). 只在 /tmp 写; 退出码 0=全过
T=$(cd "$(dirname "$0")/.." && pwd); PR=${PR:-$(cd $T/.. && pwd)/prerun_results/R3_prerun_1028_175447/relax}; W=$(mktemp -d /tmp/R3m123_XXXX); fail=0
ck(){ if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fail=1; fi; }
REALPY=${GATE_PY:-/workspace/venv_gate/bin/python}
# GATE_PY 包装: ERRSET 里的帧 (basename 如 fr11.gro) 永久 rc=1; FLAKY1 里的帧第一次 rc=1 (计数文件 $W/flaky_<名>)
cat > $W/gw.sh <<GW
#!/bin/bash
f=\$(basename \$2); case " \${ERRSET:-} " in *" \$f "*) echo "injected ERR" >&2; exit 1;; esac
case " \${FLAKY1:-} " in *" \$f "*) [ -f $W/flaky_\$f ] || { touch $W/flaky_\$f; echo "injected transient" >&2; exit 1; };; esac
exec $REALPY "\$@"
GW
chmod +x $W/gw.sh
export SEL_WIN_PS=900 HERE=$T MACHINE=k03 ORCH_PID=$$ J=$W MODE=local EXPECT_GMX=any NT=2 GMX_LOCAL=${GMX_LOCAL:-/workspace/ha_src/gmxenv/bin/gmx} GATE_PY=$W/gw.sh GMXLIB=$T/inputs/ff DEADLINE="2099-01-01 00:00 +0800" SEL_RETRY_S=0
. $T/lib_R3.sh >/dev/null; OUT=$W/out; OUT_PARENT=$W; mkdir -p $OUT/slots $OUT/ledger; export OUT OUT_PARENT; SLOT_TAG=unit; ROLE=primary; NEEDH=0
mk(){ local b=$1 fg=$2 np=$3 bad=${4:-} rd=$W/rd_$5; mkdir -p $rd; local m=$T/inputs/$b/relax_crescale_dev.mdp
  awk '!($1=="nstxout"||$1=="nstvout")' $m > $rd/relax_crescale_dev.mdp; printf 'nstxout = 5000\nnstvout = 5000\n' >> $rd/relax_crescale_dev.mdp
  ( cd $rd && $GMX_LOCAL grompp -f relax_crescale_dev.mdp -c $T/inputs/$b/start.gro -p $T/inputs/$b/sys.top -n $T/inputs/$b/index.ndx -o relax.tpr -maxwarn 0 >grompp.log 2>&1 ) || { echo "grompp fail"; tail -5 $rd/grompp.log; }
  python3 $T/tests/make_fake_trr.py $T/inputs/$b/start.gro $fg $rd/multi.gro $np 12 14175 75 "$bad"
  ( cd $rd && $GMX_LOCAL trjconv -f multi.gro -o relax.trr >trj.log 2>&1 <<<0 ); cp $fg $rd/relax.gro; echo $rd; }
FE=$PR/R3_DOPE_lam_s2/crescale/attempt_001/relax.gro
sd(){ last_attempt $OUT/builds/$1/select; }; st(){ cut -d' ' -f1 $(sd $1)/STATUS; }
# gro_has_vel 直测
g=$W/g.gro; cp $FE $g; ck "gro_has_vel: 真 relax.gro 带速度 -> 真" 'gro_has_vel $g'
awk 'NR<=2||NF<4{print;next}{print substr($0,1,44)}' $g > $W/nv.gro; ck "gro_has_vel: 去掉速度列 -> 假" '! gro_has_vel $W/nv.gro'
awk 'NR<=2{print;next} length($0)>=68{print substr($0,1,44) "  0.0000  0.0000  0.0000";next}{print}' $g > $W/zv.gro; ck "gro_has_vel: 速度全 0 -> 假" '! gro_has_vel $W/zv.gro'
# E1 瞬时 ERR (末帧 fr11 首次 rc=1, 重试后成功) -> 仍选末帧 t=15000, tries=2
rd=$(mk R3_DOPE_lam_s2 $FE 12 "" E1 | tail -1); FLAKY1="fr11.gro" step_select R3_DOPE_lam_s2 $rd; d=$(sd R3_DOPE_lam_s2)
ck "E1 瞬时 rc=1 重试后合格: SEL_OK t=15000 ($(st R3_DOPE_lam_s2))" '[ "$(st R3_DOPE_lam_s2)" = SEL_OK ] && grep -q "selected_t_ps=15000" $d/SELECTED_FRAME.txt && grep -q "n_err=0" $d/SELECTED_FRAME.txt'
ck "E1 frames.tsv 末帧 tries=2, verdict 非 ERR" '[ "$(awk "\$1==11{print \$7}" $d/frames.tsv)" = 2 ] && [ "$(awk "\$1==11{print \$4}" $d/frames.tsv)" != ERR ]'
ck "E1 无 WARN (12 帧, 末帧 t=15000)" '[ ! -f $d/WARN.txt ]'
# E3 3 个永久 ERR (含末帧 fr11,fr10,fr9) -> ERR 不计合格, SEL_OK 选 idx 63 (t=13650)  [12 帧 t=14175+75*idx]
rd=$(mk R3_DOPE_lam_s3 $PR/R3_DOPE_lam_s3/crescale/attempt_001/relax.gro 12 "" E3 | tail -1); ERRSET="fr11.gro fr10.gro fr9.gro" step_select R3_DOPE_lam_s3 $rd; d=$(sd R3_DOPE_lam_s3)
ck "E3 ERR=3 (<=3): SEL_OK 且选 idx8 t=14775 ($(grep selected_t_ps $d/SELECTED_FRAME.txt))" '[ "$(st R3_DOPE_lam_s3)" = SEL_OK ] && grep -q "selected_t_ps=14775" $d/SELECTED_FRAME.txt && grep -q "n_err=3" $d/SELECTED_FRAME.txt'
ck "E3 ERR 帧 verdict=ERR 且 tries=3, WARN.txt 提到 ERR" '[ "$(awk "\$1==11{print \$4\$7}" $d/frames.tsv)" = ERR3 ] && grep -q ERR $d/WARN.txt'
# E2 4 个永久 ERR -> SEL_SKIP, 回退 relax.gro, sel_gro_of 为空
rd=$(mk R3_DOPE_lam_s5 $PR/R3_DOPE_lam_s5/crescale/attempt_001/relax.gro 12 "" E2 | tail -1); ERRSET="fr11.gro fr10.gro fr9.gro fr8.gro" step_select R3_DOPE_lam_s5 $rd; d=$(sd R3_DOPE_lam_s5)
ck "E2 ERR=4 (>3): SEL_SKIP ($(st R3_DOPE_lam_s5)), SEL_GRO=relax.gro, sel_gro_of 空" '[ "$(st R3_DOPE_lam_s5)" = SEL_SKIP ] && [ "$SEL_GRO" = $rd/relax.gro ] && [ -z "$(sel_gro_of R3_DOPE_lam_s5)" ]'
# W 帧数不符 (窗口 10 帧而非 67) 记 WARN
rd=$(mk R3_DOPE_lam_s9 $PR/R3_DOPE_lam_s3/crescale/attempt_001/relax.gro 12 "" W | tail -1); SEL_WIN_PS=300 step_select R3_DOPE_lam_s9 $rd; d=$(sd R3_DOPE_lam_s9)
ck "W 窗口缩小 -> 帧数 WARN 不适用(期望同步缩小) 但仍 SEL_OK" '[ "$(st R3_DOPE_lam_s9)" = SEL_OK ]'
# F 无速度回退: 覆盖 gro_has_vel, 使 fr11 无速度 -> 选 idx10; 全无 -> SEL_NONE
rd=$(mk R3_DOPE_lam_s14 $PR/R3_DOPE_lam_s3/crescale/attempt_001/relax.gro 12 "" F | tail -1); eval "orig_$(declare -f gro_has_vel)"
gro_has_vel(){ case $1 in *fr11.gro) return 1;; esac; orig_gro_has_vel "$1"; }
step_select R3_DOPE_lam_s14 $rd; d=$(sd R3_DOPE_lam_s14)
ck "F 末帧无速度 -> 回退 idx10 t=14925 ($(grep selected_t_ps $d/SELECTED_FRAME.txt)), novel=1" '[ "$(st R3_DOPE_lam_s14)" = SEL_OK ] && grep -q "selected_t_ps=14925" $d/SELECTED_FRAME.txt && grep -q "n_qualified_novel=1" $d/SELECTED_FRAME.txt && [ -s $d/novel_frames.txt ]'
gro_has_vel(){ return 1; }; step_select R3_DOPE_lam_s14 $rd; d=$(sd R3_DOPE_lam_s14)
ck "F 全部合格帧无速度 -> SEL_NONE ($(st R3_DOPE_lam_s14))" '[ "$(st R3_DOPE_lam_s14)" = SEL_NONE ] && [ "$SEL_GRO" = $rd/relax.gro ]'
eval "$(declare -f orig_gro_has_vel | sed 's/^orig_gro_has_vel/gro_has_vel/')"
# G M3: 选中帧 -> step_gate PASS -> sel_verify OK; 篡改 selected.gro -> VOID_SEL_MISMATCH, prod 不 grompp
b=R3_DOPE_lam_s2; rd=$W/rd_E1; selg=$(sel_gro_of $b); GATE_PY=$REALPY step_gate $b $rd $selg; ck "G step_gate(选中帧) PASS ($GATE_ST)" '[ "$GATE_ST" = PASS ]'
ck "G sel_verify 一致 -> 0" 'sel_verify $b $selg'
cp $selg $W/sel_ok.gro; echo "tamper" >> $selg
ck "G 篡改后 sel_verify -> 1" '! sel_verify $b $selg'
PROD_MIN_H=0.01; NSTEPS_OVERRIDE_PROD=10; step_prod $b 0 $rd $selg; rc=$?; pd=$(last_attempt $OUT/builds/$b/prod)
ck "G step_prod 篡改起点: rc!=0, STATUS=VOID_SEL_MISMATCH ($(cut -d' ' -f1 $pd/STATUS)), 无 grompp.log, ledger void" '[ $rc != 0 ] && [ "$(cut -d" " -f1 $pd/STATUS)" = VOID_SEL_MISMATCH ] && [ ! -f $pd/grompp.log ] && ledger_has void $b && [ -s $pd/VOID_SEL_MISMATCH.txt ]'
echo "tmp=$W (未删除)"; [ $fail = 0 ] && echo "ALL PASS" || echo "SOME FAIL"; exit $fail
