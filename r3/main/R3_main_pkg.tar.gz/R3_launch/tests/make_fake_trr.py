#!/usr/bin/env python3
"""[TRR-AMEND] 单测用: 造"假 relax 轨迹"的多帧 gro (之后 gmx trjconv 转 trr).
用法: make_fake_trr.py <pass.gro> <fail.gro> <out_multi.gro> <n_pass> [n_total=67] [t0=10050] [dt=75] [bad_idx,...]
帧 i (0-based): i<n_pass 且 i 不在 bad_idx -> 用 pass.gro 的坐标 (起点, 闸门 PASS); 否则用 fail.gro 的坐标 (relax 终帧, 闸门 VOID). 速度恒取 fail.gro 的 (relax 终帧, 带速度). 标题行 't= <ps>'."""
import sys
def rd(p):
    L=open(p).read().split('\n'); n=int(L[1]); return L[2:2+n], L[2+n]
p,f,o,npass=sys.argv[1],sys.argv[2],sys.argv[3],int(sys.argv[4]); n=int(sys.argv[5]) if len(sys.argv)>5 else 67
t0=float(sys.argv[6]) if len(sys.argv)>6 else 10050.0; dt=float(sys.argv[7]) if len(sys.argv)>7 else 75.0
bad=set(int(x) for x in sys.argv[8].split(',')) if len(sys.argv)>8 and sys.argv[8] else set()
pa,pbox=rd(p); fa,fbox=rd(f); assert len(pa)==len(fa)
with open(o,'w') as w:
    for i in range(n):
        a=pa if (i<npass and i not in bad) else fa
        w.write('fake t= %.5f step= %d\n%d\n'%(t0+i*dt,i,len(a)))
        for la,lf in zip(a,fa): w.write(la[:44]+lf[44:]+'\n')   # 坐标 (x,y,z 各8列) 取 a, 速度列取 fail.gro; 原子名/序号两者相同
        w.write((pbox if a is pa else fbox)+'\n')
