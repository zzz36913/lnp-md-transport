#!/bin/bash
# [TRR-AMEND] 选帧逻辑单测 (box, MODE=local, gmx 2025.4 + venv_gate; 不起 docker/Spark): 用 prerun 的 relax.gro (闸门 0/6 的那批终帧, 带速度) 与 start.gro (闸门 PASS) 拼"假 relax.trr" (67 帧, 75 ps 间隔, 末 5 ns).
# 情形: A 前 50 帧起点(其中第 10/20 帧换成终帧=不合格), 后 17 帧终帧(不合格) -> 期望选 idx=49 (t=13725), 合格 48/67
#       B 全 67 帧都是终帧 (DOPC_s1 型) -> 期望 SEL_NONE, 回退末帧, step_gate -> VOID_L2, ledger void
#       C 最后一帧即合格 (n_pass=67) -> 期望选 idx=66 (t=15000) = 末帧
#       D hii 臂不走选帧; SEL_RULE=0 不走选帧
# 用法: bash tests/test_SEL_unit.sh  (只在 /tmp 写; 退出码 0=全过)
T=$(cd "$(dirname "$0")/.." && pwd); PR=${PR:-$(cd $T/.. && pwd)/prerun_results/R3_prerun_1028_175447/relax}; W=$(mktemp -d /tmp/R3selu_XXXX); fail=0
ck(){ if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fail=1; fi; }
export HERE=$T MACHINE=k03 ORCH_PID=$$ J=$W MODE=local EXPECT_GMX=any NT=2 GMX_LOCAL=${GMX_LOCAL:-/workspace/ha_src/gmxenv/bin/gmx} GATE_PY=${GATE_PY:-/workspace/venv_gate/bin/python} GMXLIB=$T/inputs/ff
. $T/lib_R3.sh >/dev/null; OUT=$W/out; OUT_PARENT=$W; mkdir -p $OUT/slots $OUT/ledger; export OUT OUT_PARENT; SLOT_TAG=unit; ROLE=primary; NEEDH=0
mk(){ # mk <build> <fail.gro> <n_pass> [bad_idx]  -> $W/rd_<tag>/ (relax.tpr relax.trr relax.gro 派生 mdp)
  local b=$1 fg=$2 np=$3 bad=${4:-} rd=$W/rd_$5; mkdir -p $rd; local m=$T/inputs/$b/relax_crescale_dev.mdp
  awk '!($1=="nstxout"||$1=="nstvout")' $m > $rd/relax_crescale_dev.mdp; printf 'nstxout = 5000\nnstvout = 5000\n' >> $rd/relax_crescale_dev.mdp
  ( cd $rd && $GMX_LOCAL grompp -f relax_crescale_dev.mdp -c $T/inputs/$b/start.gro -p $T/inputs/$b/sys.top -n $T/inputs/$b/index.ndx -o relax.tpr -maxwarn 0 >grompp.log 2>&1 ) || { echo "grompp fail"; tail -5 $rd/grompp.log; }
  python3 $T/tests/make_fake_trr.py $T/inputs/$b/start.gro $fg $rd/multi.gro $np 67 10050 75 "$bad"
  ( cd $rd && $GMX_LOCAL trjconv -f multi.gro -o relax.trr >trj.log 2>&1 <<<0 ); cp $fg $rd/relax.gro; echo $rd; }
FE=$PR/R3_DOPE_lam_s2/crescale/attempt_001/relax.gro; FC=$PR/R3_DOPC_lam_s1/crescale/attempt_001/relax.gro
# 情形 A
rd=$(mk R3_DOPE_lam_s2 $FE 50 10,20 A | tail -1); SEL_NSTOUT=5000 SEL_WIN_PS=5000 step_select R3_DOPE_lam_s2 $rd; d=$(last_attempt $OUT/builds/R3_DOPE_lam_s2/select)
ck "A STATUS=SEL_OK ($(cat $d/STATUS))" '[ "$(cut -d" " -f1 $d/STATUS)" = SEL_OK ]'
ck "A 窗口帧数 67 ($(grep n_frames_window $d/SELECTED_FRAME.txt))" 'grep -q "n_frames_window=67" $d/SELECTED_FRAME.txt'
ck "A 合格 48/67 ($(grep n_qualified $d/SELECTED_FRAME.txt))" 'grep -q "n_qualified=48" $d/SELECTED_FRAME.txt'
ck "A 选中 t=13725 ($(grep selected_t_ps $d/SELECTED_FRAME.txt))" 'grep -q "selected_t_ps=13725" $d/SELECTED_FRAME.txt'
ck "A SEL_GRO=selected.gro 且带速度" '[ "$SEL_GRO" = $d/selected.gro ] && [ "$(sed -n 3p $d/selected.gro | awk "{print NF}")" = 9 ]'
ck "A 非选中帧 .gro 已清 (剩 $(ls $d/frames | wc -l) 个), frames.tsv 67 行" '[ "$(ls $d/frames | wc -l)" = 1 ] && [ "$(tail -n +2 $d/frames.tsv | wc -l)" = 67 ]'
ck "A 第 10/20 帧 rc=3, 第 49 帧 rc=0, 第 50 帧 rc=3" '[ "$(awk "\$1==10{print \$3}" $d/frames.tsv)" = 3 ] && [ "$(awk "\$1==20{print \$3}" $d/frames.tsv)" = 3 ] && [ "$(awk "\$1==49{print \$3}" $d/frames.tsv)" = 0 ] && [ "$(awk "\$1==50{print \$3}" $d/frames.tsv)" = 3 ]'
ck "A selected.gro sha 与 SELECTED_FRAME.txt 一致" '[ "$(sha256sum $d/selected.gro | cut -d" " -f1)" = "$(grep selected_gro_sha256 $d/SELECTED_FRAME.txt | cut -d= -f2)" ]'
ck "A sel_gro_of 可在续跑时找回" '[ "$(sel_gro_of R3_DOPE_lam_s2)" = $d/selected.gro ]'
step_gate R3_DOPE_lam_s2 $rd $SEL_GRO; ck "A step_gate(选中帧) PASS ($GATE_ST)" '[ "$GATE_ST" = PASS ]'
# 情形 B
rd=$(mk R3_DOPC_lam_s1 $FC 0 "" B | tail -1); step_select R3_DOPC_lam_s1 $rd; d=$(last_attempt $OUT/builds/R3_DOPC_lam_s1/select)
ck "B STATUS=SEL_NONE ($(cut -d' ' -f1 $d/STATUS)) 且 0/67" '[ "$(cut -d" " -f1 $d/STATUS)" = SEL_NONE ] && grep -q "n_qualified=0" $d/SELECTED_FRAME.txt && grep -q "n_frames_window=67" $d/SELECTED_FRAME.txt'
ck "B SEL_GRO 回退为末帧 relax.gro" '[ "$SEL_GRO" = $rd/relax.gro ]'
step_gate R3_DOPC_lam_s1 $rd $SEL_GRO; ck "B step_gate -> VOID_L2 + ledger void ($GATE_ST)" '[ "$GATE_ST" = VOID_L2 ] && ledger_has void R3_DOPC_lam_s1'
ck "B sel_gro_of 为空 (prod 不会用)" '[ -z "$(sel_gro_of R3_DOPC_lam_s1)" ]'
# 情形 C
rd=$(mk R3_DOPE_lam_s3 $PR/R3_DOPE_lam_s3/crescale/attempt_001/relax.gro 67 "" C | tail -1); step_select R3_DOPE_lam_s3 $rd; d=$(last_attempt $OUT/builds/R3_DOPE_lam_s3/select)
ck "C 全合格 -> 选 t=15000 ($(grep -h selected_t_ps $d/SELECTED_FRAME.txt)) 67/67" 'grep -q "selected_t_ps=15000" $d/SELECTED_FRAME.txt && grep -q "n_qualified=67" $d/SELECTED_FRAME.txt'
# 情形 D
SEL_RULE=0 step_select R3_DOPE_lam_s5 $rd; ck "D SEL_RULE=0 不建 select 目录" '[ ! -d $OUT/builds/R3_DOPE_lam_s5/select ]'
step_select R3_DOPE_hii_s1 $rd; ck "D hii 臂不建 select 目录" '[ ! -d $OUT/builds/R3_DOPE_hii_s1/select ]'
echo "tmp=$W (未删除)"; [ $fail = 0 ] && echo "ALL PASS" || echo "SOME FAIL"; exit $fail
