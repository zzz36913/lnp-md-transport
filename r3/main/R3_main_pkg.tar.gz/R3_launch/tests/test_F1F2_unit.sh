#!/bin/bash
# 单元测试 (无 docker, 无 gmx): F1 进程扫描不自命中且仍能抓到外部进程 / flock 防双开; F2 两槽并发取容器名不重复且都在 cleanup 前缀范围内.
# 用法: bash tests/test_F1F2_unit.sh   (只在 /tmp 写; 退出码 0=全过)
T=$(cd "$(dirname "$0")/.." && pwd); fail=0; ck(){ if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fail=1; fi; }
W=$(mktemp -d /tmp/R3ut_XXXX)
# ---- F1 ----
# 1) 外层 "ssh 式" bash -c, 命令行里含 run_R3.sh, 里面再起子 shell/管道 调用 procs_other: 不得命中任何一个自己
OUT1=$(bash -c "# run_R3.sh outer wrapper
 export HERE=$T MACHINE=k03 ORCH_PID=\$\$ J=$W; . $T/lib_R3.sh >/dev/null
 x=\$(procs_other \$\$ 'R2a_machine|R2a_slot|R2b_machine|R2b_slot|run_R2|run_prerun|preflight_R3|run_R3\\.sh'); echo \"[\$x]\"")
ck "F1 自身/祖先/子 shell 不命中 ($OUT1)" '[ "$OUT1" = "[]" ]'
# 2) 同 shell 里真有外部的 run_prerun/run_R3.sh 进程 (独立会话) 必须被抓到
( setsid bash -c 'exec -a "bash /x/run_prerun.sh k03" sleep 20' ) & sleep 0.5
( setsid bash -c 'exec -a "bash /y/run_R3.sh k04" sleep 20' ) & sleep 0.5
OUT2=$(bash -c "export HERE=$T MACHINE=k03 ORCH_PID=\$\$ J=$W; . $T/lib_R3.sh >/dev/null; procs_other \$\$ 'R2a_machine|R2a_slot|R2b_machine|R2b_slot|run_R2|run_prerun|preflight_R3|run_R3\\.sh'")
ck "F1 外部 run_prerun 与另一实例 run_R3.sh 被抓到 (n=$(echo "$OUT2" | grep -c .))" '[ "$(echo "$OUT2" | grep -c "run_prerun\|run_R3.sh")" = 2 ]'
pkill -f 'run_prerun.sh k03' ; pkill -f '/y/run_R3.sh k04'
# 3) flock: 第一个持有时, 第二个 take_lock 失败; 持有者退出后可再取 (不需 rm)
bash -c "export HERE=$T MACHINE=k03 J=$W; . $T/lib_R3.sh >/dev/null; take_lock && sleep 4" & sleep 1
bash -c "export HERE=$T MACHINE=k03 J=$W; . $T/lib_R3.sh >/dev/null; take_lock" ; r1=$?
ck "F1 flock 双开被拒 (rc=$r1)" '[ $r1 != 0 ]'; wait
bash -c "export HERE=$T MACHINE=k03 J=$W; . $T/lib_R3.sh >/dev/null; take_lock"; r2=$?
ck "F1 持有者退出后 flock 可再取 (rc=$r2)" '[ $r2 = 0 ]'
# ---- F2 ---- 用假 docker 记录 --name, 两槽 (A/B) 并发, 每槽对不同 build/阶段多次 gp + 一次 mdrun 名; 任何两次同名即失败
mkdir -p $W/bin; cat > $W/bin/docker <<'EOD'
#!/bin/bash
[ "$1" = run ] || exit 0
n=; for a in "$@"; do [ "$p" = --name ] && n=$a; p=$a; done
echo "$n" >> "$FAKE_DOCKER_LOG"; exit 0
EOD
chmod +x $W/bin/docker; export FAKE_DOCKER_LOG=$W/names.log; : > $FAKE_DOCKER_LOG
cat > $W/two.sh <<EOS
export HERE=$T MACHINE=k03 ORCH_PID=424242 MODE=docker OUT=$W/out OUT_PARENT=$W J=$W PATH=$W/bin:\$PATH; . $T/lib_R3.sh >/dev/null
slot(){ SLOT_TAG=\$1; shift; for b in "\$@"; do for st in relax prod; do d=$W/out/builds/\$b/\$st/attempt_001; mkdir -p \$d; gp \$d \$st m.mdp c.gro t.top n.ndx 0; done; done; }
( slot k03_A R3_DOPE_lam_s2 R3_DOPE_lam_s5 ) & ( slot k03_B R3_DOPC_lam_s1 R3_DOPC_lam_s3 ) & ( slot k03_A R3_DOPE_hii_s1 ) & wait
EOS
bash $W/two.sh >/dev/null 2>&1
n=$(wc -l < $FAKE_DOCKER_LOG); u=$(sort -u $FAKE_DOCKER_LOG | wc -l); bad=$(grep -vc '^R3_k03_424242_' $FAKE_DOCKER_LOG)
ck "F2 并发 gp 容器名共 $n 个, 唯一 $u" '[ "$n" = 10 ] && [ "$u" = "$n" ]'
ck "F2 全部落在 ^R3_<机>_<pid>_ 范围 (越界 $bad)" '[ "$bad" = 0 ]'
# 默认 gx 名 (无 CN) 在并发子 shell 里也不同
: > $FAKE_DOCKER_LOG
cat > $W/three.sh <<EOS
export HERE=$T MACHINE=k03 ORCH_PID=424242 MODE=docker OUT=$W/out OUT_PARENT=$W J=$W PATH=$W/bin:\$PATH; . $T/lib_R3.sh >/dev/null
( SLOT_TAG=k03_A; gx grompp ) & ( SLOT_TAG=k03_B; gx grompp ) & wait
EOS
bash $W/three.sh >/dev/null 2>&1
ck "F2 默认 gx 名并发不重名且在前缀内" '[ "$(sort -u $FAKE_DOCKER_LOG | wc -l)" = 2 ] && [ "$(grep -c "^R3_k03_424242_" $FAKE_DOCKER_LOG)" = 2 ]'
echo "示例名: $(sort -u $W/names.log | head -3 | tr '\n' ' ')"; echo "tmp=$W (未删除)"; [ $fail = 0 ] && echo "ALL PASS" || echo "SOME FAIL"; exit $fail
