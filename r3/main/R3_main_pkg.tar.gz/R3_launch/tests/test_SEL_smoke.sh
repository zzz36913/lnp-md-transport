#!/bin/bash
# [TRR-AMEND] box 冒烟 (MODE=local, 真 gmx 2025.4, nsteps 极小): 单条 lam build 走 relax(写 trr) -> step_select(逐帧闸门, 选最后合格帧) -> step_gate(选中帧) -> prod(-c selected.gro, 无 -t).
# 用法: bash tests/test_SEL_smoke.sh [build=R3_DOPE_lam_s2]   环境: GMX_LOCAL(默认 /workspace/ha_src/gmxenv/bin/gmx) GATE_PY(默认 /workspace/venv_gate/bin/python)
T=$(cd "$(dirname "$0")/.." && pwd); B=${1:-R3_DOPE_lam_s2}; W=$(mktemp -d /tmp/R3sel_XXXX)
export HERE=$T MACHINE=k03 ORCH_PID=$$ J=$W MODE=local EXPECT_GMX=any NT=2 GMX_LOCAL=${GMX_LOCAL:-/workspace/ha_src/gmxenv/bin/gmx} GATE_PY=${GATE_PY:-/workspace/venv_gate/bin/python}
export NSTEPS_OVERRIDE_RELAX=${NSTEPS_OVERRIDE_RELAX:-200} NSTEPS_OVERRIDE_PROD=${NSTEPS_OVERRIDE_PROD:-100} SEL_NSTOUT=${SEL_NSTOUT:-25} SEL_WIN_PS=${SEL_WIN_PS:-1.5}   # relax 200 步*0.015=3 ps; 末 1.5 ps 内每 25 步(0.375 ps)一帧
. $T/lib_R3.sh >/dev/null; OUT=$W/out; OUT_PARENT=$W; mkdir -p $OUT/slots $OUT/ledger; export OUT OUT_PARENT; SLOT_TAG=smoke; DEADLINE="2099-01-01 00:00 +0800"; DL=$(date -d "$DEADLINE" +%s)
run_build $B primary 0 main; echo "run_build rc=$?"
for s in relax select gate prod; do d=$(last_attempt $OUT/builds/$B/$s); echo "$s: $(basename "$d") $(cat $d/STATUS 2>/dev/null)"; done
d=$(last_attempt $OUT/builds/$B/select); cat $d/SELECTED_FRAME.txt; cat $d/frames.tsv; ls $d/frames | head; echo "--- relax mdp diff:"; cat $(last_attempt $OUT/builds/$B/relax)/mdp_diff_trr.txt
echo "--- prod grompp cmd/START:"; cat $(last_attempt $OUT/builds/$B/prod)/START_FRAME.txt; echo "tmp=$W"
