#!/usr/bin/env python3
"""collect_prerun.py -- 收 R3 预跑回传. 只输出三件工程读数, 无任何 DOPE/DOPC 科学判读, 无 G-R3 判读:
  (1) 能否过 preflight (gmx 版本 + maxwarn 0 下各 mdp 的 grompp 通过数 + 警告原文去重)
  (2) relax 后起点资格合格率 (起点资格 = 与 t=0 完全同款的 t0_gate.py --level prod0, 即 ncl/wind/npol/wpol=2/2/2/2 @ 0.65/0.75/0.95 且 v1==v2)
  (3) 实际 ns/day (新协议 PR 各向异性 tau_p=12 nst=3 的短 prod 的 Performance 行; 以及 relax 的 Performance)
用法: python3 collect_prerun.py <回传的 R3_prerun_<TS> 目录> [--out <新目录>] [--py /workspace/venv_r2/bin/python]
只在 box 上跑; 只读回传目录; 结果写到一个新目录(默认 <回传目录>_collect_<TS>, 已存在则报错退出)."""
import argparse, csv, glob, json, os, re, subprocess, sys, time, hashlib
T0 = '/workspace/lnp-md/scan/R3_remediation/R3_pkg/scripts/t0_gate.py'   # 与 t=0 同款闸门脚本(原件, 不改); 其依赖 analyzer_v2/topo_v2.py
EST_PROD = 15188.0   # compute_estimate_R3.py v2 的 R3 prod 吞吐估算(ns/day/槽, 估算) —— 仅用于算 实际/估算 比值
ap = argparse.ArgumentParser(); ap.add_argument('root'); ap.add_argument('--out'); ap.add_argument('--py', default='/workspace/venv_r2/bin/python')
ap.add_argument('--expect-lipids', type=int, default=960); ap.add_argument('--expect-w', type=int, default=720); a = ap.parse_args()
root = os.path.abspath(a.root); rows = list(csv.DictReader(open(os.path.join(root, 'ALL_RECORDS.tsv')), delimiter='\t'))
out = a.out or root.rstrip('/') + '_collect_' + time.strftime('%m%d_%H%M%S')
os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True); os.mkdir(out)   # 已存在则抛错, 不覆盖
os.mkdir(os.path.join(out, 't0'))

def local(r):   # 把记录里的(Spark 端)attempt 路径映射到回传目录: 取最后 4 级 stage/build/arm/attempt_NNN
    p = r['attempt_dir'].rstrip('/').split('/'); return os.path.join(root, *p[-4:])
latest = {}
for r in rows:   # attempt 编号大者为有效; 全部 attempt 都保留在 ALL_RECORDS 里
    k = (r['stage'], r['build'], r['arm_or_mdp']); d = local(r)
    if k not in latest or d > latest[k][0]: latest[k] = (d, r)
meta = sorted(glob.glob(os.path.join(root, 'META_*.txt')))
gmxv = sorted({r['gmx_version'] for r in rows})
L = []; P = L.append
P(f'# R3 预跑收数 (只含: 能否过 preflight / relax 后合格率 / 实际 ns/day; 无 DOPE-DOPC 科学结论, 无 G-R3 判读)')
P(f'- 回传目录: {root}\n- 记录数: {len(rows)} (含所有 attempt); 有效(每步最新 attempt): {len(latest)}\n- gmx 版本: {", ".join(gmxv)}\n- META: {", ".join(os.path.basename(m) for m in meta)}')
# ---------- (1) preflight ----------
P('\n## (1) 能否过 preflight (grompp, maxwarn 0, CPU)')
pre = {k: v for k, v in latest.items() if k[0] == 'preflight'}; by = {}
for (s, b, m), (d, r) in pre.items(): by.setdefault(m, []).append((b, r, d))
P('| mdp | 通过/总数 | 警告数分布(通过=0 警告) | 结论(机械) |\n|---|---|---|---|')
uniq = {}
for m in sorted(by):
    ok = sum(1 for b, r, d in by[m] if r['grompp_rc'] == '0'); dist = {}
    for b, r, d in by[m]:
        dist[r['n_warn']] = dist.get(r['n_warn'], 0) + 1
        wf = os.path.join(d, 'warnings.txt')
        if os.path.exists(wf):
            t = open(wf, errors='replace').read().strip()
            if t:
                h = hashlib.sha1(re.sub(r'\[file [^,\]]*/([^/,\]]+)', r'[file \1', t).encode()).hexdigest()[:8]   # 仅哈希键忽略路径前缀, 输出仍存原文
                uniq.setdefault(h, [t, set(), set()])[1].add(m); uniq[h][2].add(b)
    P(f'| {m} | {ok}/{len(by[m])} | {dict(sorted(dist.items()))} | {"能过" if ok == len(by[m]) else "不能过 maxwarn 0"} |')
allok = bool(pre) and all(r['grompp_rc'] == '0' for (d, r) in pre.values())
P(f'\n**能否过 preflight(全部 mdp 在 maxwarn 0 下): {"能" if allok else "不能"}**')
uf = open(os.path.join(out, 'preflight_warnings_unique.txt'), 'w')
for h, (t, ms, bs) in sorted(uniq.items()):
    uf.write(f'### 警告块 {h}  出现于 mdp={sorted(ms)}  构建数={len(bs)}\n{t}\n\n')
uf.close(); P(f'- 去重后警告原文块 {len(uniq)} 个 -> {out}/preflight_warnings_unique.txt (逐条原文; 各 attempt 的 warnings.txt 为全量)')
# ---------- (2) relax 后合格率 ----------
P('\n## (2) relax 后起点资格 (t0_gate.py --level prod0, 同 t=0 款; 工程读数)')
rel = {k: v for k, v in latest.items() if k[0] == 'relax'}; arms = {}
detail = []
for (s, b, arm), (d, r) in sorted(rel.items()):
    A = arms.setdefault(arm, dict(tried=0, done=0, qual=0, fail=0)); A['tried'] += 1
    t0path = 'NA'; verdict = r['state']; read = ''
    if r['state'] == 'DONE' and os.path.exists(os.path.join(d, 'relax.gro')):
        A['done'] += 1; jf = os.path.join(out, 't0', f'relax__{b}__{arm}__{os.path.basename(d)}.json'); t0path = jf
        p = subprocess.run([a.py, T0, os.path.join(d, 'relax.gro'), '--level', 'prod0', '--arm', 'lam', '--expect-lipids', str(a.expect_lipids), '--expect-w', str(a.expect_w), '--json', jf], capture_output=True, text=True)
        if os.path.exists(jf):
            j = json.load(open(jf)); verdict = j['verdict']; read = '; '.join(f"{c}: v1={x['v1']} v2={x['v2']}" for c, x in j['readings'].items())
            A['qual'] += verdict == 'PASS'
        else: verdict = 'T0_ERROR'; read = p.stderr[-200:]
    else: A['fail'] += 1
    detail.append((b, arm, os.path.basename(d), r['state'], r['maxwarn'], r['n_warn'], r['performance_ns_day'], verdict, read, r['input_gro'], r['grompp_log'], r['mdrun_log'], t0path))
P('| relax 臂 | 尝试构建数 | relax 完成 | 起点资格 PASS | 合格率(PASS/完成) | 合格率(PASS/尝试) | 失败(grompp/mdrun) |\n|---|---|---|---|---|---|---|')
for arm, A in sorted(arms.items()):
    P(f"| {arm} | {A['tried']} | {A['done']} | {A['qual']} | {A['qual']}/{A['done']}" + (f" = {A['qual']/A['done']:.0%}" if A['done'] else '') + f" | {A['qual']}/{A['tried']}" + (f" = {A['qual']/A['tried']:.0%}" if A['tried'] else '') + f" | {A['fail']} |")
P('\n逐构建(输入/日志/Performance/起点资格读数路径见 prerun_summary.tsv):\n| 构建 | 臂 | attempt | 状态 | maxwarn | 警告数 | relax ns/day | 起点资格 | 读数(2/2/2/2 = ncl/wind/npol/wpol) |\n|---|---|---|---|---|---|---|---|---|')
for x in detail: P('| ' + ' | '.join(str(v) for v in x[:9]) + ' |')
P('\n注: crescale 臂 = 偏离 SI 协议的 c-rescale 半各向同性开发臂, 力场/SI 字节一致性未核; 本表不比较两臂孰优, 只给各臂合格率.')
# ---------- (3) 吞吐 ----------
P('\n## (3) 实际 ns/day (新协议: v-rescale + Parrinello-Rahman 各向异性 tau_p=12, nstpcouple=nsttcouple=3, dt 20 fs; 2 槽并行)')
tp = {k: v for k, v in latest.items() if k[0] == 'tp'}; vals = []
P('| 构建 | 来源 relax 臂 | 状态 | 步数 | Performance ns/day | 实际/估算(15188) | 日志 |\n|---|---|---|---|---|---|---|')
for (s, b, arm), (d, r) in sorted(tp.items()):
    try: v = float(r['performance_ns_day'])
    except Exception: v = None
    if v and r['state'] in ('DONE', 'TRUNC_MAXH'): vals.append(v)
    P(f"| {b} | {arm} | {r['state']} | {r['nsteps_run']} | {r['performance_ns_day']} | " + (f'{v/EST_PROD:.3f}' if v else 'NA') + f" | {r['perf_log']} |")
if vals: P(f'\n**实际 ns/day: 各槽 {", ".join(f"{v:.0f}" for v in vals)}; 平均 {sum(vals)/len(vals):.0f}; 对 15188(估算)比值 {sum(vals)/len(vals)/EST_PROD:.3f}**')
else: P('\n**实际 ns/day: 无有效读数**')
rp = []
for (s, b, arm), (d, r) in rel.items():
    try: rp.append(float(r['performance_ns_day']))
    except Exception: pass
if rp: P(f'- relax(dt 15 fs)ns/day: n={len(rp)} 平均 {sum(rp)/len(rp):.0f}' + (f'; 对 tp 平均比值 {sum(rp)/len(rp)/(sum(vals)/len(vals)):.3f} (compute_estimate 假设 0.75)' if vals else ''))
if len(vals) < 2: P('- 注: 少于 2 槽有效读数, 不能代表 2 槽并行吞吐')
open(os.path.join(out, 'prerun_summary.md'), 'w').write('\n'.join(L) + '\n')
with open(os.path.join(out, 'prerun_summary.tsv'), 'w', newline='') as f:
    w = csv.writer(f, delimiter='\t'); w.writerow(['build', 'arm', 'attempt', 'state', 'maxwarn', 'n_warn', 'perf_ns_day', 'qualification', 'readings', 'input_gro', 'grompp_log', 'mdrun_log', 't0_readout_json']); [w.writerow(x) for x in detail]
print('\n'.join(L)); print(f'\n-> {out}/prerun_summary.md / .tsv')
