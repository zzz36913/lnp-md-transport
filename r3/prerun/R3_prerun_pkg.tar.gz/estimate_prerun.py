#!/usr/bin/env python3
"""预跑槽位小时估算 (全部「估算」, 未实测; 预跑本身就是要替换其中 15188). 约定: slot·h = ns / (ns/day) * 24; 一个槽 = 一张 GPU 上的一个 MPS 份额; 预跑用 2 槽."""
R_PROD = 15188.0      # ns/day/槽: compute_estimate_R3.py v2 的 R3(12240 珠)估算 = 15000(R2a 实测 14343-16290 的取整) * 12393/12240 之类的线性珠数缩放; 未对新协议实测
RELAX_RATIO = 0.75    # relax dt 15 fs vs prod dt 20 fs -> 同样 wall 下 ns/day 为 0.75 倍 (估算, 同 compute_estimate v2)
RELAX_NS, TP_NS = 15.0, 50.0
OVH = 0.03            # 每个 grompp+mdrun 步骤的容器启动/IO/空转开销 (h), 假设, 未测
for f in (1.0, 0.8, 0.5):
    rp, rr = R_PROD*f, R_PROD*f*RELAX_RATIO
    one_relax = RELAX_NS/rr*24; one_tp = TP_NS/rp*24
    print(f'吞吐系数 f={f}: prod {rp:.0f} ns/day, relax {rr:.0f} ns/day; 单个 relax {one_relax:.4f} 槽·h({one_relax*60:.1f} min); 单个 {TP_NS:.0f} ns tp {one_tp:.4f} 槽·h({one_tp*60:.1f} min)')
    for name, nrelax in (('名义: 6 构建 literal(maxwarn 2) 全过, 无 crescale', 6), ('最坏: literal+crescale 各 6 (RUN_CRESCALE=1 或 literal grompp 全失败)', 12)):
        ntp = 2; tot = nrelax*one_relax + ntp*one_tp + (nrelax+ntp)*OVH
        wall = (nrelax/2*one_relax + one_tp + (nrelax/2+1)*OVH)   # 两槽并行, relax 平分, 再同时开跑 tp
        print(f'   {name}: relax {nrelax*one_relax:.2f} + tp {ntp*one_tp:.2f} + 开销 {(nrelax+ntp)*OVH:.2f} = {tot:.2f} 槽·h; 墙钟 ≈ {wall:.2f} h (+预检 CPU 若干分钟, 不占槽)')
print('目标 <= 4 槽·h: 上面最坏 f=0.5 仍远低于 4, 无需缩 relax 构建数/prod 长度. 最坏总计 ≈ 0.538/f + 0.42 槽·h, 仅当实测 f < 约 0.15(估算)才会超 4 槽·h; 届时把 literal 臂每格构建数 3→2 或 tp 50→20 ns.')
