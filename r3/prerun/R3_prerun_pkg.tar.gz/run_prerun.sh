#!/bin/bash
# run_prerun.sh -- R3 预跑: (a) B2 预检  (b) B3+B1 relax 15 ns + 起点资格(在 box 上由 collect_prerun.py 读)  (c) PR 各向异性新协议吞吐.
# 只写文件; 只在 $J/R3_prerun_<TS>/ 下新增内容; 不覆盖/删除任何已有文件; 不触碰任何 GLM/ZCode/端口/key/他人容器.
# 用法:
#   bash run_prerun.sh                      # 全流程 preflight -> relax -> tp (TS 由本脚本运行时生成; 目录已存在则报错退出)
#   STAGES="preflight" bash run_prerun.sh   # 只做某些阶段(preflight|relax|tp 的空格分隔子集)
#   APPEND_TO=$J/R3_prerun_<TS> STAGES="relax tp" bash run_prerun.sh   # 重试: 只新增 attempt_NNN, 已 DONE 的步骤跳过, 旧 attempt 一字不改
#   DRY=1 MODE=local bash run_prerun.sh     # 只打印计划/检查输入+MANIFEST, 不依赖 Spark, 不创建输出
# ======================= 逐步 maxwarn (每步独立; 默认 0; 想放行须发车人在命令行显式设置, 并写入 META.txt) =======================
MAXWARN_PREFLIGHT=0                                          # (a) 固定 0, 在 preflight_R3.sh 内 readonly
MAXWARN_RELAX_LITERAL=${MAXWARN_RELAX_LITERAL:-0}            # (b) 逐字 Berendsen 各向异性 relax 的 grompp; B1 路径 A 需 K 批准后显式设 2 (box 2025.4 实测 2 条警告, 见 B1_warnings.md)
MAXWARN_RELAX_CRESCALE=${MAXWARN_RELAX_CRESCALE:-0}          # (b) relax_crescale_dev 对照 (box 2025.4 实测 0 条)
MAXWARN_TP_PROD=${MAXWARN_TP_PROD:-0}                        # (c) 新协议 prod (v-rescale + PR 各向异性 tau_p=12, nst=3) 的 grompp
# ======================= 其它可调 (均有默认; 值会写进 META.txt) =======================
STAGES=${STAGES:-"preflight relax tp"}
RUN_CRESCALE=${RUN_CRESCALE:-auto}      # auto: 仅当该构建 literal grompp 失败时跑 crescale 对照; 1: 总是跑; 0: 不跑. (对照臂=偏离 SI 协议的 c-rescale 半各向同性开发臂, 力场/SI 字节一致性未核)
RELAX_NSTEPS=${RELAX_NSTEPS:-}          # 空=用 tpr 的 1e6 步(15 ns@15 fs); 仅 box 冒烟时设小值
RELAX_MAXH=${RELAX_MAXH:-0.6}           # 单个 relax 的 mdrun 时限(h), 防挂死 (估算 ≈0.04 slot·h 即 ≈2.4 min, 留 15× 余量)
TP_NSTEPS=${TP_NSTEPS:-2500000}         # 新协议吞吐: 2.5e6 步 × 20 fs = 50 ns
TP_MAXH=${TP_MAXH:-0.5}                 # 吞吐 run 时限(h)
PINOFF_A=${PINOFF_A:-15}; PINOFF_B=${PINOFF_B:-5}   # 与 R2a_machine.sh 的两槽钉核一致
HERE=$(cd "$(dirname "$0")" && pwd); . "$HERE/lib_prerun.sh"
if [ "$MODE" = local ]; then PIN_A=""; PIN_B=""; GPUF=""; else
  PIN_A=${PINFLAGS_A-"-pin on -pinoffset $PINOFF_A -pinstride 1"}; PIN_B=${PINFLAGS_B-"-pin on -pinoffset $PINOFF_B -pinstride 1"}; GPUF=${GPUFLAGS-"-nb gpu -update cpu"}; fi
SETTINGS="MODE=$MODE STAGES=[$STAGES] maxwarn{preflight=$MAXWARN_PREFLIGHT relax_literal=$MAXWARN_RELAX_LITERAL relax_crescale=$MAXWARN_RELAX_CRESCALE tp_prod=$MAXWARN_TP_PROD} RUN_CRESCALE=$RUN_CRESCALE RELAX_NSTEPS=${RELAX_NSTEPS:-tpr(1e6)} RELAX_MAXH=$RELAX_MAXH TP_NSTEPS=$TP_NSTEPS TP_MAXH=$TP_MAXH NT=$NT builds_A=[$BUILDS_DOPE] builds_B=[$BUILDS_DOPC] IMG=$IMG G=$G"
echo "== run_prerun  $SETTINGS"
check_inputs $PRE_BUILDS || exit 1
if [ -n "${DRY:-}" ]; then
  echo "[DRY] 槽 A(pin $PINOFF_A): $BUILDS_DOPE ; 槽 B(pin $PINOFF_B): $BUILDS_DOPC"
  for st in $STAGES; do case $st in
    preflight) echo "[DRY] stage preflight: bash preflight_R3.sh (maxwarn $MAXWARN_PREFLIGHT, $(for b in $PRE_BUILDS; do ls $INP/$b/*.mdp; done | wc -l) 个 mdp)";;
    relax) for b in $BUILDS_DOPE $BUILDS_DOPC; do echo "[DRY] relax $b: literal(grompp -maxwarn $MAXWARN_RELAX_LITERAL; mdrun ${RELAX_NSTEPS:-1e6} 步) ; crescale(RUN_CRESCALE=$RUN_CRESCALE, -maxwarn $MAXWARN_RELAX_CRESCALE) -> attempt_NNN"; done;;
    tp) echo "[DRY] tp: 每槽取该槽首个 relax DONE 构建的 relax.gro/.cpt, grompp(prod_lam.mdp, -t relax.cpt, -maxwarn $MAXWARN_TP_PROD), mdrun -nsteps $TP_NSTEPS -maxh $TP_MAXH, 两槽同时开跑, 读 Performance 行";;
    *) echo "ABORT: 未知阶段 $st"; exit 1;; esac; done
  echo "[DRY] 不创建输出目录, 不调用 gmx/docker/MPS"; exit 0; fi
need_cmd; init_out; export APPEND; GMXV=$(gmx_version); check_gmxv
cp_meta(){ { echo "TS_dir=$OUT"; echo "start=$(date +%FT%T%z)"; echo "host=$(hostname)"; echo "gmx_version=$GMXV"; echo "settings=$SETTINGS"; echo "pkg_manifest_sha256=$(sha256sum "$HERE/MANIFEST_sha256.txt" 2>/dev/null | cut -c1-64)"; echo "run_prerun.sh_sha256=$(sha256sum "$0" | cut -c1-64)"; [ -n "${APPEND:-}" ] && echo "mode=APPEND_TO (新增 attempt, 旧文件不动)"; command -v nvidia-smi >/dev/null && nvidia-smi --query-gpu=name,driver_version --format=csv,noheader; } > "$OUT/META_$(date +%H%M%S).txt"; }
cp_meta; [ -f "$OUT/ALL_RECORDS.tsv" ] || printf '%s\n' "$REC_HEADER" >> "$OUT/ALL_RECORDS.tsv"
echo "OUT=$OUT gmx=$GMXV"
CNPFX=R3PRE_$(basename "$OUT")
cleanup(){ mps_stop; [ "$MODE" = docker ] && for c in $(docker ps -q --filter "name=$CNPFX"); do docker stop -t 30 $c >/dev/null 2>&1; done; }   # 只停本脚本起的 R3PRE_<目录名>* 容器
trap 'cleanup; echo "中断: 已停本脚本容器/MPS; 已写的文件保留"; exit 130' INT TERM
trap 'cleanup' EXIT

# ---- relax 单臂 (一个 attempt): relax_arm <slot> <build> <arm: literal|crescale> <mdp名> <maxwarn> <pin>
relax_arm(){ local slot=$1 b=$2 arm=$3 mdp=$4 mw=$5 pin=$6 s d st mrc perf; s=$OUT/relax/$b/$arm
  [ -n "${APPEND:-}" ] && [ "$(last_state $s)" = DONE ] && { echo "[$slot] skip(已DONE) $b $arm"; return 0; }
  d=$(new_attempt $s); export CN=${CNPFX}_${slot}
  gp $d relax $INP/$b/$mdp.mdp $INP/$b/start.gro $INP/$b/sys.top $INP/$b/index.ndx $mw
  if [ $GP_RC -ne 0 ]; then setstat $d FAIL_GROMPP "rc=$GP_RC n_warn=$GP_NW maxwarn=$mw"
    rec "$(date +%FT%T%z)" relax $b $arm $d FAIL_GROMPP "$GMXV" $mw $GP_RC $GP_NW NA NA NA $INP/$b/start.gro $INP/$b/$mdp.mdp $INP/$b/sys.top $d/grompp.log $d/warnings.txt NA NA NA; echo "[$slot] $b $arm FAIL_GROMPP rc=$GP_RC n_warn=$GP_NW"; return 1; fi
  ( cd $d && GXG=1 gx mdrun -deffnm relax -ntmpi 1 -ntomp $NT $GPUF $pin -maxh $RELAX_MAXH ${RELAX_NSTEPS:+-nsteps $RELAX_NSTEPS} ) > $d/mdrun.out 2>&1; mrc=$?
  perf=$(awk '/^Performance:/{print $2}' $d/relax.log 2>/dev/null | tail -1); perf=${perf:-NA}
  if [ $mrc -ne 0 ]; then st=FAIL_MDRUN; elif [ "$(nanchk $d/mdrun.out)" -gt 0 ] || [ "$(nanchk $d/relax.log)" -gt 0 ]; then st=FAIL_NAN
  elif ! grep -q '^Finished mdrun' $d/relax.log 2>/dev/null; then st=FAIL_NOFINISH
  elif grep -q 'Run time exceeded' $d/relax.log 2>/dev/null; then st=TRUNC_MAXH
  else st=DONE; fi
  setstat $d $st "mrc=$mrc perf=$perf n_warn=$GP_NW maxwarn=$mw"
  rec "$(date +%FT%T%z)" relax $b $arm $d $st "$GMXV" $mw $GP_RC $GP_NW $mrc ${RELAX_NSTEPS:-1000000} $perf $INP/$b/start.gro $INP/$b/$mdp.mdp $INP/$b/sys.top $d/grompp.log $d/warnings.txt $d/mdrun.out $d/relax.log "t0/relax__${b}__${arm}__$(basename $d).json"
  echo "[$slot] $b $arm $st perf=$perf ns/day n_warn=$GP_NW"; [ $st = DONE ]; }
relax_slot(){ local slot=$1 pin=$2; shift 2; local b ok
  for b in "$@"; do relax_arm $slot $b literal relax_literal $MAXWARN_RELAX_LITERAL "$pin"; ok=$?
    case $RUN_CRESCALE in 1) relax_arm $slot $b crescale relax_crescale_dev $MAXWARN_RELAX_CRESCALE "$pin";; auto) [ $ok -ne 0 ] && relax_arm $slot $b crescale relax_crescale_dev $MAXWARN_RELAX_CRESCALE "$pin";; esac; done; }
# ---- 吞吐: tp_slot <slot> <pin> <builds...>; 取首个有 relax DONE 的构建(literal 优先, 否则 crescale)
tp_slot(){ local slot=$1 pin=$2; shift 2; local b arm src="" sd s d mrc perf st
  for b in "$@"; do for arm in literal crescale; do sd=$(ls -1d $OUT/relax/$b/$arm/attempt_[0-9][0-9][0-9] 2>/dev/null | sort | while read x; do grep -q '^DONE' $x/STATUS 2>/dev/null && echo $x; done | tail -1); [ -n "$sd" ] && { src=$sd; break 2; }; done; done
  [ -n "$src" ] || { echo "[$slot] tp: 没有可用 relax 结果, 跳过"; return 1; }
  b=$(echo $src | sed 's#.*/relax/\([^/]*\)/.*#\1#'); arm=$(echo $src | sed 's#.*/relax/[^/]*/\([^/]*\)/attempt.*#\1#')
  s=$OUT/tp/$b/from_$arm; [ -n "${APPEND:-}" ] && [ "$(last_state $s)" = DONE ] && { echo "[$slot] skip(已DONE) tp $b"; return 0; }
  d=$(new_attempt $s); export CN=${CNPFX}_${slot}_tp
  gp $d tp $INP/$b/prod_lam.mdp $src/relax.gro $INP/$b/sys.top $INP/$b/index.ndx $MAXWARN_TP_PROD -t $src/relax.cpt
  if [ $GP_RC -ne 0 ]; then setstat $d FAIL_GROMPP "rc=$GP_RC n_warn=$GP_NW maxwarn=$MAXWARN_TP_PROD"
    rec "$(date +%FT%T%z)" tp $b from_$arm $d FAIL_GROMPP "$GMXV" $MAXWARN_TP_PROD $GP_RC $GP_NW NA NA NA $src/relax.gro $INP/$b/prod_lam.mdp $INP/$b/sys.top $d/grompp.log $d/warnings.txt NA NA NA; echo "[$slot] tp $b FAIL_GROMPP"; return 1; fi
  ( cd $d && GXG=1 gx mdrun -deffnm tp -ntmpi 1 -ntomp $NT $GPUF $pin -nsteps $TP_NSTEPS -maxh $TP_MAXH ) > $d/mdrun.out 2>&1; mrc=$?
  perf=$(awk '/^Performance:/{print $2}' $d/tp.log 2>/dev/null | tail -1); perf=${perf:-NA}
  if [ $mrc -ne 0 ]; then st=FAIL_MDRUN; elif [ "$(nanchk $d/mdrun.out)" -gt 0 ] || [ "$(nanchk $d/tp.log)" -gt 0 ]; then st=FAIL_NAN; elif ! grep -q '^Finished mdrun' $d/tp.log 2>/dev/null; then st=FAIL_NOFINISH; elif grep -q 'Run time exceeded' $d/tp.log 2>/dev/null; then st=TRUNC_MAXH; else st=DONE; fi
  setstat $d $st "mrc=$mrc perf=$perf concurrent_slots=2 steps=$TP_NSTEPS"
  rec "$(date +%FT%T%z)" tp $b from_$arm $d $st "$GMXV" $MAXWARN_TP_PROD $GP_RC $GP_NW $mrc $TP_NSTEPS $perf $src/relax.gro $INP/$b/prod_lam.mdp $INP/$b/sys.top $d/grompp.log $d/warnings.txt $d/mdrun.out $d/tp.log "NA(吞吐 run 不做起点资格)"
  echo "[$slot] tp $b(from $arm) $st perf=$perf ns/day"; [ $st = DONE ]; }

for st in $STAGES; do case $st in
  preflight) PRERUN_OUT=$OUT APPEND_TO= bash "$HERE/preflight_R3.sh" ;;
  relax) mps_start
    relax_slot A "$PIN_A" $BUILDS_DOPE & pa=$!; relax_slot B "$PIN_B" $BUILDS_DOPC & pb=$!; wait $pa; wait $pb;;
  tp) mps_start
    tp_slot A "$PIN_A" $BUILDS_DOPE & pa=$!; tp_slot B "$PIN_B" $BUILDS_DOPC & pb=$!; wait $pa; wait $pb;;
  *) echo "ABORT: 未知阶段 $st"; exit 1;; esac; done
echo "== 完成. 回传整个 $OUT (或至少 ALL_RECORDS.tsv + META_*.txt + 各 attempt 的 STATUS/*.log/relax.gro/relax.cpt/tp.log). 在 box 上: python3 collect_prerun.py <回传目录>"
