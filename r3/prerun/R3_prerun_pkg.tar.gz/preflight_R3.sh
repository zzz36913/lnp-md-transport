#!/bin/bash
# preflight_R3.sh -- B2: Spark 上 gmx 2026.3 的 CPU grompp 预检 (只 grompp, 不 mdrun, 不占 GPU).
# 用法: bash preflight_R3.sh              (新建 $J/R3_prerun_<TS>/preflight/...; 目录已存在则报错退出)
#       PRERUN_OUT=<dir> bash preflight_R3.sh   (由 run_prerun.sh 调用, 复用其输出目录)
#       APPEND_TO=<已有 R3_prerun_ 目录> bash preflight_R3.sh   (重试: 只新增 attempt_NNN, 旧的不动)
#       DRY=1 MODE=local bash preflight_R3.sh   (只打印计划+检查输入, 不依赖 Spark)
# ---- 逐步 maxwarn (本脚本内固定 0, 不接受环境变量覆盖: 预检的目的就是原样看到全部警告) ----
readonly MAXWARN_PREFLIGHT=0
# 覆盖: 每个构建的 relax_literal / relax_crescale_dev / relax_hybrid_vrescaleT_berendsenP (relax 三种) + prod_lam / prod_hii (PR 各向异性 tau_p=12, nstpcouple=nsttcouple=3)
HERE=$(cd "$(dirname "$0")" && pwd); . "$HERE/lib_prerun.sh"
MDPS_ALL="relax_literal relax_crescale_dev relax_hybrid_vrescaleT_berendsenP prod_lam prod_hii"
echo "== preflight_R3  MODE=$MODE  maxwarn=$MAXWARN_PREFLIGHT  builds: $PRE_BUILDS"
check_inputs $PRE_BUILDS || exit 1
if [ -n "${DRY:-}" ]; then
  for b in $PRE_BUILDS; do for m in $MDPS_ALL; do [ -f "$INP/$b/$m.mdp" ] && echo "[DRY] grompp -f $INP/$b/$m.mdp -c $INP/$b/start.gro -p $INP/$b/sys.top -n $INP/$b/index.ndx (GMXLIB=$FF) -maxwarn $MAXWARN_PREFLIGHT   -> \$OUT/preflight/$b/$m/attempt_NNN/"; done; done
  echo "[DRY] 不创建输出目录, 不调用 gmx/docker"; exit 0; fi
need_cmd; init_out; GMXV=$(gmx_version); check_gmxv; echo "OUT=$OUT  gmx=$GMXV"
for b in $PRE_BUILDS; do for m in $MDPS_ALL; do [ -f "$INP/$b/$m.mdp" ] || continue
  s=$OUT/preflight/$b/$m; [ -n "${APPEND:-}" ] && [ "$(last_state $s)" = DONE ] && { echo "skip(已DONE) $b $m"; continue; }
  d=$(new_attempt $s); gp $d $m $INP/$b/$m.mdp $INP/$b/start.gro $INP/$b/sys.top $INP/$b/index.ndx $MAXWARN_PREFLIGHT
  [ $GP_RC -eq 0 ] && st=DONE || st=FAIL_GROMPP; setstat $d $st "rc=$GP_RC n_warn=$GP_NW"
  rec "$(date +%FT%T%z)" preflight $b $m $d $st "$GMXV" $MAXWARN_PREFLIGHT $GP_RC $GP_NW NA NA NA $INP/$b/start.gro $INP/$b/$m.mdp $INP/$b/sys.top $d/grompp.log $d/warnings.txt NA NA NA
  printf '%-18s %-40s rc=%s n_warn=%s %s\n' $b $m $GP_RC $GP_NW $st; done; done
echo "== preflight 完成: $OUT/ALL_RECORDS.tsv ; 逐条警告原文见各 attempt_NNN/warnings.txt"
