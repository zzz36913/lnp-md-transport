# B1：relax 步 grompp 的 2 条警告（原文 + mdp 对应 + 物理影响）
- 写于 2026-10-28 16:5x（UTC+8）。来源：box 上 gmx **2025.4-conda_forge** 的 grompp 实际输出，未改写。**不是 2026.3**（2026.3 的条数/文字须由调度侧在 Spark 上复测，见 B2；Claude 的 CSV 称 2026.3 为 4/2 条，review 称，未复核）。
- 原始日志：`../R3_pkg/release/R3_DOPE_lam_s2/pf_relax_literal.log`（命令 `gmx grompp -f relax_literal.mdp -c start.gro -p sys.top -n index.ndx -o pf_relax_literal.tpr -po pf_relax_literal_out.mdp -maxwarn 0`；md5 9b7b4fd1acef89cc35801245dfd92189）。
- 一致性：release 下全部 17 个已预检构建（DOPE/DOPC 片层与 HII）的 relax_literal 警告块逐字相同（17/17，md5 相同）。
- 结果：2 条 WARNING + 1 条 NOTE；`maxwarn 0` 下 `Fatal error: Too many warnings (2).`，退出码 1。

## 警告原文（逐字）
```
WARNING 1 [file relax_literal.mdp]:
  The Berendsen thermostat does not generate the correct kinetic energy
  distribution, and should not be used for new production simulations (in
  our opinion). We would recommend the V-rescale thermostat.

WARNING 2 [file relax_literal.mdp]:
  The Berendsen barostat does not generate any strictly correct ensemble,
  and should not be used for new production simulations (in our opinion).
  We recommend using the C-rescale barostat instead.
```
同一输出里的 NOTE（不算警告，不计入 maxwarn）：
```
NOTE 1 [file relax_literal.mdp]:
  verlet-buffer-pressure-tolerance is ignored when verlet-buffer-tolerance
  < 0
```

## 对应 mdp 参数（`relax_literal.mdp`，逐行取自文件）
| 警告 | 触发参数 | 文件中的值 |
|---|---|---|
| 1 | `tcoupl` | `berendsen`（`tc-grps = Solvent Rest`，`tau_t = 1.0 1.0`，`ref_t = 320 320`，`nsttcouple = 2`） |
| 2 | `pcoupl` | `berendsen`（`pcoupltype = anisotropic`，`tau_p = 1.0`，`ref_p = 1.0 1.0 1.0 0 0 0`，`compressibility = 3e-4 3e-4 3e-4 0 0 0`，`nstpcouple = 2`） |
- 步长 `dt = 0.015`，`nsteps = 1000000`（15 ns）。两条警告都与 `tau_t/tau_p/nst*couple` 的取值无关：grompp 没有报耦合时间常数相关的警告（本日志中无 tau/nst 类 WARNING）。

## 物理影响（只写能核实的）
来源：GROMACS 手册 manual.gromacs.org 的 mdp-options 与 reference-manual「Molecular Dynamics」页面检索摘录（**页面是 nightly 2027.0-dev，不是 2025.4/2026.3 手册；各版本措辞是否一致：未核实**）：
- 警告 1（恒温）：手册称 Berendsen 恒温「抑制动能涨落，不产生正确的正则系综，严格说采样不正确；该误差按 1/N 缩放，系统很大时多数系综平均基本不受影响，但动能分布本身与热容等涨落量受影响」；v-rescale 加了随机项保证正确动能分布。
- 警告 2（恒压）：手册称 Berendsen 恒压「平均压强正确，但不给精确 NPT 系综，压强/体积涨落不对」，且「仅为复现旧运行而保留，强烈不建议用于新模拟」；C-rescale 加随机项给出正确体积涨落，可用于平衡与生产。
- 以上是**系综/涨落正确性**问题，**不是**「仅弃用」，也不是「耦合时间常数」问题。
- 对本 relax（15 ns，之后换 v-rescale + PR 各向异性 τp=12 做 2 µs prod）的**具体影响**：
  - 恒温的 1/N 论断对 ~1.2 万珠、2 个耦合组（Solvent 自由度 2157，Rest 34557，见日志）的体系：量级「未核实」（没有做 Berendsen vs v-rescale 的对照 relax）。
  - Berendsen 各向异性 τp=1 对盒长（Lz、Lx、Ly 各自独立）的抑制涨落效应，以及它是否改变 relax 末态的桥接/极性网络（dd/61：片层起点的桥接发生在平衡段）：**未核实**，没有 relax 对照数据。
  - relax 末帧就是 prod 第 0 帧，所以 relax 的耦合方式会影响起点（起点资格读数与桥接是否出现）；这一点是结构性的，不依赖于未核实的量级。

## 对父 agent 推荐 A 的前提的判断
前提「警告只涉及弃用/耦合时间常数，不影响物理」：**不成立（部分成立）**。
- 不成立的部分：警告说的是系综正确性（动能分布、体积涨落），不是弃用字样或 tau 取值。
- 成立的部分：这两条是「见解性」警告（文中 "in our opinion"、"should not be used for new production simulations"），对象是新的**生产**模拟；本 relax 是 15 ns 平衡，之后换 v-rescale + PR（系综正确的耦合）跑 2 µs，prod 数据本身不受 Berendsen 影响。
- 因此 A 的风险不在 prod 的统计，而在**起点**：relax 的 Berendsen 效应会进入起点资格和事件时间的零点。这一点要写进结论限定语：「条件于合格起点；起点由 Berendsen 各向异性 15 ns relax 产生」。
- 路径 A（仅 relax 步，`-maxwarn 2`，契约写死上面两条原文）可行，条件：
  1. 只有 relax 步用 `-maxwarn 2`；prod/em 仍为 0；
  2. 契约里写死两条原文；Spark 2026.3 实测的警告数与文字必须与本文逐字一致，**条数≠2 或文字不同就不得放行，须重新批准**；
  3. 结论限定语见上。
- 路径 B（`relax_crescale_dev`：v-rescale + c-rescale **半各向同性** τp=1，2025.4 实测 0 警告，退出码 0）：偏离 SI 协议的开发臂（半各向同性，非各向异性），力场与 SI 字节一致性未核；只作对照/探索。c-rescale 各向异性在 2026.3 为 ERROR（review 称，未复核）。
- 预跑（见 `README.md`）会同时跑 A 与 B 的 relax，并读 relax 后的 2/2/2/2 合格率，给 K 一个数据依据；本文不做任何 G-R3 科学判读。
