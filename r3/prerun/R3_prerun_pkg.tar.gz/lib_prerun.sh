#!/bin/bash
# lib_prerun.sh -- 预跑公共函数 (被 preflight_R3.sh / run_prerun.sh source). 不单独执行.
# 约束(写死): 只用 gmx 与(可选)用户态 MPS; 不碰 GLM/ZCode/任何端口/key; 不 stop 他人容器(只 stop 本脚本起的 R3PRE_* 容器).
# 输出布局: $OUT/<stage>/<build>/<arm_or_mdp>/attempt_NNN/ ; 每次尝试新 attempt_NNN(mkdir 原子, 不用 -p), 目录内文件只写一次(noclobber), 永不覆写/删除旧 attempt.
HERE=${HERE:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}
INP=$HERE/inputs; FF=$INP/ff
MODE=${MODE:-docker}                                           # docker(Spark 默认, 同 R2a) | local(box 冒烟, 用 GMX_LOCAL)
IMG=${IMG:-ghcr.io/novomcp/gromacs-md:spark}; G=${G:-/usr/local/gromacs/bin/gmx}   # 与 run_R2a.sh 同款默认值
GMX_LOCAL=${GMX_LOCAL:-gmx}
NT=${NT:-5}
J=${J:-$HOME/R3_prerun}                                        # 输出根(父目录); 实际输出 $J/R3_prerun_<TS>
BUILDS_DOPE=${BUILDS_DOPE:-"R3_DOPE_lam_s2 R3_DOPE_lam_s3 R3_DOPE_lam_s5"}   # release/t0_L1_summary*.tsv 里 DOPE 前 3 个 L1 PASS
BUILDS_DOPC=${BUILDS_DOPC:-"R3_DOPC_lam_s1 R3_DOPC_lam_s2 R3_DOPC_lam_s3"}   # DOPC 前 3 个 L1 PASS
PRE_BUILDS=${PRE_BUILDS:-"$BUILDS_DOPE $BUILDS_DOPC R3_DOPE_hii_s1"}        # 预检覆盖(含 1 个 HII 起点以覆盖 prod_hii.mdp)
GMXV=unknown
need_cmd(){ [ "$MODE" = local ] && { command -v "$GMX_LOCAL" >/dev/null 2>&1 || [ -x "$GMX_LOCAL" ] || { echo "ABORT: MODE=local 但找不到 $GMX_LOCAL"; exit 1; }; } || { command -v docker >/dev/null 2>&1 || { echo "ABORT: 没有 docker"; exit 1; }; }; }
# gx: (GXG=1 时才给容器 --gpus all; grompp 预检不给 GPU) 在 $PWD 里跑 gmx (docker 模式同 run_R2a.sh: --entrypoint /bin/sh -u uid:gid -e HOME=/tmp -v J:J -w PWD)
gx(){ if [ "$MODE" = local ]; then GMXLIB=$FF $GMX_LOCAL "$@" 2>&1; else
  docker run --rm --name ${CN:-R3PRE_$$} ${GXG:+--gpus all} ${MPSARGS-} --entrypoint /bin/sh -u $(id -u):$(id -g) -e HOME=/tmp -e GMXLIB=$FF -v $HERE:$HERE:ro -v $OUT_PARENT:$OUT_PARENT -w "$PWD" $IMG -c "exec 2>&1; $G $*"; fi; }
gmx_version(){ ( cd /tmp; gx --version 2>&1 | grep -m1 'GROMACS version' | awk '{print $NF}' ); }
# 输出目录: 新建 $J/R3_prerun_<TS>; 已存在 -> 报错退出. APPEND_TO=<已有目录> 时只在其中追加新 attempt(不改旧文件).
init_out(){
  if [ -n "${PRERUN_OUT:-}" ] && [ -d "$PRERUN_OUT" ]; then OUT=$PRERUN_OUT
  elif [ -n "${APPEND_TO:-}" ]; then [ -d "$APPEND_TO" ] || { echo "ABORT: APPEND_TO 目录不存在"; exit 1; }; OUT=$(cd "$APPEND_TO" && pwd); APPEND=1
  else TS=$(date +%m%d_%H%M%S); mkdir -p "$J" || exit 1; OUT=$J/R3_prerun_$TS
    mkdir "$OUT" 2>/dev/null || { echo "ABORT: $OUT 已存在, 不覆盖 (重试请用 APPEND_TO=该目录)"; exit 1; }; fi
  OUT_PARENT=$(dirname "$OUT"); export PRERUN_OUT=$OUT OUT OUT_PARENT; }
# new_attempt <step_dir> -> 打印新 attempt 目录(原子 mkdir, 编号 = 现有最大+1)
new_attempt(){ local s=$1 n d; mkdir -p "$s"; n=$(ls -1d "$s"/attempt_[0-9][0-9][0-9] 2>/dev/null | sed 's/.*attempt_//' | sort -n | tail -1); n=$((10#${n:-0}))
  while :; do n=$((n+1)); d=$(printf '%s/attempt_%03d' "$s" $n); mkdir "$d" 2>/dev/null && { echo "$d"; return 0; }; done; }
last_state(){ local s=$1 d; d=$(ls -1d "$s"/attempt_[0-9][0-9][0-9] 2>/dev/null | sort | tail -1); [ -n "$d" ] && [ -f "$d/STATUS" ] && cut -d' ' -f1 "$d/STATUS" || echo NONE; }
# setstat <attempt_dir> <STATE> [详情]  (只写一次)
setstat(){ ( set -o noclobber; echo "$2 ${3:-}" > "$1/STATUS" ) 2>/dev/null || echo "WARN: $1/STATUS 已存在, 不覆盖" >&2; }
warn_extract(){ awk '/^WARNING [0-9]+/{p=1} /^(Number of degrees|There w(as|ere) [0-9]+ (NOTE|WARNING))/{p=0} p' "$1"; }   # 逐字抽取 grompp 警告块
nanchk(){ grep -ciE '(^|[^a-z])nan([^a-z]|$)|fatal error|LINCS WARNING' "$1" 2>/dev/null; }
# 追加记录(只 >>): 列见 REC_HEADER
REC_HEADER=$'ts\tstage\tbuild\tarm_or_mdp\tattempt_dir\tstate\tgmx_version\tmaxwarn\tgrompp_rc\tn_warn\tmdrun_rc\tnsteps_run\tperformance_ns_day\tinput_gro\tinput_mdp\tinput_top\tgrompp_log\twarnings_txt\tmdrun_log\tperf_log\tt0_readout_rel'
rec(){ [ -f "$OUT/ALL_RECORDS.tsv" ] || printf '%s\n' "$REC_HEADER" >> "$OUT/ALL_RECORDS.tsv"; local IFS=$'\t'; printf '%s\n' "$*" >> "$OUT/ALL_RECORDS.tsv"; }
# 单次 grompp: gp <attempt_dir> <tag> <mdp> <gro> <top> <ndx> <maxwarn> [额外 grompp 参数...]  -> 设 GP_RC GP_NW; 日志 grompp.log, 警告 warnings.txt
gp(){ local d=$1 tag=$2 mdp=$3 gro=$4 top=$5 ndx=$6 mw=$7; shift 7; ( cd "$d" && gx grompp -f "$mdp" -c "$gro" -p "$top" -n "$ndx" -o $tag.tpr -po ${tag}_out.mdp "$@" -maxwarn $mw ) > "$d/grompp.log" 2>&1; GP_RC=$?
  warn_extract "$d/grompp.log" > "$d/warnings.txt"; GP_NW=$(grep -c '^WARNING' "$d/grompp.log"); }
# MPS (同 R2a_machine.sh: 用户态守护, MPSROOT 须不存在/空; 只关自己新起的)
mps_start(){ [ "$MODE" = local ] && return 0; [ -n "${MPS_UP:-}" ] && return 0; [ -n "${NOMPS:-}" ] && return 0; MPSROOT=${MPSROOT:-$HOME/mps_R3pre_$$}
  [ -z "$(ls -A $MPSROOT 2>/dev/null)" ] || { echo "ABORT: $MPSROOT 非空"; exit 1; }
  export MPSPIPE=$MPSROOT/pipe MPSLOG=$MPSROOT/log; mkdir -p $MPSPIPE $MPSLOG; PRE_MPS=" $(pgrep nvidia-cuda-mps | tr '\n' ' ') "
  CUDA_MPS_PIPE_DIRECTORY=$MPSPIPE CUDA_MPS_LOG_DIRECTORY=$MPSLOG nvidia-cuda-mps-control -d || { echo "ABORT: MPS 起不来"; exit 1; }; sleep 3
  export MPSARGS="--ipc=host -v $MPSPIPE:$MPSPIPE -v $MPSLOG:$MPSLOG -e CUDA_MPS_PIPE_DIRECTORY=$MPSPIPE -e CUDA_MPS_LOG_DIRECTORY=$MPSLOG"; MPS_UP=1; }
mps_stop(){ [ -n "${MPS_UP:-}" ] || return 0; echo quit | CUDA_MPS_PIPE_DIRECTORY=$MPSPIPE CUDA_MPS_LOG_DIRECTORY=$MPSLOG timeout 20 nvidia-cuda-mps-control > /dev/null 2>&1; sleep 2
  for p in $(pgrep nvidia-cuda-mps); do case "$PRE_MPS" in *" $p "*) ;; *) kill $p 2>/dev/null;; esac; done; MPS_UP=; }
check_inputs(){ local b f; for b in "$@"; do for f in start.gro sys.top index.ndx; do [ -s "$INP/$b/$f" ] || { echo "ABORT: 缺 $INP/$b/$f"; return 1; }; done; done
  for f in $(grep -E '^#include' "$INP/${1}/sys.top" | sed 's/.*"\(.*\)".*/\1/'); do [ -s "$FF/$f" ] || { echo "ABORT: 缺 $FF/$f"; return 1; }; done
  if [ -f "$HERE/MANIFEST_sha256.txt" ]; then ( cd "$HERE" && sha256sum -c MANIFEST_sha256.txt --quiet ) >/dev/null 2>&1 || { echo "ABORT: 包与 MANIFEST_sha256.txt 不符 (cd $HERE && sha256sum -c MANIFEST_sha256.txt 查看)"; return 1; }; fi; }
# gmx 版本检查: B2 的目的就是 2026.3 实测; 版本不符则中止(EXPECT_GMX=any 可关, 仅 box 冒烟用)
check_gmxv(){ case "$GMXV" in ${EXPECT_GMX:-2026.3}*) ;; *) [ "${EXPECT_GMX:-}" = any ] || { echo "ABORT: gmx 版本 '$GMXV' != 期望 ${EXPECT_GMX:-2026.3} (box 冒烟请设 EXPECT_GMX=any)"; exit 1; };; esac; }
