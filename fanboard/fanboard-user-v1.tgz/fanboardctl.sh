#!/usr/bin/env bash
# FanBoard user-v1 control: start|stop|status|log. No sudo, no autostart, idempotent.
set -u
APP="$(cd "$(dirname "$0")" && pwd)"
export FANBOARD_HOME="${FANBOARD_HOME:-$HOME/.local/state/fanboard}"
export FANBOARD_LOG="${FANBOARD_LOG:-$FANBOARD_HOME/agent.log}"
export FANBOARD_LOG_MAX="${FANBOARD_LOG_MAX:-2097152}"
ARGS_FILE="${FANBOARD_ARGS_FILE:-$APP/args.conf}"
PIDF="$FANBOARD_HOME/agent.pid"
AGENT="$APP/fanboard_agent.py"
mkdir -p -m 700 "$FANBOARD_HOME"

# Return 0 only if pid is ours, alive, and runs exactly our agent script.
own_pid() {
  local p="$1"; [[ "$p" =~ ^[0-9]+$ ]] || return 1
  [ -r "/proc/$p/cmdline" ] || return 1
  [ "$(stat -c %u "/proc/$p")" = "$(id -u)" ] || return 1
  tr '\0' '\n' < "/proc/$p/cmdline" | grep -qxF "$AGENT"
}
cur_pid() { [ -f "$PIDF" ] && p="$(cat "$PIDF")" && own_pid "$p" && echo "$p"; }

case "${1:-}" in
start)
  if p="$(cur_pid)"; then echo "RUNNING pid=$p (already)"; exit 0; fi
  [ -f "$ARGS_FILE" ] || { echo "MISSING $ARGS_FILE"; exit 2; }
  grep -q '<' "$ARGS_FILE" && { echo "UNFILLED placeholder in $ARGS_FILE"; exit 2; }
  read -r -a ARGS < <(grep -v '^#' "$ARGS_FILE" | tr '\n' ' ')
  setsid nohup /usr/bin/python3 -u "$AGENT" --no-vllm "${ARGS[@]}" </dev/null >>"$FANBOARD_HOME/boot.log" 2>&1 &
  echo $! > "$PIDF"; sleep 2
  if p="$(cur_pid)"; then echo "STARTED pid=$p log=$FANBOARD_LOG"; exit 0; fi
  echo "START_FAILED; tail:"; tail -n 15 "$FANBOARD_LOG"; rm -f "$PIDF"; exit 1 ;;
stop)
  p="$(cur_pid)" || { echo "NOT_RUNNING"; rm -f "$PIDF"; exit 0; }
  kill -TERM "$p"
  for _ in $(seq 1 20); do own_pid "$p" || { echo "STOPPED pid=$p"; rm -f "$PIDF"; exit 0; }; sleep 0.5; done
  own_pid "$p" && kill -KILL "$p" && echo "KILLED pid=$p (no clean exit in 10s)"; rm -f "$PIDF" ;;
status)
  if p="$(cur_pid)"; then echo "RUNNING pid=$p"; ps -o pid,user,etime,cmd -p "$p"; else echo "NOT_RUNNING"; fi
  tail -n "${2:-10}" "$FANBOARD_LOG" 2>/dev/null ;;
log) tail -n "${2:-50}" "$FANBOARD_LOG" ;;
*) echo "usage: $0 start|stop|status [N]|log [N]"; exit 2 ;;
esac
