# -*- coding: utf-8 -*-
"""DGX Spark 风扇控制板 · 主机聚合上报脚本【修复版】
双通道：USB + HTTP
修复点：后台缓存CPU、串口自动重连(含 ESP32-S3 CDC 卡死/死锁修复)、nvidia-smi 线程超时降级、
        vLLM计数器回退重置、运行时动态刷新IP、优雅退出、启动自动扫描并绑定FanBoard USB口
零强制第三方依赖；psutil可选。
"""
from __future__ import annotations
import argparse
import json
import os
import signal
import socket
import threading
import time
from typing import Optional

try:
    import psutil  # 可选
except ImportError:
    psutil = None

# 全局退出标记
SHUTDOWN_FLAG = threading.Event()

# --------------------------- 后台缓存对象 ---------------------------
class MetricCache:
    def __init__(self):
        self.lock = threading.Lock()
        self.cpu: Optional[float] = None
        self.mem: Optional[float] = None
        self.gpu_info: dict = {}
        self.local_ip: str = "127.0.0.1"
        self.last_ip_refresh = 0.0

    def set_cpu(self, v: Optional[float]):
        with self.lock:
            self.cpu = v

    def get_cpu(self) -> Optional[float]:
        with self.lock:
            return self.cpu

    def set_mem(self, v: Optional[float]):
        with self.lock:
            self.mem = v

    def get_mem(self) -> Optional[float]:
        with self.lock:
            return self.mem

    def set_gpu(self, d: dict):
        with self.lock:
            self.gpu_info = d

    def get_gpu(self) -> dict:
        with self.lock:
            return self.gpu_info.copy()

    def refresh_ip(self, force: bool = False):
        now = time.monotonic()
        with self.lock:
            if not force and (now - self.last_ip_refresh < 30.0):
                return
            self.local_ip = choose_local_ip()
            self.last_ip_refresh = now

    def get_ip(self) -> str:
        with self.lock:
            return self.local_ip

GLOBAL_CACHE = MetricCache()

# ---------------------------------------------------------------------------
# 网络 / IP 挑选
# ---------------------------------------------------------------------------
def _default_route_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()

_VIRTUAL_IFACE_SUBSTR = (
    "docker", "veth", "vmnet", "vboxnet", "virbr", "vbr", "tun",
    "tap", "tailscale", "wg", "utun", "bridge", "br-", "lo",
)

def _is_virtual_iface(name: str) -> bool:
    n = name.lower()
    return any(n.startswith(p) or (p in n) for p in _VIRTUAL_IFACE_SUBSTR)

def _is_private(ip: str) -> bool:
    if ip.startswith("192.168.") or ip.startswith("10."):
        return True
    for seg in range(16, 32):
        if ip.startswith(f"172.{seg}."):
            return True
    return False

def list_ipv4() -> list:
    if psutil is not None:
        try:
            ifaces = psutil.net_if_addrs()
        except Exception:
            ifaces = {}
        out = []
        for name, addrs in ifaces.items():
            for addr in addrs:
                if addr.family == socket.AF_INET and addr.address:
                    out.append((str(name), str(addr.address)))
        if out:
            return out
    return _list_ipv4_cmd()

def _list_ipv4_cmd() -> list:
    import subprocess
    try:
        out = subprocess.check_output(["ip", "-4", "addr"], text=True, stderr=subprocess.DEVNULL)
    except Exception:
        return []
    result = []
    iface = None
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("inet ") and iface:
            ip = line.split()[1].rsplit("/", 1)[0]
            result.append((iface, ip))
        elif ":" in line and line.endswith(":"):
            candidate = line.rstrip(":")
            if candidate and not candidate.startswith("inet"):
                iface = candidate
    return result

def choose_local_ip() -> str:
    routed = _default_route_ip()
    physical_priv = None
    for name, ip in list_ipv4():
        if _is_virtual_iface(name):
            continue
        if _is_private(ip) and physical_priv is None:
            physical_priv = ip
        if routed == ip:
            return ip
    if physical_priv is not None:
        return physical_priv
    return routed

def choose_local_ip_or(override: Optional[str]) -> str:
    if override:
        return override
    return GLOBAL_CACHE.get_ip()

# ---------------------------------------------------------------------------
# 后台采样线程：CPU/MEM 后台定时采样，不在HTTP请求中阻塞
# ---------------------------------------------------------------------------
def _background_sample_cpu_mem():
    """后台线程循环采样CPU/MEM，写入全局缓存"""
    while not SHUTDOWN_FLAG.is_set():
        try:
            if psutil is not None:
                cpu_val = psutil.cpu_percent(interval=0.2)
                mem_val = psutil.virtual_memory().percent
                GLOBAL_CACHE.set_cpu(cpu_val)
                GLOBAL_CACHE.set_mem(mem_val)
            else:
                cpu_val = _cpu_percent_raw()
                mem_val = _mem_percent_raw()
                GLOBAL_CACHE.set_cpu(cpu_val)
                GLOBAL_CACHE.set_mem(mem_val)
        except Exception:
            pass
        SHUTDOWN_FLAG.wait(0.5)

def _cpu_percent_raw() -> Optional[float]:
    try:
        with open("/proc/stat", "r") as f:
            first = f.readline().split()
        total1 = sum(int(x) for x in first[1:])
        idle1 = int(first[4])
        time.sleep(0.2)
        with open("/proc/stat", "r") as f:
            second = f.readline().split()
        total2 = sum(int(x) for x in second[1:])
        idle2 = int(second[4])
        dt = total2 - total1
        if dt <= 0:
            return 0.0
        return round(100.0 * (1.0 - (idle2 - idle1) / dt), 1)
    except Exception:
        return None

def _mem_percent_raw() -> Optional[float]:
    try:
        total = avail = None
        with open("/proc/meminfo", "r") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    total = float(line.split()[1])
                elif line.startswith("MemAvailable:"):
                    avail = float(line.split()[1])
                if total is not None and avail is not None:
                    break
        if total is None or avail is None or total <= 0:
            return None
        return round(100.0 * (1.0 - avail / total), 1)
    except Exception:
        return None

def _nvidia_all() -> dict:
    """读取 GPU 状态。关键修复：DGX Spark 上 nvidia-smi 偶发进入
    D (uninterruptible) 状态永久 hang，subprocess 的 timeout=2 无法 kill 此类
    进程，会冻结调用线程（主循环）。改为：独立线程跑 nvidia-smi（内部 timeout=2），
    主线程 join 4s；超时则回退上次缓存（GLOBAL_CACHE），绝不冻结主循环。
    成功则更新缓存。
    """
    import subprocess
    holder = {}

    def _worker():
        try:
            out = subprocess.check_output(
                ["nvidia-smi",
                 "--query-gpu=utilization.gpu,power.draw,temperature.gpu",
                 "--format=csv,noheader,nounits"],
                text=True, timeout=2,
            ).strip()
            holder["out"] = out
        except Exception as e:
            holder["err"] = repr(e)

    t = threading.Thread(target=_worker, daemon=True)
    t.start()
    t.join(4.0)  # 硬超时，超过则放弃，用缓存
    if t.is_alive():
        # nvidia-smi 仍卡死 → 用上次缓存
        return GLOBAL_CACHE.get_gpu()
    if "err" in holder:
        return GLOBAL_CACHE.get_gpu()
    out = holder.get("out", "")
    try:
        parts = [p.strip() for p in (out.splitlines()[0].split(",") if out else [])]
        if len(parts) < 3:
            return GLOBAL_CACHE.get_gpu()
        result = {
            "gpu": round(float(parts[0].strip().strip('%')), 1),
            "power": round(float(parts[1].strip().strip('W')), 1),
            "gpu_temp": round(float(parts[2].strip()), 1),
        }
        GLOBAL_CACHE.set_gpu(result)
        return result
    except Exception:
        return GLOBAL_CACHE.get_gpu()

# vLLM token速率采集：修复计数器回退重置
_VLLM_LOCK = threading.Lock()
_VLLM_STATE = {
    "last_fetch": 0.0,
    "fail_until": 0.0,
    "prev_t": None,
    "prev_in": None,
    "prev_out": None,
    "rate_in": None,
    "rate_out": None,
    "g_running": None,
    "g_waiting": None,
    "g_kv": None,
}

def fetch_vllm_speed(url: str, interval_s: float) -> Optional[dict]:
    now = time.monotonic()
    with _VLLM_LOCK:
        st = _VLLM_STATE
        if st["fail_until"] and now < st["fail_until"]:
            return None
        if st["last_fetch"] and now - st["last_fetch"] < interval_s:
            out = {}
            if st["rate_in"] is not None:
                out["tok_in"] = st["rate_in"]
            if st["rate_out"] is not None:
                out["tok_out"] = st["rate_out"]
            if st["g_running"] is not None:
                out["vllm_running"] = st["g_running"]
            if st["g_waiting"] is not None:
                out["vllm_waiting"] = st["g_waiting"]
            if st["g_kv"] is not None:
                out["vllm_kv_pct"] = round(st["g_kv"] * 100.0, 2)
            return out or None
        try:
            import urllib.request
            with urllib.request.urlopen(url, timeout=2) as resp:
                if resp.status != 200:
                    raise OSError(f"metrics http status {resp.status}")
                text = resp.read().decode("utf-8", "replace")
        except Exception:
            st["fail_until"] = now + 30.0
            return None

        cur_in = cur_out = cur_run = cur_wait = cur_kv = None
        for line in text.splitlines():
            key = line.split("{", 1)[0]
            try:
                if key == "vllm:prompt_tokens_total":
                    cur_in = float(line.rsplit(" ", 1)[-1])
                elif key == "vllm:generation_tokens_total":
                    cur_out = float(line.rsplit(" ", 1)[-1])
                elif key == "vllm:num_requests_running":
                    cur_run = float(line.rsplit(" ", 1)[-1])
                elif key == "vllm:num_requests_waiting":
                    cur_wait = float(line.rsplit(" ", 1)[-1])
                elif key == "vllm:kv_cache_usage_perc":
                    cur_kv = float(line.rsplit(" ", 1)[-1])
            except ValueError:
                pass

        result = {}
        if cur_in is not None and cur_out is not None:
            # 检测计数器回退(vLLM重启)，重置基准
            if st["prev_in"] is not None and st["prev_out"] is not None:
                if cur_in < st["prev_in"] or cur_out < st["prev_out"]:
                    st["prev_in"] = None
                    st["prev_out"] = None
                    st["prev_t"] = None
            if st["prev_in"] is not None and st["prev_out"] is not None:
                dt = now - st["prev_t"]
                if dt > 0:
                    rate_in = (cur_in - st["prev_in"]) / dt
                    rate_out = (cur_out - st["prev_out"]) / dt
                    if rate_in >= 0 and rate_out >= 0:
                        st["rate_in"] = round(rate_in, 1)
                        st["rate_out"] = round(rate_out, 1)
                        result["tok_in"] = st["rate_in"]
                        result["tok_out"] = st["rate_out"]
            st["prev_in"], st["prev_out"], st["prev_t"] = cur_in, cur_out, now
        if cur_run is not None:
            st["g_running"] = cur_run
            result["vllm_running"] = cur_run
        if cur_wait is not None:
            st["g_waiting"] = cur_wait
            result["vllm_waiting"] = cur_wait
        if cur_kv is not None:
            st["g_kv"] = cur_kv
            result["vllm_kv_pct"] = round(cur_kv * 100.0, 2)
        st["last_fetch"] = now
        return result or None

def collect_local(ip_override: Optional[str] = None,
                  vllm_url: Optional[str] = None, vllm_interval: float = 10.0) -> dict:
    GLOBAL_CACHE.refresh_ip()
    ip = choose_local_ip_or(ip_override)
    cpu = GLOBAL_CACHE.get_cpu()
    mem = GLOBAL_CACHE.get_mem()
    gpu_info = _nvidia_all()
    GLOBAL_CACHE.set_gpu(gpu_info)

    status = {"host": "A", "ip": ip}
    if cpu is not None:
        status["cpu"] = cpu
    if gpu_info.get("gpu") is not None:
        status["gpu"] = gpu_info["gpu"]
    if mem is not None:
        status["mem"] = mem
    if gpu_info.get("power") is not None:
        status["power"] = gpu_info["power"]
    if gpu_info.get("gpu_temp") is not None:
        status["gpu_temp"] = gpu_info["gpu_temp"]
    if gpu_info.get("gpu") is not None:
        status["gpu_util"] = gpu_info["gpu"]
    if vllm_url:
        spd = fetch_vllm_speed(vllm_url, vllm_interval)
        if spd:
            status.update(spd)
    return status

def collect_remote(host_b: Optional[str], port: int) -> Optional[dict]:
    if not host_b:
        return None
    import urllib.request
    try:
        with urllib.request.urlopen(f"http://{host_b}:{port}/api/status", timeout=0.8) as resp:
            if resp.status != 200:
                return None
            data = json.loads(resp.read().decode("utf-8") or "{}")
        data["host"] = "B"
        return data
    except Exception:
        return None

def build_message(local: dict, remote: Optional[dict]) -> str:
    hosts = [local]
    if remote is not None:
        hosts.append(remote)
    return json.dumps({"type": "hosts", "hosts": hosts})

# ---------------------------------------------------------------------------
# HTTP服务
# ---------------------------------------------------------------------------
def _serve_http(host_b: Optional[str], host_b_port: int, bind: str, port: int,
                local_ip_override: Optional[str] = None,
                vllm_url: Optional[str] = None, vllm_interval: float = 10.0):
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass
        def _json(self, obj):
            body = json.dumps(obj).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        def do_GET(self):
            path = self.path.split("?", 1)[0]
            if path == "/api/status":
                self._json(collect_local(ip_override=local_ip_override,
                                         vllm_url=vllm_url, vllm_interval=vllm_interval))
            elif path == "/api/aggregate":
                local = collect_local(ip_override=local_ip_override,
                                      vllm_url=vllm_url, vllm_interval=vllm_interval)
                remote = collect_remote(host_b, host_b_port)
                self._json({
                    "type": "hosts",
                    "hosts": ([local] + ([remote] if remote is not None else [])),
                })
            else:
                self.send_error(404)

    httpd = ThreadingHTTPServer((bind, port), Handler)
    try:
        while not SHUTDOWN_FLAG.is_set():
            httpd.handle_request()
    except Exception:
        pass
    httpd.server_close()

# ---------------------------------------------------------------------------
# USB串口层：启动自动扫描绑定 + 自动重连，处理非阻塞EAGAIN
# ---------------------------------------------------------------------------
def _port_usb_product(name: str):
    """沿 /sys/class/tty/<name>/device 上溯若干层，取 usb 设备 uevent 的 PRODUCT（vid/pid）。
    返回 (vid, pid) 或 None。纯标准库，不依赖 pyserial。"""
    try:
        real = os.path.realpath(f"/sys/class/tty/{name}/device")
    except Exception:
        return None
    for _ in range(6):
        uev = os.path.join(real, "uevent")
        try:
            with open(uev, "r") as f:
                for line in f:
                    if line.startswith("PRODUCT="):
                        parts = line.split("=", 1)[1].strip().lower().split("/")
                        if len(parts) >= 2:
                            return (parts[0], parts[1])
        except Exception:
            pass
        parent = os.path.dirname(real)
        if parent == real:
            break
        real = parent
    return None

def detect_fanboard_port() -> str:
    """在 /dev/ttyACM* / /dev/ttyUSB* 中找唯一的 ESP32-S3 原生 CDC（303a:1001），
    返回设备路径；未找到或无法唯一确定时返回 ""，调用方可隔几秒重扫。"""
    candidates = []
    try:
        for name in sorted(os.listdir("/dev")):
            if not (name.startswith("ttyACM") or name.startswith("ttyUSB")):
                continue
            if _port_usb_product(name) == ("303a", "1001"):
                candidates.append("/dev/" + name)
    except Exception as e:
        print(f"[FanBoardAgent] detect_fanboard_port error: {e}")
        return ""
    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) > 1:
        print(f"[FanBoardAgent] multiple FanBoard ports found: {candidates}; use --device to pick one")
    return ""

class AutoReconnectSerial:
    def __init__(self, device: str, baudrate: int):
        self.device = device
        self.baudrate = baudrate
        self.handle = None
        self.lock = threading.Lock()

    @staticmethod
    def _neutralize_modem(fd):
        """清除 DTR/RTS 并设置 CLOCAL|CREAD，防止 ESP32-S3 原生 CDC 复位。"""
        try:
            import termios
            import fcntl
        except Exception:
            return
        try:
            attrs = termios.tcgetattr(fd)
            attrs[3] = attrs[3] | termios.CLOCAL | termios.CREAD
            termios.tcsetattr(fd, termios.TCSANOW, attrs)
        except Exception as e:
            print(f"[FanBoardSerial] tcsetattr CLOCAL|CREAD failed: {e}")
        try:
            bits = 0
            if hasattr(termios, "TIOCM_DTR"):
                bits |= termios.TIOCM_DTR
            if hasattr(termios, "TIOCM_RTS"):
                bits |= termios.TIOCM_RTS
            if bits:
                fcntl.ioctl(fd, termios.TIOCMBIC, bits)
        except Exception as e:
            print(f"[FanBoardSerial] TIOCMBIC DTR/RTS failed: {e}")

    def _do_open_raw(self):
        """锁外阻塞操作：尝试打开端口，返回 handle 或 None。
        关键：本函数绝不持有 self.lock，避免 os.open 在 ESP32 重启窗口内
        阻塞时把锁带走，导致 write_line/close 死锁主循环。
        """
        # 关键修复：ESP32-S3 原生 USB-CDC（303a:1001）在被主机以默认
        # termios 打开端口时，DTR/RTS 会被置位并触发芯片复位 → USB 重枚举
        # → fd 失效。优先用 raw os.open + 立即 neutralize（在打开瞬间就设
        # CLOCAL|CREAD、清 DTR/RTS），避免 pyserial 构造期间默认 termios 触发
        # 复位。仅 raw 失败才回退 pyserial（exclusive=True + 立即清 DTR/RTS）。
        try:
            fd = os.open(self.device, os.O_WRONLY | os.O_NOCTTY | os.O_NONBLOCK)
            self._neutralize_modem(fd)
            return os.fdopen(fd, "wb", buffering=0)
        except Exception as e:
            print(f"[FanBoardSerial] raw os open fail {self.device}: {e}")
        try:
            import serial
            ser = serial.Serial(self.device, self.baudrate, timeout=0.2,
                                exclusive=True)
            try:
                ser.dtr = False
                ser.rts = False
            except Exception:
                pass
            return ser
        except Exception as e:
            print(f"[FanBoardSerial] pyserial open fail {self.device}: {e}")
            return None

    def open(self) -> bool:
        """在锁外执行阻塞的 _do_open_raw，仅在拿到有效 handle 后才加锁赋值。
        因此即使 _do_open_raw 阻塞，也不持有 self.lock，不会死锁主循环。
        """
        h = self._do_open_raw()
        with self.lock:
            # 先安全关闭旧 handle
            if self.handle is not None:
                try:
                    self.handle.close()
                except Exception:
                    pass
            if h is not None:
                self.handle = h
                print(f"[FanBoardSerial] opened {self.device} ({'raw' if not hasattr(h,'is_open') else 'pyserial'})")
                return True
            self.handle = None
            return False

    def open_with_timeout(self, timeout: float = 3.0) -> bool:
        """在独立线程中执行 open()，避免 os.open 在 ESP32-S3 重启窗口内
        阻塞主循环（CDC 设备节点临时不可达时 open 可能在驱动层挂起）。
        子线程内部不持有 self.lock，仅通过返回值把 handle 交回，主线程加锁赋值，
        因此绝不会死锁。超时返回 False，主循环继续，不冻结。
        """
        result = {}

        def _worker():
            try:
                result["h"] = self._do_open_raw()
            except Exception as e:
                result["err"] = repr(e)

        t = threading.Thread(target=_worker, daemon=True)
        t.start()
        t.join(timeout)
        if t.is_alive():
            # _do_open_raw 仍阻塞（ESP32 重启未恢复），标记失败
            print(f"[FanBoardSerial] open() blocked > {timeout}s (ESP32 reboot?), skip this round")
            return False
        h = result.get("h")
        err = result.get("err")
        with self.lock:
            if self.handle is not None:
                try:
                    self.handle.close()
                except Exception:
                    pass
            if h is not None:
                self.handle = h
                print(f"[FanBoardSerial] opened {self.device} (async, {'raw' if not hasattr(h,'is_open') else 'pyserial'})")
                return True
            self.handle = None
            if err:
                print(f"[FanBoardSerial] open() raised: {err}")
            return False

    def close(self):
        with self.lock:
            if self.handle is not None:
                try:
                    self.handle.close()
                except Exception:
                    pass
            self.handle = None

    def write_line(self, msg: str) -> bool:
        data = (msg + "\n").encode("utf-8")
        with self.lock:
            if self.handle is None:
                return False
            try:
                # raw fd 模式：os.fdopen 返回的 _io.FileIO，write 返回写入字节数。
                # 关键修复：O_NONBLOCK tty 输出队列满时 write 会返回短计数（部分写入），
                # 若忽略则消息尾部（含行结束符 \n）被静默丢弃 —— 主板即使已把 USB-CDC
                # RX 缓冲加大到 4096，也永远凑不成整行、A/B 无数据。必须循环写到写完，
                # 中途 EAGAIN 短暂让出。
                off = 0
                while off < len(data):
                    try:
                        n = self.handle.write(data[off:])
                    except (BlockingIOError, InterruptedError):
                        time.sleep(0.01)
                        continue
                    if n is None:
                        n = len(data) - off  # pyserial write 返回 None 视为整包
                    if n <= 0:
                        time.sleep(0.01)
                        continue
                    off += n
                return True
            except (OSError, ValueError) as e:
                # 设备消失 / fd 失效（ESP32 重启后 CDC 重枚举）→ 立即断开重连
                print(f"[FanBoardSerial] write OSError: {e}, device gone? will reconnect")
                try:
                    self.handle.close()
                except Exception:
                    pass
                self.handle = None
                return False
            except Exception as e:
                print(f"[FanBoardSerial] write error: {e}, will reconnect")
                try:
                    self.handle.close()
                except Exception:
                    pass
                self.handle = None
                return False

# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------
def handle_sigterm(signum, frame):
    print("[FanBoardAgent] SIGTERM received, shutting down...")
    SHUTDOWN_FLAG.set()

def _run(cfg: dict) -> int:
    signal.signal(signal.SIGTERM, handle_sigterm)
    signal.signal(signal.SIGINT, handle_sigterm)

    device = cfg.get("device") or ""
    interval_s = max(0.1, int(cfg.get("sample_interval_ms", 1000)) / 1000.0)
    host_b = cfg.get("host_b") or None
    host_b_port = int(cfg.get("host_b_port", 8080))
    with_http = bool(cfg.get("with_http", True))
    bind = cfg.get("bind", "0.0.0.0")
    http_port = int(cfg.get("http_port", 8080))
    local_ip_override = cfg.get("local_ip") or None
    vllm_url = cfg.get("vllm_metrics_url") or None
    vllm_interval = max(1.0, float(cfg.get("vllm_interval", 10.0)))

    GLOBAL_CACHE.refresh_ip(force=True)

    # 启动后台CPU/MEM采样线程
    bg_thread = threading.Thread(target=_background_sample_cpu_mem, daemon=True)
    bg_thread.start()

    if with_http:
        t_http = threading.Thread(
            target=_serve_http,
            args=(host_b, host_b_port, bind, http_port, local_ip_override,
                  vllm_url, vllm_interval),
            daemon=True,
            name="http-server",
        )
        t_http.start()
        print(f"[FanBoardAgent] HTTP started http://{bind}:{http_port}/api/status"
              f"{' HostB=' + str(host_b) + ':' + str(host_b_port) if host_b else ''}"
              f" vLLM={vllm_url if vllm_url else 'off'}")

    serial_dev = AutoReconnectSerial(device, int(cfg.get("baudrate", 115200)))
    last_serial_attempt = 0.0
    last_print = 0.0

    print(f"[FanBoardAgent] device={device} interval={interval_s}s http={with_http}")

    while not SHUTDOWN_FLAG.is_set():
        start = time.monotonic()
        try:
            if serial_dev.handle is None and (start - last_serial_attempt > 3.0):
                last_serial_attempt = start
                if not serial_dev.device:
                    # 尚未绑定端口（--device 未指定或用默认自动模式未找到）→ 每轮重新扫描
                    dev = detect_fanboard_port()
                    if dev:
                        serial_dev.device = dev
                        print(f"[FanBoardAgent] auto-detected FanBoard USB port: {dev}")
                if serial_dev.device:
                    # 带超时 open：阻塞的 os.open 在锁外执行，绝不死锁主循环
                    serial_dev.open_with_timeout(timeout=3.0)
                # 仍未找到就下一轮再试，不阻塞主循环

            local = collect_local(ip_override=local_ip_override,
                                  vllm_url=vllm_url, vllm_interval=vllm_interval)
            remote = collect_remote(host_b, host_b_port)
            msg = build_message(local, remote)
            serial_dev.write_line(msg)

            if start - last_print >= 5.0:
                print(f"[FanBoardAgent] {msg}")
                last_print = start
        except Exception as exc:
            print(f"[FanBoardAgent] loop exception: {exc}")

        elapsed = time.monotonic() - start
        sleep_time = max(0.0, interval_s - elapsed)
        SHUTDOWN_FLAG.wait(sleep_time)

    serial_dev.close()
    print("[FanBoardAgent] exited cleanly (shutdown flag)", flush=True)
    return 0

# ---------------------------------------------------------------------------
# 单实例接管：重复运行 = 自动停掉旧实例再接管
# ---------------------------------------------------------------------------
# [user-v1] 用户目录锁替代 /run PID + 杀旧进程：已有实例持锁时本实例直接退出，绝不杀任何进程。
STATE_DIR = os.environ.get("FANBOARD_HOME") or os.path.expanduser("~/.local/state/fanboard")
LOCK_FILE = os.path.join(STATE_DIR, "agent.lock")
_LOCK_FD = None

def _acquire_singleton() -> None:
    global _LOCK_FD
    import fcntl
    os.makedirs(STATE_DIR, mode=0o700, exist_ok=True)
    fd = os.open(LOCK_FILE, os.O_RDWR | os.O_CREAT, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        print(f"[FanBoardAgent] another instance holds {LOCK_FILE}; exiting (no process killed)", flush=True)
        raise SystemExit(3)
    os.ftruncate(fd, 0)
    os.write(fd, str(os.getpid()).encode())
    _LOCK_FD = fd  # 进程存活期间持锁，退出时内核自动释放

class _RotatingOut:
    """[user-v1] 按大小轮转的 stdout/stderr（FANBOARD_LOG 设置时启用）：单文件上限 FANBOARD_LOG_MAX 字节，保留 .1/.2。"""
    def __init__(self, path, max_bytes, keep=2):
        self.path, self.max, self.keep = path, max_bytes, keep
        self.lock = threading.Lock()
        self.f = open(path, "a", encoding="utf-8", buffering=1)
    def _rotate(self):
        self.f.close()
        for i in range(self.keep, 0, -1):
            src = self.path if i == 1 else f"{self.path}.{i-1}"
            if os.path.exists(src):
                os.replace(src, f"{self.path}.{i}")
        self.f = open(self.path, "a", encoding="utf-8", buffering=1)
    def write(self, msg):
        with self.lock:
            if msg and msg != "\n":
                msg = time.strftime("%Y-%m-%d %H:%M:%S%z ") + msg if not msg.startswith("\n") else msg
            self.f.write(msg)
            if self.f.tell() > self.max:
                self._rotate()
        return len(msg)
    def flush(self):
        with self.lock:
            self.f.flush()

def _setup_log():
    import sys
    path = os.environ.get("FANBOARD_LOG")
    if not path:
        return
    out = _RotatingOut(path, int(os.environ.get("FANBOARD_LOG_MAX", str(2 * 1024 * 1024))))
    sys.stdout = out
    sys.stderr = out

def main() -> int:
    _setup_log()
    # 重复运行：自动停掉上一个实例后由本实例接管（单实例保证）。
    ap = argparse.ArgumentParser(description="DGX Spark FanBoard Agent Repair Version USB+HTTP")
    ap.add_argument("--device", default="", help="USB serial device（留空则自动检测 FanBoard 口）")
    ap.add_argument("--baudrate", type=int, default=115200)
    ap.add_argument("--interval-ms", type=int, default=1000)
    ap.add_argument("--host-b", default="")
    ap.add_argument("--host-b-port", type=int, default=8080)
    ap.add_argument("--http", dest="http", action="store_true", default=True)
    ap.add_argument("--no-http", dest="http", action="store_false")
    ap.add_argument("--bind", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--local-ip", default="")
    ap.add_argument("--vllm-metrics-url", default="http://127.0.0.1:8888/metrics")
    ap.add_argument("--vllm-interval", type=float, default=10.0)
    ap.add_argument("--no-vllm", dest="vllm", action="store_false", default=True)
    args = ap.parse_args()
    _acquire_singleton()  # [user-v1] 解析参数之后再取锁，--help 不再有副作用
    print(f"[FanBoardAgent] start pid={os.getpid()} uid={os.getuid()} args={vars(args)}", flush=True)
    cfg = {
        "device": args.device,
        "baudrate": args.baudrate,
        "sample_interval_ms": args.interval_ms,
        "host_b": args.host_b,
        "host_b_port": args.host_b_port,
        "with_http": args.http,
        "bind": args.bind,
        "http_port": args.port,
        "local_ip": args.local_ip,
        "vllm_metrics_url": args.vllm_metrics_url if args.vllm else "",
        "vllm_interval": args.vllm_interval,
    }
    return _run(cfg)

if __name__ == "__main__":
    import sys
    sys.exit(main())
